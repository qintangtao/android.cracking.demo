package com.mycheering.data;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.mycheering.data.BuildConfig
 * JD-Core Version:    0.6.2
 */