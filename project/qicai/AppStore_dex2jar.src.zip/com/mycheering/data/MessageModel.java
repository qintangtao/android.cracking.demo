package com.mycheering.data;

import java.util.ArrayList;

public class MessageModel
{
  public String data;
  public ArrayList<String> idList = new ArrayList();
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.mycheering.data.MessageModel
 * JD-Core Version:    0.6.2
 */