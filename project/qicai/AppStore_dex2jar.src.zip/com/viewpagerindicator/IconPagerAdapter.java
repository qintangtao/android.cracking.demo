package com.viewpagerindicator;

public abstract interface IconPagerAdapter
{
  public abstract int getCount();

  public abstract int getIconResId(int paramInt);
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.viewpagerindicator.IconPagerAdapter
 * JD-Core Version:    0.6.2
 */