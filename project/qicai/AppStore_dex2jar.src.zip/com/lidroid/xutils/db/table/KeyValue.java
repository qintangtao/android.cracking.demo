package com.lidroid.xutils.db.table;

public class KeyValue
{
  public final String key;
  public final Object value;

  public KeyValue(String paramString, Object paramObject)
  {
    this.key = paramString;
    this.value = paramObject;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.lidroid.xutils.db.table.KeyValue
 * JD-Core Version:    0.6.2
 */