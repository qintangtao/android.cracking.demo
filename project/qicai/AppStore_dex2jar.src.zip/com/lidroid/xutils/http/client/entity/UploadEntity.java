package com.lidroid.xutils.http.client.entity;

import com.lidroid.xutils.http.callback.RequestCallBackHandler;

public abstract interface UploadEntity
{
  public abstract void setCallBackHandler(RequestCallBackHandler paramRequestCallBackHandler);
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.UploadEntity
 * JD-Core Version:    0.6.2
 */