package com.lidroid.xutils.http.callback;

public abstract interface RequestCallBackHandler
{
  public abstract boolean updateProgress(long paramLong1, long paramLong2, boolean paramBoolean);
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.lidroid.xutils.http.callback.RequestCallBackHandler
 * JD-Core Version:    0.6.2
 */