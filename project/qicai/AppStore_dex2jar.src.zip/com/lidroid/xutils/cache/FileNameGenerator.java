package com.lidroid.xutils.cache;

public abstract interface FileNameGenerator
{
  public abstract String generate(String paramString);
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.lidroid.xutils.cache.FileNameGenerator
 * JD-Core Version:    0.6.2
 */