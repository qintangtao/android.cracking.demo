package com.nineoldandroids.util;

public class NoSuchPropertyException extends RuntimeException
{
  public NoSuchPropertyException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.nineoldandroids.util.NoSuchPropertyException
 * JD-Core Version:    0.6.2
 */