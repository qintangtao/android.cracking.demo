package com.jh.net.bean;

public class DomainInfoCDTO
{
  private String Domain;
  private int ResponseCode;

  public String getDomain()
  {
    return this.Domain;
  }

  public int getResponseCode()
  {
    return this.ResponseCode;
  }

  public void setDomain(String paramString)
  {
    this.Domain = paramString;
  }

  public void setResponseCode(int paramInt)
  {
    this.ResponseCode = paramInt;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.jh.net.bean.DomainInfoCDTO
 * JD-Core Version:    0.6.2
 */