package com.jh.net.bean;

public class WebSiteCDTO
{
  private int Code;
  private String Domain;
  private String IP;
  private String Id;
  private String Name;

  public int getCode()
  {
    return this.Code;
  }

  public String getDomain()
  {
    return this.Domain;
  }

  public String getIP()
  {
    return this.IP;
  }

  public String getId()
  {
    return this.Id;
  }

  public String getName()
  {
    return this.Name;
  }

  public void setCode(int paramInt)
  {
    this.Code = paramInt;
  }

  public void setDomain(String paramString)
  {
    this.Domain = paramString;
  }

  public void setIP(String paramString)
  {
    this.IP = paramString;
  }

  public void setId(String paramString)
  {
    this.Id = paramString;
  }

  public void setName(String paramString)
  {
    this.Name = paramString;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.jh.net.bean.WebSiteCDTO
 * JD-Core Version:    0.6.2
 */