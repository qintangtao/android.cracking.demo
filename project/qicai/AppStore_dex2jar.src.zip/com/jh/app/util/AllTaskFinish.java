package com.jh.app.util;

public abstract interface AllTaskFinish
{
  public abstract void finish();
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.jh.app.util.AllTaskFinish
 * JD-Core Version:    0.6.2
 */