package com.hsg.sdk.common.http;

public abstract interface HttpErrorCode
{
  public static final int HTTP_CLIENT_PROTOCOL_ERR = 201;
  public static final int HTTP_IO_ERR = 301;
  public static final int HTTP_NETWORK_DISCONN = 101;
  public static final int HTTP_NULL_POINTER = 404;
  public static final int HTTP_OK;
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.hsg.sdk.common.http.HttpErrorCode
 * JD-Core Version:    0.6.2
 */