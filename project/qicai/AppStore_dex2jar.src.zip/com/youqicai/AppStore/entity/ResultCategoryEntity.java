package com.youqicai.AppStore.entity;

import java.util.ArrayList;
import java.util.List;

public class ResultCategoryEntity
{
  public List<BannerItem> bannerItemList = new ArrayList();
  public List<Category> cardEntityList = new ArrayList();
  public String errMsgs;
  public String errMsgsCnt;
  public String error;
  public String msg;
  public String status;
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.ResultCategoryEntity
 * JD-Core Version:    0.6.2
 */