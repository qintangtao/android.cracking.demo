package com.youqicai.AppStore.entity;

public class HotwordEntity
{
  private String hotword;

  public String getHotword()
  {
    return this.hotword;
  }

  public void setHotword(String paramString)
  {
    this.hotword = paramString;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.HotwordEntity
 * JD-Core Version:    0.6.2
 */