package com.youqicai.AppStore.entity;

import java.util.ArrayList;
import java.util.List;

public class ResultCardEntity
{
  public List<CardEntity> cardEntityList = new ArrayList();
  public boolean hasNext;
  public String msg;
  public String status;
}

/* Location:           C:\Users\Tato\Desktop\android反编译\qicai\AppStore_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.ResultCardEntity
 * JD-Core Version:    0.6.2
 */