package com.android.models;

public class Window
{
  public String currentActivity = "";
  public String packageName = "";
}

/* Location:           C:\ProgramData\MPhoneAssistant\res\lib\classes_dex2jar.jar
 * Qualified Name:     com.android.models.Window
 * JD-Core Version:    0.6.2
 */