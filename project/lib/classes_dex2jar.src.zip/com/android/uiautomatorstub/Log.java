package com.android.uiautomatorstub;

public class Log
{
  public static final String TAG = "UIAutomatorStub";

  public static void d(String paramString)
  {
    android.util.Log.d("UIAutomatorStub", paramString);
  }

  public static void e(String paramString)
  {
    android.util.Log.e("UIAutomatorStub", paramString);
  }

  public static void i(String paramString)
  {
    android.util.Log.i("UIAutomatorStub", paramString);
  }
}

/* Location:           C:\ProgramData\MPhoneAssistant\res\lib\classes_dex2jar.jar
 * Qualified Name:     com.android.uiautomatorstub.Log
 * JD-Core Version:    0.6.2
 */