package com.android.runner.phone;

public class Samsung
{
  public void run()
  {
  }
}

/* Location:           C:\ProgramData\MPhoneAssistant\res\lib\classes_dex2jar.jar
 * Qualified Name:     com.android.runner.phone.Samsung
 * JD-Core Version:    0.6.2
 */