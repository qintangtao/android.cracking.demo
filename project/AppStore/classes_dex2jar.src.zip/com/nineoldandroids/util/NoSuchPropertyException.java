package com.nineoldandroids.util;

public class NoSuchPropertyException extends RuntimeException
{
  public NoSuchPropertyException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.nineoldandroids.util.NoSuchPropertyException
 * JD-Core Version:    0.6.2
 */