package com.jh.util;

import java.util.UUID;

public class GUID
{
  public static String getGUID()
  {
    return UUID.randomUUID().toString();
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.jh.util.GUID
 * JD-Core Version:    0.6.2
 */