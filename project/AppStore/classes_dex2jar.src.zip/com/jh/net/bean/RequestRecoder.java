package com.jh.net.bean;

public class RequestRecoder
{
  private int response;
  private int status;

  public int getResponse()
  {
    return this.response;
  }

  public int getStatus()
  {
    return this.status;
  }

  public void setResponse(int paramInt)
  {
    this.response = paramInt;
  }

  public void setStatus(int paramInt)
  {
    this.status = paramInt;
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.jh.net.bean.RequestRecoder
 * JD-Core Version:    0.6.2
 */