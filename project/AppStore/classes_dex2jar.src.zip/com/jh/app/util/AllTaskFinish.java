package com.jh.app.util;

public abstract interface AllTaskFinish
{
  public abstract void finish();
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.jh.app.util.AllTaskFinish
 * JD-Core Version:    0.6.2
 */