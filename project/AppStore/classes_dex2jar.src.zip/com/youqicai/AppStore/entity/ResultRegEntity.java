package com.youqicai.AppStore.entity;

public class ResultRegEntity
{
  public String headUrl;
  public String msg;
  public String nickName;
  public String phone;
  public int status;
  public String token;
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.ResultRegEntity
 * JD-Core Version:    0.6.2
 */