package com.youqicai.AppStore.entity;

public class CommentItem
{
  private String apkId;
  private String appId;
  private String comment;
  private String createTime;
  private String headUrl;
  private String nickName;
  private String score;

  public String getApkId()
  {
    return this.apkId;
  }

  public String getAppId()
  {
    return this.appId;
  }

  public String getComment()
  {
    return this.comment;
  }

  public String getCreateTime()
  {
    return this.createTime;
  }

  public String getHeadUrl()
  {
    return this.headUrl;
  }

  public String getNickName()
  {
    return this.nickName;
  }

  public String getScore()
  {
    return this.score;
  }

  public void setApkId(String paramString)
  {
    this.apkId = paramString;
  }

  public void setAppId(String paramString)
  {
    this.appId = paramString;
  }

  public void setComment(String paramString)
  {
    this.comment = paramString;
  }

  public void setCreateTime(String paramString)
  {
    this.createTime = paramString;
  }

  public void setHeadUrl(String paramString)
  {
    this.headUrl = paramString;
  }

  public void setNickName(String paramString)
  {
    this.nickName = paramString;
  }

  public void setScore(String paramString)
  {
    this.score = paramString;
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.CommentItem
 * JD-Core Version:    0.6.2
 */