package com.youqicai.AppStore.entity;

public class HotwordEntity
{
  private String hotword;

  public String getHotword()
  {
    return this.hotword;
  }

  public void setHotword(String paramString)
  {
    this.hotword = paramString;
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.HotwordEntity
 * JD-Core Version:    0.6.2
 */