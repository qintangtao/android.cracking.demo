package com.youqicai.AppStore.entity;

import java.util.ArrayList;
import java.util.List;

public class ResultCommentEntity
{
  public List<Comment> commentList = new ArrayList();
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.ResultCommentEntity
 * JD-Core Version:    0.6.2
 */