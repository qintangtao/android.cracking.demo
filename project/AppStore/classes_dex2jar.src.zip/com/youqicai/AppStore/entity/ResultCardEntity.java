package com.youqicai.AppStore.entity;

import java.util.ArrayList;
import java.util.List;

public class ResultCardEntity
{
  public List<CardEntity> cardEntityList = new ArrayList();
  public boolean hasNext;
  public String msg;
  public String status;
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.youqicai.AppStore.entity.ResultCardEntity
 * JD-Core Version:    0.6.2
 */