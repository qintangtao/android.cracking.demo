package com.hsg.sdk.common.http;

public abstract interface ParseInfo
{
  public abstract Object parseInBackgroud(Object paramObject);
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.hsg.sdk.common.http.ParseInfo
 * JD-Core Version:    0.6.2
 */