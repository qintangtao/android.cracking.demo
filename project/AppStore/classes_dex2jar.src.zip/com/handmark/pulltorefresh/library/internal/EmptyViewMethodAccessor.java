package com.handmark.pulltorefresh.library.internal;

import android.view.View;

public abstract interface EmptyViewMethodAccessor
{
  public abstract void setEmptyView(View paramView);

  public abstract void setEmptyViewInternal(View paramView);
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.handmark.pulltorefresh.library.internal.EmptyViewMethodAccessor
 * JD-Core Version:    0.6.2
 */