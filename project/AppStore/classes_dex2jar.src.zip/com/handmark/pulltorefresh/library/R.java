package com.handmark.pulltorefresh.library;

public final class R
{
  public static final class anim
  {
    public static int rotate_loading_view = 2130968583;
    public static int slide_in_from_bottom = 2130968585;
    public static int slide_in_from_top = 2130968586;
    public static int slide_out_to_bottom = 2130968587;
    public static int slide_out_to_top = 2130968588;
  }

  public static final class attr
  {
    public static int ptrAdapterViewBackground = 2130772015;
    public static int ptrAnimationStyle = 2130772011;
    public static int ptrDrawable = 2130772005;
    public static int ptrDrawableBottom = 2130772017;
    public static int ptrDrawableEnd = 2130772007;
    public static int ptrDrawableStart = 2130772006;
    public static int ptrDrawableTop = 2130772016;
    public static int ptrHeaderBackground = 2130772000;
    public static int ptrHeaderSubTextColor = 2130772002;
    public static int ptrHeaderTextAppearance = 2130772009;
    public static int ptrHeaderTextColor = 2130772001;
    public static int ptrListViewExtrasEnabled = 2130772013;
    public static int ptrMode = 2130772003;
    public static int ptrOverScroll = 2130772008;
    public static int ptrRefreshableViewBackground = 2130771999;
    public static int ptrRotateDrawableWhilePulling = 2130772014;
    public static int ptrScrollingWhileRefreshingEnabled = 2130772012;
    public static int ptrShowIndicator = 2130772004;
    public static int ptrSubHeaderTextAppearance = 2130772010;
  }

  public static final class color
  {
    public static int pull_refresh_txt_color = 2131165226;
    public static int pull_refresh_txt_small_color = 2131165227;
  }

  public static final class dimen
  {
    public static int header_footer_left_right_padding = 2131361808;
    public static int header_footer_top_bottom_padding = 2131361809;
    public static int indicator_corner_radius = 2131361806;
    public static int indicator_internal_padding = 2131361807;
    public static int indicator_right_padding = 2131361805;
  }

  public static final class drawable
  {
    public static int default_ptr_flip = 2130837568;
    public static int default_ptr_rotate = 2130837569;
    public static int indicator_arrow = 2130837653;
    public static int indicator_bg_bottom = 2130837654;
    public static int indicator_bg_top = 2130837655;
  }

  public static final class id
  {
    public static int both = 2131099656;
    public static int disabled = 2131099653;
    public static int fl_inner = 2131099863;
    public static int flip = 2131099661;
    public static int gridview = 2131099662;
    public static int manualOnly = 2131099657;
    public static int pullDownFromTop = 2131099658;
    public static int pullFromEnd = 2131099655;
    public static int pullFromStart = 2131099654;
    public static int pullUpFromBottom = 2131099659;
    public static int pull_to_refresh_image = 2131099864;
    public static int pull_to_refresh_progress = 2131099865;
    public static int pull_to_refresh_sub_text = 2131099867;
    public static int pull_to_refresh_text = 2131099866;
    public static int rotate = 2131099660;
    public static int scrollview = 2131099664;
    public static int webview = 2131099663;
  }

  public static final class layout
  {
    public static int pull_to_refresh_header_horizontal = 2130903093;
    public static int pull_to_refresh_header_vertical = 2130903094;
  }

  public static final class string
  {
    public static int pull_to_refresh_from_bottom_pull_label = 2131492867;
    public static int pull_to_refresh_from_bottom_refreshing_label = 2131492869;
    public static int pull_to_refresh_from_bottom_release_label = 2131492868;
    public static int pull_to_refresh_pull_label = 2131492864;
    public static int pull_to_refresh_refreshing_label = 2131492866;
    public static int pull_to_refresh_release_label = 2131492865;
  }

  public static final class styleable
  {
    public static final int[] PullToRefresh = { 2130771999, 2130772000, 2130772001, 2130772002, 2130772003, 2130772004, 2130772005, 2130772006, 2130772007, 2130772008, 2130772009, 2130772010, 2130772011, 2130772012, 2130772013, 2130772014, 2130772015, 2130772016, 2130772017 };
    public static int PullToRefresh_ptrAdapterViewBackground = 16;
    public static int PullToRefresh_ptrAnimationStyle = 12;
    public static int PullToRefresh_ptrDrawable = 6;
    public static int PullToRefresh_ptrDrawableBottom = 18;
    public static int PullToRefresh_ptrDrawableEnd = 8;
    public static int PullToRefresh_ptrDrawableStart = 7;
    public static int PullToRefresh_ptrDrawableTop = 17;
    public static int PullToRefresh_ptrHeaderBackground = 1;
    public static int PullToRefresh_ptrHeaderSubTextColor = 3;
    public static int PullToRefresh_ptrHeaderTextAppearance = 10;
    public static int PullToRefresh_ptrHeaderTextColor = 2;
    public static int PullToRefresh_ptrListViewExtrasEnabled = 14;
    public static int PullToRefresh_ptrMode = 4;
    public static int PullToRefresh_ptrOverScroll = 9;
    public static int PullToRefresh_ptrRefreshableViewBackground = 0;
    public static int PullToRefresh_ptrRotateDrawableWhilePulling = 15;
    public static int PullToRefresh_ptrScrollingWhileRefreshingEnabled = 13;
    public static int PullToRefresh_ptrShowIndicator = 5;
    public static int PullToRefresh_ptrSubHeaderTextAppearance = 11;
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.handmark.pulltorefresh.library.R
 * JD-Core Version:    0.6.2
 */