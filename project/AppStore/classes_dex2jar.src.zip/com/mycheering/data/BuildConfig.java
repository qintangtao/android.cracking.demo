package com.mycheering.data;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.mycheering.data.BuildConfig
 * JD-Core Version:    0.6.2
 */