package com.mycheering.data;

public final class R
{
  public static final class dimen
  {
    public static int activity_horizontal_margin = 2131361810;
    public static int activity_vertical_margin = 2131361811;
  }

  public static final class drawable
  {
    public static int ic_launcher = 2130837596;
  }

  public static final class id
  {
  }

  public static final class layout
  {
    public static int activity_main = 2130903052;
    public static int activity_next = 2130903054;
  }

  public static final class string
  {
    public static int action_settings = 2131492872;
    public static int app_name = 2131492870;
    public static int hello_world = 2131492871;
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.mycheering.data.R
 * JD-Core Version:    0.6.2
 */