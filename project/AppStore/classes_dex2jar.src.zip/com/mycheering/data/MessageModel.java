package com.mycheering.data;

import java.util.ArrayList;

public class MessageModel
{
  public String data;
  public ArrayList<String> idList = new ArrayList();
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.mycheering.data.MessageModel
 * JD-Core Version:    0.6.2
 */