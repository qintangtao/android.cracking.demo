package com.viewpagerindicator;

public final class R
{
  public static final class attr
  {
    public static int centered = 2130771974;
    public static int clipPadding = 2130771985;
    public static int fadeDelay = 2130771997;
    public static int fadeLength = 2130771998;
    public static int fades = 2130771996;
    public static int fillColor = 2130771978;
    public static int footerColor = 2130771986;
    public static int footerIndicatorHeight = 2130771989;
    public static int footerIndicatorStyle = 2130771988;
    public static int footerIndicatorUnderlinePadding = 2130771990;
    public static int footerLineHeight = 2130771987;
    public static int footerPadding = 2130771991;
    public static int gapWidth = 2130771984;
    public static int linePosition = 2130771992;
    public static int lineWidth = 2130771983;
    public static int pageColor = 2130771979;
    public static int radius = 2130771980;
    public static int selectedBold = 2130771993;
    public static int selectedColor = 2130771975;
    public static int snap = 2130771981;
    public static int strokeColor = 2130771982;
    public static int strokeWidth = 2130771976;
    public static int titlePadding = 2130771994;
    public static int topPadding = 2130771995;
    public static int unselectedColor = 2130771977;
    public static int vpiCirclePageIndicatorStyle = 2130771968;
    public static int vpiIconPageIndicatorStyle = 2130771969;
    public static int vpiLinePageIndicatorStyle = 2130771970;
    public static int vpiTabPageIndicatorStyle = 2130771972;
    public static int vpiTitlePageIndicatorStyle = 2130771971;
    public static int vpiUnderlinePageIndicatorStyle = 2130771973;
  }

  public static final class bool
  {
    public static int default_circle_indicator_centered = 2131230720;
    public static int default_circle_indicator_snap = 2131230721;
    public static int default_line_indicator_centered = 2131230722;
    public static int default_title_indicator_selected_bold = 2131230723;
    public static int default_underline_indicator_fades = 2131230724;
  }

  public static final class color
  {
    public static int default_circle_indicator_fill_color = 2131165192;
    public static int default_circle_indicator_page_color = 2131165193;
    public static int default_circle_indicator_stroke_color = 2131165194;
    public static int default_line_indicator_selected_color = 2131165195;
    public static int default_line_indicator_unselected_color = 2131165196;
    public static int default_title_indicator_footer_color = 2131165197;
    public static int default_title_indicator_selected_color = 2131165198;
    public static int default_title_indicator_text_color = 2131165199;
    public static int default_underline_indicator_selected_color = 2131165200;
    public static int vpi__background_holo_dark = 2131165184;
    public static int vpi__background_holo_light = 2131165185;
    public static int vpi__bright_foreground_disabled_holo_dark = 2131165188;
    public static int vpi__bright_foreground_disabled_holo_light = 2131165189;
    public static int vpi__bright_foreground_holo_dark = 2131165186;
    public static int vpi__bright_foreground_holo_light = 2131165187;
    public static int vpi__bright_foreground_inverse_holo_dark = 2131165190;
    public static int vpi__bright_foreground_inverse_holo_light = 2131165191;
    public static int vpi__dark_theme = 2131165237;
    public static int vpi__light_theme = 2131165238;
  }

  public static final class dimen
  {
    public static int default_circle_indicator_radius = 2131361792;
    public static int default_circle_indicator_stroke_width = 2131361793;
    public static int default_line_indicator_gap_width = 2131361795;
    public static int default_line_indicator_line_width = 2131361794;
    public static int default_line_indicator_stroke_width = 2131361796;
    public static int default_title_indicator_clip_padding = 2131361797;
    public static int default_title_indicator_footer_indicator_height = 2131361799;
    public static int default_title_indicator_footer_indicator_underline_padding = 2131361800;
    public static int default_title_indicator_footer_line_height = 2131361798;
    public static int default_title_indicator_footer_padding = 2131361801;
    public static int default_title_indicator_text_size = 2131361802;
    public static int default_title_indicator_title_padding = 2131361803;
    public static int default_title_indicator_top_padding = 2131361804;
  }

  public static final class drawable
  {
    public static int vpi__tab_indicator = 2130837702;
    public static int vpi__tab_selected_focused_holo = 2130837703;
    public static int vpi__tab_selected_holo = 2130837704;
    public static int vpi__tab_selected_pressed_holo = 2130837705;
    public static int vpi__tab_unselected_focused_holo = 2130837706;
    public static int vpi__tab_unselected_holo = 2130837707;
    public static int vpi__tab_unselected_pressed_holo = 2130837708;
  }

  public static final class id
  {
    public static int bottom = 2131099651;
    public static int none = 2131099648;
    public static int top = 2131099652;
    public static int triangle = 2131099649;
    public static int underline = 2131099650;
  }

  public static final class integer
  {
    public static int default_circle_indicator_orientation = 2131296256;
    public static int default_title_indicator_footer_indicator_style = 2131296257;
    public static int default_title_indicator_line_position = 2131296258;
    public static int default_underline_indicator_fade_delay = 2131296259;
    public static int default_underline_indicator_fade_length = 2131296260;
  }

  public static final class style
  {
    public static int TextAppearance_TabPageIndicator = 2131427331;
    public static int Theme_PageIndicatorDefaults = 2131427328;
    public static int Widget = 2131427329;
    public static int Widget_IconPageIndicator = 2131427332;
    public static int Widget_TabPageIndicator = 2131427330;
  }

  public static final class styleable
  {
    public static final int[] CirclePageIndicator = { 16842948, 16842964, 2130771974, 2130771976, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982 };
    public static int CirclePageIndicator_android_background = 1;
    public static int CirclePageIndicator_android_orientation = 0;
    public static int CirclePageIndicator_centered = 2;
    public static int CirclePageIndicator_fillColor = 4;
    public static int CirclePageIndicator_pageColor = 5;
    public static int CirclePageIndicator_radius = 6;
    public static int CirclePageIndicator_snap = 7;
    public static int CirclePageIndicator_strokeColor = 8;
    public static int CirclePageIndicator_strokeWidth = 3;
    public static final int[] LinePageIndicator = { 16842964, 2130771974, 2130771975, 2130771976, 2130771977, 2130771983, 2130771984 };
    public static int LinePageIndicator_android_background = 0;
    public static int LinePageIndicator_centered = 1;
    public static int LinePageIndicator_gapWidth = 6;
    public static int LinePageIndicator_lineWidth = 5;
    public static int LinePageIndicator_selectedColor = 2;
    public static int LinePageIndicator_strokeWidth = 3;
    public static int LinePageIndicator_unselectedColor = 4;
    public static final int[] TitlePageIndicator = { 16842901, 16842904, 16842964, 2130771975, 2130771985, 2130771986, 2130771987, 2130771988, 2130771989, 2130771990, 2130771991, 2130771992, 2130771993, 2130771994, 2130771995 };
    public static int TitlePageIndicator_android_background = 2;
    public static int TitlePageIndicator_android_textColor = 1;
    public static int TitlePageIndicator_android_textSize = 0;
    public static int TitlePageIndicator_clipPadding = 4;
    public static int TitlePageIndicator_footerColor = 5;
    public static int TitlePageIndicator_footerIndicatorHeight = 8;
    public static int TitlePageIndicator_footerIndicatorStyle = 7;
    public static int TitlePageIndicator_footerIndicatorUnderlinePadding = 9;
    public static int TitlePageIndicator_footerLineHeight = 6;
    public static int TitlePageIndicator_footerPadding = 10;
    public static int TitlePageIndicator_linePosition = 11;
    public static int TitlePageIndicator_selectedBold = 12;
    public static int TitlePageIndicator_selectedColor = 3;
    public static int TitlePageIndicator_titlePadding = 13;
    public static int TitlePageIndicator_topPadding = 14;
    public static final int[] UnderlinePageIndicator = { 16842964, 2130771975, 2130771996, 2130771997, 2130771998 };
    public static int UnderlinePageIndicator_android_background = 0;
    public static int UnderlinePageIndicator_fadeDelay = 3;
    public static int UnderlinePageIndicator_fadeLength = 4;
    public static int UnderlinePageIndicator_fades = 2;
    public static int UnderlinePageIndicator_selectedColor = 1;
    public static final int[] ViewPagerIndicator = { 2130771968, 2130771969, 2130771970, 2130771971, 2130771972, 2130771973 };
    public static int ViewPagerIndicator_vpiCirclePageIndicatorStyle = 0;
    public static int ViewPagerIndicator_vpiIconPageIndicatorStyle = 1;
    public static int ViewPagerIndicator_vpiLinePageIndicatorStyle = 2;
    public static int ViewPagerIndicator_vpiTabPageIndicatorStyle = 4;
    public static int ViewPagerIndicator_vpiTitlePageIndicatorStyle = 3;
    public static int ViewPagerIndicator_vpiUnderlinePageIndicatorStyle = 5;
  }
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.viewpagerindicator.R
 * JD-Core Version:    0.6.2
 */