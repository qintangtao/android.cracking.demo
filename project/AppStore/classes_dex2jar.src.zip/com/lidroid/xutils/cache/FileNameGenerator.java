package com.lidroid.xutils.cache;

public abstract interface FileNameGenerator
{
  public abstract String generate(String paramString);
}

/* Location:           C:\Program Files (x86)\MPhoneAssistant\res\AppStore\classes_dex2jar.jar
 * Qualified Name:     com.lidroid.xutils.cache.FileNameGenerator
 * JD-Core Version:    0.6.2
 */