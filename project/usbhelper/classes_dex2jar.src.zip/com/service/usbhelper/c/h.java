package com.service.usbhelper.c;

import android.content.Context;
import com.service.usbhelper.d.i;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.m;
import java.net.URLEncoder;
import java.util.ArrayList;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.StatusLine;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

public class h
{
  private static h d;
  private static String e = "HttpRequestUtil";
  private DefaultHttpClient a;
  private HttpPost b;
  private HttpGet c;

  private h()
  {
    BasicHttpParams localBasicHttpParams = new BasicHttpParams();
    localBasicHttpParams.setParameter("http.protocol.version", HttpVersion.HTTP_1_1);
    localBasicHttpParams.setParameter("http.protocol.content-charset", "UTF-8");
    localBasicHttpParams.setParameter("http.connection.timeout", Integer.valueOf(15000));
    localBasicHttpParams.setParameter("http.connection.stalecheck", Boolean.valueOf(false));
    SchemeRegistry localSchemeRegistry = new SchemeRegistry();
    localSchemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
    localSchemeRegistry.register(new Scheme("https", SSLSocketFactory.getSocketFactory(), 443));
    this.a = new DefaultHttpClient(new ThreadSafeClientConnManager(localBasicHttpParams, localSchemeRegistry), localBasicHttpParams);
  }

  public static h a()
  {
    d = new h();
    return d;
  }

  public String a(String paramString1, String paramString2, Context paramContext)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    this.b = new HttpPost(paramString1);
    ArrayList localArrayList = new ArrayList();
    localStringBuilder.append(paramString2);
    localArrayList.add(new BasicNameValuePair("content", URLEncoder.encode(paramString2, "utf-8")));
    if ((localArrayList != null) && (localArrayList.size() > 0))
      this.b.setEntity(new UrlEncodedFormEntity(localArrayList, "UTF-8"));
    HttpResponse localHttpResponse = this.a.execute(this.b);
    if (localHttpResponse.getStatusLine().getStatusCode() == 200)
    {
      String str = EntityUtils.toString(localHttpResponse.getEntity());
      j.b(e, "sendDataResult:" + str);
      return str;
    }
    return null;
  }

  public String a(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    this.b = new HttpPost(paramString2);
    ArrayList localArrayList = new ArrayList();
    localStringBuilder.append(paramString3);
    localStringBuilder.append(a(paramString1, this.b));
    String str1 = i.b(localStringBuilder.toString());
    localArrayList.add(new BasicNameValuePair("project", m.a(paramContext, "project_name")));
    localArrayList.add(new BasicNameValuePair("data", URLEncoder.encode(paramString3, "utf-8")));
    localArrayList.add(new BasicNameValuePair("sign", str1));
    if ((localArrayList != null) && (localArrayList.size() > 0))
      this.b.setEntity(new UrlEncodedFormEntity(localArrayList, "UTF-8"));
    HttpResponse localHttpResponse = this.a.execute(this.b);
    if (localHttpResponse.getStatusLine().getStatusCode() == 200)
    {
      String str2 = EntityUtils.toString(localHttpResponse.getEntity());
      j.b(e, "sendDataResult:" + str2);
      return str2;
    }
    return null;
  }

  public String a(String paramString, ArrayList<BasicNameValuePair> paramArrayList)
  {
    this.b = new HttpPost(paramString);
    if ((paramArrayList != null) && (paramArrayList.size() > 0))
      this.b.setEntity(new UrlEncodedFormEntity(paramArrayList, "UTF-8"));
    HttpResponse localHttpResponse = this.a.execute(this.b);
    if (localHttpResponse.getStatusLine().getStatusCode() == 200)
      return EntityUtils.toString(localHttpResponse.getEntity());
    return null;
  }

  public String a(String paramString, HttpPost paramHttpPost)
  {
    this.c = new HttpGet(paramString);
    StringBuilder localStringBuilder = new StringBuilder();
    try
    {
      HttpResponse localHttpResponse = this.a.execute(this.c);
      if (localHttpResponse == null)
        return "";
      Header[] arrayOfHeader = localHttpResponse.getAllHeaders();
      for (int i = 0; ; i++)
      {
        int j = arrayOfHeader.length;
        if (i >= j)
          return localStringBuilder.toString();
        if (arrayOfHeader[i].getValue().contains("sid"))
        {
          String str4 = arrayOfHeader[i].getValue();
          int m = str4.indexOf("=");
          localStringBuilder.append(str4.substring(m + 1));
          paramHttpPost.setHeader("sid", str4.substring(m + 1));
        }
        if (arrayOfHeader[i].getValue().contains("key"))
        {
          String str3 = arrayOfHeader[i].getValue();
          int k = str3.indexOf("=");
          localStringBuilder.append(str3.substring(k + 1));
          paramHttpPost.setHeader("key", str3.substring(k + 1));
        }
        if (arrayOfHeader[i].getValue().contains("PHPSESSID"))
        {
          String str2 = arrayOfHeader[i].getValue();
          paramHttpPost.setHeader("PHPSESSID", str2.substring(1 + str2.indexOf("=")));
        }
        if (arrayOfHeader[i].getValue().contains("tid"))
        {
          String str1 = arrayOfHeader[i].getValue();
          paramHttpPost.setHeader("tid", str1.substring(1 + str1.indexOf("=")));
        }
      }
    }
    catch (Exception localException)
    {
    }
    return "";
  }

  public String b(String paramString, ArrayList<BasicNameValuePair> paramArrayList)
  {
    Object localObject1;
    int i;
    if ((paramArrayList != null) && (paramArrayList.size() > 0))
    {
      localObject1 = paramString + "?";
      i = 0;
      if (i >= paramArrayList.size())
        paramString = (String)localObject1;
    }
    else
    {
      this.c = new HttpGet(paramString);
      HttpResponse localHttpResponse = this.a.execute(this.c);
      if (localHttpResponse.getStatusLine().getStatusCode() != 200)
        break label189;
      return EntityUtils.toString(localHttpResponse.getEntity());
    }
    BasicNameValuePair localBasicNameValuePair = (BasicNameValuePair)paramArrayList.get(i);
    String str;
    if (localBasicNameValuePair.getValue() != null)
      str = localBasicNameValuePair.getName() + "=" + localBasicNameValuePair.getValue() + "&";
    for (Object localObject2 = localObject1 + str; ; localObject2 = localObject1)
    {
      i++;
      localObject1 = localObject2;
      break;
      label189: return null;
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.h
 * JD-Core Version:    0.6.2
 */