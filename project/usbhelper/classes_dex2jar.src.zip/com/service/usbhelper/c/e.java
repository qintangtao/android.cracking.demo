package com.service.usbhelper.c;

import android.os.Handler;
import java.net.HttpURLConnection;
import java.net.URL;

public class e
  implements Runnable
{
  public e(c paramc)
  {
  }

  public void run()
  {
    try
    {
      HttpURLConnection localHttpURLConnection = (HttpURLConnection)new URL(c.a(this.a)).openConnection();
      localHttpURLConnection.setConnectTimeout(5000);
      localHttpURLConnection.setRequestMethod("GET");
      localHttpURLConnection.connect();
      c.a(this.a, localHttpURLConnection.getContentLength());
      localHttpURLConnection.disconnect();
      c.b(this.a).sendEmptyMessage(1003);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
    finally
    {
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.e
 * JD-Core Version:    0.6.2
 */