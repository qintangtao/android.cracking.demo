package com.service.usbhelper.c;

public class f
{
  private int b;
  private long c;
  private long d;
  private long e;

  public f(c paramc)
  {
  }

  public int a()
  {
    return this.b;
  }

  public void a(long paramLong)
  {
    this.c = paramLong;
  }

  public long b()
  {
    return this.c;
  }

  public void b(long paramLong)
  {
    this.d = paramLong;
  }

  public long c()
  {
    return this.d;
  }

  public void c(long paramLong)
  {
    this.e = paramLong;
  }

  public long d()
  {
    return this.e;
  }

  public String toString()
  {
    return "startPost:" + b() + "endPost:" + c() + "downloadLength:" + d();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.f
 * JD-Core Version:    0.6.2
 */