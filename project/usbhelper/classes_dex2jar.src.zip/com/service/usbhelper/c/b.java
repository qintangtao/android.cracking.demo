package com.service.usbhelper.c;

import android.content.Context;
import com.service.usbhelper.d.m;
import java.io.File;

public class b
  implements a
{
  private long a;
  private int b = 0;
  private String c;
  private Context d;

  public b(Context paramContext, String paramString)
  {
    this.c = paramString;
    this.d = paramContext;
  }

  private void d()
  {
    File localFile = new File(com.service.usbhelper.d.b.b() + "/Android/data/com.book2345.reader/apk" + "/" + this.c);
    if (localFile.exists())
      localFile.delete();
  }

  public void a()
  {
    d();
  }

  public void a(long paramLong)
  {
    int i = (int)(100.0F * ((float)paramLong / (float)this.a));
    if (i - this.b > 2)
      this.b = i;
  }

  public void a(long paramLong1, long paramLong2)
  {
    this.a = paramLong2;
  }

  public void a(String paramString)
  {
    m.b(this.d, paramString);
  }

  public void b()
  {
    d();
  }

  public void c()
  {
    d();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.b
 * JD-Core Version:    0.6.2
 */