package com.service.usbhelper.c;

import android.os.Handler;
import com.service.usbhelper.d.b;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;

public class c
{
  private static int f = 1;
  private static boolean i = false;
  private String a;
  private String b;
  private Handler c;
  private int d = 0;
  private long e = 0L;
  private ArrayList<f> g = new ArrayList();
  private int h = 101;
  private a j;

  public c(String paramString1, String paramString2, boolean paramBoolean, int paramInt, a parama)
  {
    this.a = paramString1;
    this.b = paramString2;
    f = paramInt;
    i = paramBoolean;
    this.j = parama;
    b();
  }

  private void a(int paramInt)
  {
    f = -1 + f;
    if (f == 0)
    {
      if (this.e != this.d)
        h();
    }
    else
      return;
    g();
  }

  private void a(f paramf)
  {
  }

  private void b()
  {
    this.c = new d(this);
  }

  private void c()
  {
    Iterator localIterator;
    if ((this.g.size() == 0) || (!i))
    {
      d();
      this.h = 100;
      if (this.j != null)
        this.j.a(this.e, this.d);
      localIterator = this.g.iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
      {
        return;
        e();
        break;
      }
      new Thread(new g(this, (f)localIterator.next())).start();
    }
  }

  private void d()
  {
    try
    {
      File localFile1 = new File(this.b);
      File localFile2 = new File(b.b() + "/Android/data/com.book2345.reader/apk");
      if (!localFile2.isDirectory())
        localFile2.mkdirs();
      if (!localFile1.exists())
        localFile1.createNewFile();
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(localFile1, "rwd");
      localRandomAccessFile.setLength(this.d);
      localRandomAccessFile.close();
      this.e = 0L;
      int k = this.d / f;
      int m = 0;
      if (m >= f)
        return;
      f localf = new f(this);
      localf.a(m * k);
      if (m < -1 + f)
        localf.b(-1 + (k + m * k));
      while (true)
      {
        this.g.add(localf);
        m++;
        break;
        localf.b(k + m * k);
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private void e()
  {
    try
    {
      boolean bool = new File(this.b).exists();
      int k = 0;
      if (bool)
        k = 1;
      if (k == 0)
      {
        f();
        d();
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private void f()
  {
    this.g.clear();
  }

  private void g()
  {
    f();
    if (this.j != null)
      this.j.a(this.b);
  }

  private void h()
  {
    f();
    File localFile = new File(this.b);
    if (localFile.exists())
      localFile.delete();
    if (this.j != null)
      this.j.a();
  }

  public void a()
  {
    new Thread(new e(this)).start();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.c
 * JD-Core Version:    0.6.2
 */