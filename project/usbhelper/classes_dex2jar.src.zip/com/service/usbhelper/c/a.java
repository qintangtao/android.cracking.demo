package com.service.usbhelper.c;

public abstract interface a
{
  public abstract void a();

  public abstract void a(long paramLong);

  public abstract void a(long paramLong1, long paramLong2);

  public abstract void a(String paramString);

  public abstract void b();

  public abstract void c();
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.a
 * JD-Core Version:    0.6.2
 */