package com.service.usbhelper.c;

public class g
  implements Runnable
{
  private f b;

  public g(c paramc, f paramf)
  {
    this.b = paramf;
  }

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: new 24	java/io/RandomAccessFile
    //   5: dup
    //   6: aload_0
    //   7: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   10: invokestatic 30	com/service/usbhelper/c/c:c	(Lcom/service/usbhelper/c/c;)Ljava/lang/String;
    //   13: ldc 32
    //   15: invokespecial 35	java/io/RandomAccessFile:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   18: astore_2
    //   19: aload_2
    //   20: aload_0
    //   21: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   24: invokevirtual 41	com/service/usbhelper/c/f:d	()J
    //   27: aload_0
    //   28: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   31: invokevirtual 43	com/service/usbhelper/c/f:b	()J
    //   34: ladd
    //   35: invokevirtual 47	java/io/RandomAccessFile:seek	(J)V
    //   38: new 49	java/net/URL
    //   41: dup
    //   42: aload_0
    //   43: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   46: invokestatic 51	com/service/usbhelper/c/c:a	(Lcom/service/usbhelper/c/c;)Ljava/lang/String;
    //   49: invokespecial 54	java/net/URL:<init>	(Ljava/lang/String;)V
    //   52: invokevirtual 58	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   55: checkcast 60	java/net/HttpURLConnection
    //   58: astore 13
    //   60: aload 13
    //   62: ldc 62
    //   64: invokevirtual 65	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   67: aload 13
    //   69: iconst_0
    //   70: invokevirtual 69	java/net/HttpURLConnection:setReadTimeout	(I)V
    //   73: aload 13
    //   75: ldc 71
    //   77: new 73	java/lang/StringBuilder
    //   80: dup
    //   81: ldc 75
    //   83: invokespecial 76	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   86: aload_0
    //   87: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   90: invokevirtual 41	com/service/usbhelper/c/f:d	()J
    //   93: aload_0
    //   94: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   97: invokevirtual 43	com/service/usbhelper/c/f:b	()J
    //   100: ladd
    //   101: invokevirtual 80	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   104: ldc 82
    //   106: invokevirtual 85	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: aload_0
    //   110: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   113: invokevirtual 87	com/service/usbhelper/c/f:c	()J
    //   116: invokevirtual 80	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   119: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   122: invokevirtual 94	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   125: aload 13
    //   127: ldc 96
    //   129: ldc 98
    //   131: invokevirtual 94	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   134: aload_0
    //   135: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   138: invokestatic 101	com/service/usbhelper/c/c:d	(Lcom/service/usbhelper/c/c;)I
    //   141: istore 16
    //   143: iload 16
    //   145: ifne +38 -> 183
    //   148: iconst_0
    //   149: ifeq +7 -> 156
    //   152: aconst_null
    //   153: invokevirtual 106	java/io/InputStream:close	()V
    //   156: aload 13
    //   158: ifnull +8 -> 166
    //   161: aload 13
    //   163: invokevirtual 109	java/net/HttpURLConnection:disconnect	()V
    //   166: aload_2
    //   167: ifnull +7 -> 174
    //   170: aload_2
    //   171: invokevirtual 110	java/io/RandomAccessFile:close	()V
    //   174: return
    //   175: astore 29
    //   177: aload 29
    //   179: invokevirtual 113	java/io/IOException:printStackTrace	()V
    //   182: return
    //   183: aload 13
    //   185: invokevirtual 117	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   188: astore 17
    //   190: aload 17
    //   192: astore_1
    //   193: sipush 4096
    //   196: newarray byte
    //   198: astore 19
    //   200: aload_1
    //   201: aload 19
    //   203: invokevirtual 121	java/io/InputStream:read	([B)I
    //   206: istore 20
    //   208: iload 20
    //   210: iconst_m1
    //   211: if_icmpne +110 -> 321
    //   214: iload 20
    //   216: iconst_m1
    //   217: if_icmpne +69 -> 286
    //   220: aload_0
    //   221: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   224: invokevirtual 41	com/service/usbhelper/c/f:d	()J
    //   227: aload_0
    //   228: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   231: invokevirtual 87	com/service/usbhelper/c/f:c	()J
    //   234: aload_0
    //   235: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   238: invokevirtual 43	com/service/usbhelper/c/f:b	()J
    //   241: lsub
    //   242: lcmp
    //   243: ifne +373 -> 616
    //   246: aload_0
    //   247: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   250: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   253: sipush 1002
    //   256: invokevirtual 130	android/os/Handler:obtainMessage	(I)Landroid/os/Message;
    //   259: astore 27
    //   261: aload 27
    //   263: aload_0
    //   264: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   267: invokevirtual 133	com/service/usbhelper/c/f:a	()I
    //   270: putfield 139	android/os/Message:arg1	I
    //   273: aload_0
    //   274: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   277: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   280: aload 27
    //   282: invokevirtual 143	android/os/Handler:sendMessage	(Landroid/os/Message;)Z
    //   285: pop
    //   286: aload_1
    //   287: ifnull +7 -> 294
    //   290: aload_1
    //   291: invokevirtual 106	java/io/InputStream:close	()V
    //   294: aload 13
    //   296: ifnull +8 -> 304
    //   299: aload 13
    //   301: invokevirtual 109	java/net/HttpURLConnection:disconnect	()V
    //   304: aload_2
    //   305: ifnull -131 -> 174
    //   308: aload_2
    //   309: invokevirtual 110	java/io/RandomAccessFile:close	()V
    //   312: return
    //   313: astore 26
    //   315: aload 26
    //   317: invokevirtual 113	java/io/IOException:printStackTrace	()V
    //   320: return
    //   321: aload_0
    //   322: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   325: invokestatic 146	com/service/usbhelper/c/c:e	(Lcom/service/usbhelper/c/c;)I
    //   328: bipush 101
    //   330: if_icmpne +149 -> 479
    //   333: aload_0
    //   334: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   337: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   340: sipush 1001
    //   343: invokevirtual 130	android/os/Handler:obtainMessage	(I)Landroid/os/Message;
    //   346: astore 24
    //   348: aload 24
    //   350: aload_0
    //   351: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   354: putfield 150	android/os/Message:obj	Ljava/lang/Object;
    //   357: aload_0
    //   358: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   361: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   364: aload 24
    //   366: invokevirtual 143	android/os/Handler:sendMessage	(Landroid/os/Message;)Z
    //   369: pop
    //   370: goto -156 -> 214
    //   373: astore 15
    //   375: aload 13
    //   377: astore 4
    //   379: aload 15
    //   381: astore_3
    //   382: aload_3
    //   383: invokevirtual 113	java/io/IOException:printStackTrace	()V
    //   386: aload_0
    //   387: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   390: bipush 101
    //   392: invokestatic 153	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;I)V
    //   395: aload_0
    //   396: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   399: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   402: sipush 1001
    //   405: invokevirtual 130	android/os/Handler:obtainMessage	(I)Landroid/os/Message;
    //   408: astore 10
    //   410: aload 10
    //   412: aload_0
    //   413: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   416: putfield 150	android/os/Message:obj	Ljava/lang/Object;
    //   419: aload_0
    //   420: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   423: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   426: aload 10
    //   428: invokevirtual 143	android/os/Handler:sendMessage	(Landroid/os/Message;)Z
    //   431: pop
    //   432: aload_0
    //   433: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   436: invokestatic 157	com/service/usbhelper/c/c:g	(Lcom/service/usbhelper/c/c;)Lcom/service/usbhelper/c/a;
    //   439: invokeinterface 161 1 0
    //   444: aload_1
    //   445: ifnull +7 -> 452
    //   448: aload_1
    //   449: invokevirtual 106	java/io/InputStream:close	()V
    //   452: aload 4
    //   454: ifnull +8 -> 462
    //   457: aload 4
    //   459: invokevirtual 109	java/net/HttpURLConnection:disconnect	()V
    //   462: aload_2
    //   463: ifnull -289 -> 174
    //   466: aload_2
    //   467: invokevirtual 110	java/io/RandomAccessFile:close	()V
    //   470: return
    //   471: astore 12
    //   473: aload 12
    //   475: invokevirtual 113	java/io/IOException:printStackTrace	()V
    //   478: return
    //   479: aload_2
    //   480: aload 19
    //   482: iconst_0
    //   483: iload 20
    //   485: invokevirtual 165	java/io/RandomAccessFile:write	([BII)V
    //   488: aload_0
    //   489: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   492: aload_0
    //   493: getfield 19	com/service/usbhelper/c/g:b	Lcom/service/usbhelper/c/f;
    //   496: invokevirtual 41	com/service/usbhelper/c/f:d	()J
    //   499: iload 20
    //   501: i2l
    //   502: ladd
    //   503: invokevirtual 167	com/service/usbhelper/c/f:c	(J)V
    //   506: aload_0
    //   507: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   510: astore 21
    //   512: aload 21
    //   514: aload 21
    //   516: invokestatic 171	com/service/usbhelper/c/c:f	(Lcom/service/usbhelper/c/c;)J
    //   519: iload 20
    //   521: i2l
    //   522: ladd
    //   523: invokestatic 174	com/service/usbhelper/c/c:a	(Lcom/service/usbhelper/c/c;J)V
    //   526: aload_0
    //   527: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   530: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   533: sipush 1000
    //   536: invokevirtual 130	android/os/Handler:obtainMessage	(I)Landroid/os/Message;
    //   539: astore 22
    //   541: aload 22
    //   543: aload_0
    //   544: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   547: invokestatic 171	com/service/usbhelper/c/c:f	(Lcom/service/usbhelper/c/c;)J
    //   550: invokestatic 180	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   553: putfield 150	android/os/Message:obj	Ljava/lang/Object;
    //   556: aload_0
    //   557: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   560: invokestatic 124	com/service/usbhelper/c/c:b	(Lcom/service/usbhelper/c/c;)Landroid/os/Handler;
    //   563: aload 22
    //   565: invokevirtual 143	android/os/Handler:sendMessage	(Landroid/os/Message;)Z
    //   568: pop
    //   569: goto -369 -> 200
    //   572: astore 18
    //   574: aload_1
    //   575: astore 7
    //   577: aload 13
    //   579: astore 8
    //   581: aload 18
    //   583: astore 5
    //   585: aload 7
    //   587: ifnull +8 -> 595
    //   590: aload 7
    //   592: invokevirtual 106	java/io/InputStream:close	()V
    //   595: aload 8
    //   597: ifnull +8 -> 605
    //   600: aload 8
    //   602: invokevirtual 109	java/net/HttpURLConnection:disconnect	()V
    //   605: aload_2
    //   606: ifnull +7 -> 613
    //   609: aload_2
    //   610: invokevirtual 110	java/io/RandomAccessFile:close	()V
    //   613: aload 5
    //   615: athrow
    //   616: aload_0
    //   617: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   620: invokestatic 157	com/service/usbhelper/c/c:g	(Lcom/service/usbhelper/c/c;)Lcom/service/usbhelper/c/a;
    //   623: ifnull -337 -> 286
    //   626: aload_0
    //   627: getfield 14	com/service/usbhelper/c/g:a	Lcom/service/usbhelper/c/c;
    //   630: invokestatic 157	com/service/usbhelper/c/c:g	(Lcom/service/usbhelper/c/c;)Lcom/service/usbhelper/c/a;
    //   633: invokeinterface 161 1 0
    //   638: goto -352 -> 286
    //   641: astore 9
    //   643: aload 9
    //   645: invokevirtual 113	java/io/IOException:printStackTrace	()V
    //   648: goto -35 -> 613
    //   651: astore 5
    //   653: aconst_null
    //   654: astore 7
    //   656: aconst_null
    //   657: astore 8
    //   659: aconst_null
    //   660: astore_2
    //   661: goto -76 -> 585
    //   664: astore 5
    //   666: aconst_null
    //   667: astore 7
    //   669: aconst_null
    //   670: astore 8
    //   672: goto -87 -> 585
    //   675: astore 14
    //   677: aload 13
    //   679: astore 8
    //   681: aload 14
    //   683: astore 5
    //   685: aconst_null
    //   686: astore 7
    //   688: goto -103 -> 585
    //   691: astore 5
    //   693: aload 4
    //   695: astore 6
    //   697: aload_1
    //   698: astore 7
    //   700: aload 6
    //   702: astore 8
    //   704: goto -119 -> 585
    //   707: astore_3
    //   708: aconst_null
    //   709: astore 4
    //   711: aconst_null
    //   712: astore_1
    //   713: aconst_null
    //   714: astore_2
    //   715: goto -333 -> 382
    //   718: astore_3
    //   719: aconst_null
    //   720: astore 4
    //   722: aconst_null
    //   723: astore_1
    //   724: goto -342 -> 382
    //
    // Exception table:
    //   from	to	target	type
    //   152	156	175	java/io/IOException
    //   161	166	175	java/io/IOException
    //   170	174	175	java/io/IOException
    //   290	294	313	java/io/IOException
    //   299	304	313	java/io/IOException
    //   308	312	313	java/io/IOException
    //   60	143	373	java/io/IOException
    //   183	190	373	java/io/IOException
    //   193	200	373	java/io/IOException
    //   200	208	373	java/io/IOException
    //   220	286	373	java/io/IOException
    //   321	370	373	java/io/IOException
    //   479	569	373	java/io/IOException
    //   616	638	373	java/io/IOException
    //   448	452	471	java/io/IOException
    //   457	462	471	java/io/IOException
    //   466	470	471	java/io/IOException
    //   193	200	572	finally
    //   200	208	572	finally
    //   220	286	572	finally
    //   321	370	572	finally
    //   479	569	572	finally
    //   616	638	572	finally
    //   590	595	641	java/io/IOException
    //   600	605	641	java/io/IOException
    //   609	613	641	java/io/IOException
    //   2	19	651	finally
    //   19	60	664	finally
    //   60	143	675	finally
    //   183	190	675	finally
    //   382	444	691	finally
    //   2	19	707	java/io/IOException
    //   19	60	718	java/io/IOException
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.g
 * JD-Core Version:    0.6.2
 */