package com.service.usbhelper.c;

import android.os.Handler;
import android.os.Message;

class d extends Handler
{
  d(c paramc)
  {
  }

  public void handleMessage(Message paramMessage)
  {
    super.handleMessage(paramMessage);
    switch (paramMessage.what)
    {
    default:
    case 1003:
    case 1001:
    case 1000:
      do
      {
        do
        {
          return;
          c.h(this.a);
          return;
          c.a(this.a, (f)paramMessage.obj);
        }
        while (c.g(this.a) == null);
        c.g(this.a).b();
        return;
      }
      while (c.g(this.a) == null);
      c.g(this.a).a(((Long)paramMessage.obj).longValue());
      return;
    case 1002:
    }
    c.c(this.a, paramMessage.arg1);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.c.d
 * JD-Core Version:    0.6.2
 */