package com.service.usbhelper.data;

import com.service.usbhelper.db.TJBaseModel;
import java.util.ArrayList;

public class g
{
  public String a;
  public String b;
  public String c;
  public String d;
  public ArrayList<TJBaseModel> e = new ArrayList();

  public String a()
  {
    return this.d;
  }

  public String b()
  {
    return this.a;
  }

  public ArrayList<TJBaseModel> c()
  {
    return this.e;
  }

  public String d()
  {
    return this.b;
  }

  public String e()
  {
    return this.c;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.g
 * JD-Core Version:    0.6.2
 */