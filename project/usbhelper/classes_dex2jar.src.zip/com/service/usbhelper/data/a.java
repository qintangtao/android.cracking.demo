package com.service.usbhelper.data;

import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.text.TextUtils;
import com.service.usbhelper.d.f;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;
import com.service.usbhelper.db.TJBaseModel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class a
{
  private static Object a = new Object();
  private static String b;

  public static JSONObject a(int paramInt, Context paramContext, ArrayList<g> paramArrayList)
  {
    JSONObject localJSONObject1 = new JSONObject();
    try
    {
      localJSONObject1.put("header", a(paramContext));
      if ((paramArrayList != null) && (paramArrayList.size() != 0))
      {
        new ArrayList();
        JSONObject localJSONObject2 = new JSONObject();
        Iterator localIterator1 = paramArrayList.iterator();
        while (true)
        {
          boolean bool = localIterator1.hasNext();
          if (!bool)
          {
            j.b("USBHelper", "buildTjOtherInfo：" + paramInt + ">>>>>>>>" + localJSONObject1.toString());
            return localJSONObject1;
          }
          g localg = (g)localIterator1.next();
          if (!localg.a.equals("0729cb54090d48ac0d347aa5748e2330"))
          {
            localJSONObject3 = new JSONObject();
            localJSONArray1 = new JSONArray();
            localJSONArray2 = new JSONArray();
            ArrayList localArrayList = localg.c();
            if ((localArrayList != null) && (localArrayList.size() != 0))
            {
              localIterator2 = localArrayList.iterator();
              if (localIterator2.hasNext())
                break;
              if (((localJSONArray1.length() != 0) || (localJSONArray2.length() != 0)) && (!TextUtils.isEmpty(localg.b())))
              {
                JSONObject localJSONObject6 = new JSONObject();
                localJSONObject6.put("app_version", localg.d());
                localJSONObject6.put("appcid", localg.e());
                if ((paramInt != 1) || (localJSONArray1 == null) || (localJSONArray1.length() <= 0))
                  break label467;
                localJSONObject3.put("launch", localJSONArray1);
                localJSONObject3.put("appstate", localJSONObject6);
                localJSONObject2.put(localg.b(), localJSONObject3);
                localJSONObject1.put("body", localJSONObject2);
              }
            }
          }
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        JSONObject localJSONObject3;
        JSONArray localJSONArray1;
        JSONArray localJSONArray2;
        Iterator localIterator2;
        localException.printStackTrace();
        continue;
        TJBaseModel localTJBaseModel = (TJBaseModel)localIterator2.next();
        JSONObject localJSONObject4 = new JSONObject();
        JSONObject localJSONObject5 = new JSONObject();
        if (paramInt == 1)
        {
          if (localTJBaseModel.getStart_sended() == 0)
          {
            localJSONObject4.put("sessionid", localTJBaseModel.getSession_id());
            localJSONArray1.put(localJSONObject4);
          }
        }
        else
        {
          if (localTJBaseModel.getStart_sended() == 0)
          {
            localJSONObject4.put("sessionid", localTJBaseModel.getSession_id());
            localJSONArray1.put(localJSONObject4);
          }
          if (localTJBaseModel.getDuration() >= 0)
          {
            localJSONObject5.put("sessionid", localTJBaseModel.getSession_id());
            localJSONObject5.put("duration", localTJBaseModel.getDuration());
            localJSONArray2.put(localJSONObject5);
            continue;
            label467: if ((localJSONArray1 != null) && (localJSONArray1.length() > 0))
              localJSONObject3.put("launch", localJSONArray1);
            if ((localJSONArray2 != null) && (localJSONArray2.length() > 0))
            {
              localJSONObject3.put("terminate", localJSONArray2);
              continue;
              localJSONObject1.put("body", "");
            }
          }
        }
      }
    }
  }

  public static JSONObject a(Context paramContext)
  {
    String str1 = com.service.usbhelper.d.g.c(paramContext);
    long l = f.a();
    String str2 = com.service.usbhelper.d.c.b(paramContext);
    String str3 = com.service.usbhelper.d.g.a(paramContext);
    String str4 = m.d(paramContext);
    String str5 = com.service.usbhelper.d.g.b(paramContext);
    String str6 = Build.MODEL;
    String str7 = m.c(paramContext);
    String str8 = Build.VERSION.RELEASE;
    String str9 = com.service.usbhelper.d.g.d(paramContext);
    String str10 = Build.BRAND;
    String str11 = paramContext.getPackageName();
    String str12 = m.a(paramContext, "promotion_method");
    String str13 = m.f(paramContext);
    String str14 = m.a(paramContext);
    String str15 = m.e(paramContext);
    if (TextUtils.isEmpty(str15))
      str15 = "";
    String str16 = b;
    JSONObject localJSONObject;
    try
    {
      str17 = paramContext.getPackageManager().getPackageInfo(str11, 0).versionName;
      StringBuilder localStringBuilder = new StringBuilder(String.valueOf(paramContext.getPackageManager().getPackageInfo(str11, 0).versionCode));
      String str19 = localStringBuilder.toString();
      str18 = str19;
      localJSONObject = new JSONObject();
    }
    catch (Exception localException1)
    {
      try
      {
        localJSONObject.put("uid", str1);
        localJSONObject.put("android_id", str9);
        localJSONObject.put("send_time", l);
        localJSONObject.put("toolcid", str2);
        localJSONObject.put("brand", str10);
        localJSONObject.put("promotion_method", str12);
        localJSONObject.put("total_time", SystemClock.elapsedRealtime() / 1000L);
        if (TextUtils.isEmpty(str3))
          str3 = "";
        localJSONObject.put("app_version", str17);
        localJSONObject.put("version_code", str18);
        localJSONObject.put("imei", str3);
        localJSONObject.put("imsi", str4);
        localJSONObject.put("wmac", str5);
        localJSONObject.put("supplier", str13);
        localJSONObject.put("device_model", str6);
        localJSONObject.put("access", str7);
        localJSONObject.put("os_version", str8);
        localJSONObject.put("resolution", str14);
        localJSONObject.put("iccid", str15);
        localJSONObject.put("battery", str16);
        return localJSONObject;
        localException1 = localException1;
        String str17 = "";
        String str18 = "";
      }
      catch (Exception localException2)
      {
        localException2.printStackTrace();
      }
    }
    return localJSONObject;
  }

  public static JSONObject a(Context paramContext, int paramInt)
  {
    String str1 = com.service.usbhelper.d.g.c(paramContext);
    String str2 = m.c(paramContext);
    String str3 = paramContext.getPackageName();
    String str4 = Build.BRAND;
    String str5 = m.a(paramContext, "promotion_method");
    String str6 = m.f(paramContext);
    try
    {
      str7 = paramContext.getPackageManager().getPackageInfo(str3, 0).versionName;
      String str19 = paramContext.getPackageManager().getPackageInfo(str3, 0).versionCode;
      str8 = str19;
      str9 = Build.MODEL;
      str10 = Build.VERSION.RELEASE;
      str11 = m.a(paramContext);
      str12 = com.service.usbhelper.d.c.a(paramContext);
      if (TextUtils.isEmpty(str12))
        str12 = m.a(paramContext, "UMENG_CHANNEL");
      str13 = m.a(paramContext, "project_name");
      if (TextUtils.isEmpty(str13))
        str13 = paramContext.getPackageName();
      str14 = com.service.usbhelper.d.g.a(paramContext);
      str15 = m.d(paramContext);
      str16 = com.service.usbhelper.d.g.b(paramContext);
      str17 = com.service.usbhelper.d.c.b(paramContext);
      str18 = com.service.usbhelper.d.g.d(paramContext);
      localJSONObject1 = new JSONObject();
    }
    catch (Exception localException1)
    {
      try
      {
        String str9;
        String str10;
        String str11;
        String str12;
        String str13;
        String str14;
        String str15;
        String str16;
        String str17;
        String str18;
        JSONObject localJSONObject1;
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put("uid", str1);
        localJSONObject2.put("access", str2);
        localJSONObject2.put("package", str3);
        localJSONObject2.put("app_version", str7);
        localJSONObject2.put("version_code", str8);
        localJSONObject2.put("channel", str12);
        localJSONObject2.put("brand", str4);
        localJSONObject2.put("device_model", str9);
        localJSONObject2.put("android_id", str18);
        localJSONObject2.put("promotion_method", str5);
        localJSONObject2.put("total_time", SystemClock.elapsedRealtime() / 1000L);
        JSONObject localJSONObject3 = new JSONObject();
        localJSONObject3.put("imei", str14);
        localJSONObject3.put("imsi", str15);
        localJSONObject3.put("wmac", str16);
        localJSONObject2.put("local_id", localJSONObject3);
        localJSONObject2.put("os", "Android");
        localJSONObject2.put("os_version", str10);
        localJSONObject2.put("project_name", str13);
        localJSONObject2.put("resolution", str11);
        localJSONObject2.put("sdk_version", "u1.0");
        localJSONObject2.put("run_type", paramInt);
        localJSONObject2.put("toolcid", str17);
        localJSONObject2.put("supplier", str6);
        JSONObject localJSONObject4 = new JSONObject();
        localJSONObject4.put("launch", "");
        localJSONObject1.put("header", localJSONObject2);
        localJSONObject1.put("body", localJSONObject4);
        j.b("USBHelper", "统计模块自身信息：" + paramInt + ">>>>>>>>" + localJSONObject1.toString());
        return localJSONObject1;
        localException1 = localException1;
        String str7 = "";
        String str8 = "";
      }
      catch (Exception localException2)
      {
        while (true)
          localException2.printStackTrace();
      }
    }
  }

  public static JSONObject a(Context paramContext, int paramInt, String paramString)
  {
    JSONObject localJSONObject1 = a(paramContext, paramInt);
    j.b("song", "拉起日志header-----11111：" + localJSONObject1.toString());
    try
    {
      JSONObject localJSONObject2 = localJSONObject1.getJSONObject("header");
      localJSONObject2.put("src_package", paramString);
      localJSONObject1.put("header", localJSONObject2);
      j.b("song", "拉起日志header：" + localJSONObject1.toString());
      return localJSONObject1;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public static void a(int paramInt, Context paramContext)
  {
    if (!m.b(paramContext))
      return;
    new b(paramContext, paramInt).start();
  }

  public static void a(int paramInt, Context paramContext, String paramString)
  {
    if (!m.b(paramContext))
      return;
    new c(paramContext, paramInt, paramString).start();
  }

  public static void a(ArrayList<g> paramArrayList, Context paramContext)
  {
    if ((paramArrayList == null) || (!m.b(paramContext)) || (paramArrayList.size() == 0));
    while (true)
    {
      return;
      try
      {
        JSONObject localJSONObject1 = a(2, paramContext, paramArrayList);
        if (localJSONObject1.getJSONObject("body").length() > 0)
        {
          String str = com.service.usbhelper.c.h.a().a("http://app.50bang.org/tongji_module/?_c=log&action=session", "http://app.50bang.org/tongji_module/?_c=log&action=sendData", com.service.usbhelper.d.h.a(m.a(paramContext, "app_key"), localJSONObject1.toString()), paramContext);
          j.b("USBHelper", "sendTjOtherRunningInfo：>>>>>>>>" + str);
          if ((str != null) && (!TextUtils.isEmpty(str)))
          {
            JSONObject localJSONObject2 = new JSONObject(str);
            if (localJSONObject2.getLong("code") == 200L)
            {
              com.service.usbhelper.db.b.a(paramContext, paramArrayList);
              k.a(paramContext).edit().putLong("servertime", localJSONObject2.getJSONObject("data").getLong("st")).commit();
              Iterator localIterator = paramArrayList.iterator();
              while (localIterator.hasNext())
              {
                g localg = (g)localIterator.next();
                if (!TextUtils.isEmpty(localg.a()))
                {
                  k.a(paramContext, localg.a()).edit().clear().commit();
                  j.c("songyx", "xml第三方运行delete：" + localg.a());
                }
              }
            }
          }
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
  }

  public static ArrayList<g> b(Context paramContext)
  {
    List localList = com.service.usbhelper.d.c.d(paramContext, "watch_list");
    ArrayList localArrayList1 = com.service.usbhelper.db.b.a(paramContext);
    ArrayList localArrayList2 = new ArrayList();
    SharedPreferences localSharedPreferences1 = k.a(paramContext, "watch_list");
    while (true)
    {
      String str1;
      g localg;
      ArrayList localArrayList3;
      Iterator localIterator2;
      try
      {
        Iterator localIterator1 = localList.iterator();
        if (!localIterator1.hasNext())
          return localArrayList2;
        str1 = (String)localIterator1.next();
        localg = new g();
        String str2 = localSharedPreferences1.getString(str1, "");
        if ((str2 == null) || (TextUtils.isEmpty(str2)))
          break label360;
        String[] arrayOfString = str2.split(",");
        if (arrayOfString.length == 5)
        {
          j.b("拼接启动：" + str1);
          String str4 = arrayOfString[0];
          localg.c = arrayOfString[1];
          localg.b = arrayOfString[2];
          str3 = str4;
          localg.a = str3;
          localg.d = str1;
          localArrayList3 = new ArrayList();
          localIterator2 = localArrayList1.iterator();
          if (localIterator2.hasNext())
            break label381;
          SharedPreferences localSharedPreferences2 = k.a(paramContext, str1);
          if (localSharedPreferences2.getInt("app_is_start_sended", -1) == 0)
          {
            TJBaseModel localTJBaseModel2 = new TJBaseModel();
            localTJBaseModel2.appid = str3;
            localTJBaseModel2.duration = localSharedPreferences2.getInt("app_duration", -1);
            localTJBaseModel2.session_id = localSharedPreferences2.getInt("app_sessionid", 0);
            localTJBaseModel2.start_sended = localSharedPreferences2.getInt("app_is_start_sended", -1);
            localArrayList3.add(localTJBaseModel2);
          }
          if ((localArrayList3 == null) || (localArrayList3.size() == 0))
            continue;
          localg.e.addAll(localArrayList3);
          localArrayList2.add(localg);
          continue;
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return localArrayList2;
      }
      localg.c = "";
      localg.b = "";
      String str3 = "";
      continue;
      label360: localg.c = "";
      localg.b = "";
      str3 = "";
      continue;
      label381: TJBaseModel localTJBaseModel1 = (TJBaseModel)localIterator2.next();
      if (localTJBaseModel1.getPkgname().equals(str1))
        localArrayList3.add(localTJBaseModel1);
    }
  }

  public static JSONObject b(Context paramContext, int paramInt)
  {
    String str1 = com.service.usbhelper.d.g.c(paramContext);
    String str2 = m.c(paramContext);
    String str3 = paramContext.getPackageName();
    String str4 = Build.BRAND;
    String str5 = m.a(paramContext, "promotion_method");
    String str6 = m.f(paramContext);
    try
    {
      str7 = paramContext.getPackageManager().getPackageInfo(str3, 0).versionName;
      String str19 = paramContext.getPackageManager().getPackageInfo(str3, 0).versionCode;
      str8 = str19;
      str9 = Build.MODEL;
      str10 = Build.VERSION.RELEASE;
      str11 = m.a(paramContext);
      str12 = com.service.usbhelper.d.c.a(paramContext);
      if (TextUtils.isEmpty(str12))
        str12 = m.a(paramContext, "UMENG_CHANNEL");
      str13 = m.a(paramContext, "project_name");
      if (TextUtils.isEmpty(str13))
        str13 = paramContext.getPackageName();
      str14 = com.service.usbhelper.d.g.a(paramContext);
      str15 = m.d(paramContext);
      str16 = com.service.usbhelper.d.g.b(paramContext);
      str17 = com.service.usbhelper.d.c.b(paramContext);
      str18 = com.service.usbhelper.d.g.d(paramContext);
      localJSONObject1 = new JSONObject();
    }
    catch (Exception localException1)
    {
      try
      {
        String str9;
        String str10;
        String str11;
        String str12;
        String str13;
        String str14;
        String str15;
        String str16;
        String str17;
        String str18;
        JSONObject localJSONObject1;
        localJSONObject1.put("uid", str1);
        localJSONObject1.put("access", str2);
        localJSONObject1.put("package", str3);
        localJSONObject1.put("app_version", str7);
        localJSONObject1.put("version_code", str8);
        localJSONObject1.put("channel", str12);
        localJSONObject1.put("brand", str4);
        localJSONObject1.put("device_model", str9);
        localJSONObject1.put("android_id", str18);
        localJSONObject1.put("promotion_method", str5);
        localJSONObject1.put("total_time", SystemClock.elapsedRealtime() / 1000L);
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put("imei", str14);
        localJSONObject2.put("imsi", str15);
        localJSONObject2.put("wmac", str16);
        localJSONObject1.put("supplier", str6);
        localJSONObject1.put("local_id", localJSONObject2);
        localJSONObject1.put("os", "Android");
        localJSONObject1.put("os_version", str10);
        localJSONObject1.put("project_name", str13);
        localJSONObject1.put("resolution", str11);
        localJSONObject1.put("sdk_version", "u1.0");
        localJSONObject1.put("run_type", paramInt);
        localJSONObject1.put("toolcid", str17);
        j.b("USBHelper", "手机app 相关信息：" + paramInt + ">>>>>>>>" + localJSONObject1.toString());
        return localJSONObject1;
        localException1 = localException1;
        String str7 = "";
        String str8 = "";
      }
      catch (Exception localException2)
      {
        while (true)
          localException2.printStackTrace();
      }
    }
  }

  public static void b(ArrayList<g> paramArrayList, Context paramContext)
  {
    if ((paramArrayList == null) || (!m.b(paramContext)) || (paramArrayList.size() == 0))
      return;
    new d(paramContext, paramArrayList).start();
  }

  public static ArrayList<g> c(Context paramContext)
  {
    List localList = com.service.usbhelper.d.c.d(paramContext, "watch_list");
    ArrayList localArrayList1 = com.service.usbhelper.db.b.b(paramContext);
    j.a("getAllInfo tjBaseModels:" + localArrayList1.toString());
    ArrayList localArrayList2 = new ArrayList();
    SharedPreferences localSharedPreferences1 = k.a(paramContext, "watch_list");
    try
    {
      Iterator localIterator1 = localList.iterator();
      while (true)
      {
        boolean bool = localIterator1.hasNext();
        if (!bool)
        {
          j.a("getOtherRunningInfo: bodys" + localArrayList2.toString());
          return localArrayList2;
        }
        str1 = (String)localIterator1.next();
        localg = new g();
        String str2 = localSharedPreferences1.getString(str1, "");
        if ((str2 == null) || (TextUtils.isEmpty(str2)))
          break label384;
        String[] arrayOfString = str2.split(",");
        if (arrayOfString.length != 5)
          break;
        String str4 = arrayOfString[0];
        localg.c = arrayOfString[1];
        localg.b = arrayOfString[2];
        str3 = str4;
        localg.a = str3;
        localg.d = str1;
        localArrayList3 = new ArrayList();
        localIterator2 = localArrayList1.iterator();
        if (localIterator2.hasNext())
          break label405;
        SharedPreferences localSharedPreferences2 = k.a(paramContext, str1);
        TJBaseModel localTJBaseModel2 = new TJBaseModel();
        localTJBaseModel2.appid = str3;
        localTJBaseModel2.duration = localSharedPreferences2.getInt("app_duration", -1);
        localTJBaseModel2.session_id = localSharedPreferences2.getInt("app_sessionid", 0);
        localTJBaseModel2.start_sended = localSharedPreferences2.getInt("app_is_start_sended", -1);
        if (localTJBaseModel2.session_id > 0)
          localArrayList3.add(localTJBaseModel2);
        if ((localArrayList3 != null) && (localArrayList3.size() != 0))
        {
          localg.e.addAll(localArrayList3);
          localArrayList2.add(localg);
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        String str1;
        g localg;
        ArrayList localArrayList3;
        Iterator localIterator2;
        localException.printStackTrace();
        continue;
        localg.c = "";
        localg.b = "";
        String str3 = "";
        continue;
        label384: localg.c = "";
        localg.b = "";
        str3 = "";
        continue;
        label405: TJBaseModel localTJBaseModel1 = (TJBaseModel)localIterator2.next();
        if (localTJBaseModel1.getPkgname().equals(str1))
          localArrayList3.add(localTJBaseModel1);
      }
    }
  }

  public static void d(Context paramContext)
  {
    paramContext.registerReceiver(new e(), new IntentFilter("android.intent.action.BATTERY_CHANGED"));
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.a
 * JD-Core Version:    0.6.2
 */