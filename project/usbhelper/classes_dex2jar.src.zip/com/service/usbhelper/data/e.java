package com.service.usbhelper.data;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class e extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    int i = 100;
    paramContext.unregisterReceiver(this);
    int j = paramIntent.getIntExtra("level", -1);
    if (j >= 0)
    {
      if (j > i);
      while (true)
      {
        a.a(i);
        synchronized (a.a())
        {
          a.a().notify();
          return;
        }
        i = j;
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.e
 * JD-Core Version:    0.6.2
 */