package com.service.usbhelper.data;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.service.usbhelper.d.k;
import org.json.JSONObject;

class j extends Thread
{
  j(UnionAppDataService paramUnionAppDataService, String paramString)
  {
  }

  public void run()
  {
    try
    {
      Thread.sleep(2000L);
      try
      {
        SharedPreferences localSharedPreferences = k.a(this.a, "union_app_list");
        if (localSharedPreferences.getString(this.b, "empty").equals("empty"))
          return;
        JSONObject localJSONObject = i.b(this.a, this.b);
        if (localJSONObject != null)
        {
          String str = com.service.usbhelper.c.h.a().a("http://app.50bang.org/api/?api=soft_zhushou_singleApk", com.service.usbhelper.d.h.a("NeA==Sv#i8wMDg.G9+M#j30M08rVst0", localJSONObject.toString()), this.a);
          if ((str != null) && (new JSONObject(str).getInt("code") == 0))
            localSharedPreferences.edit().putString(this.b, "empty").commit();
          com.service.usbhelper.d.j.b("diff", "联盟软件清单数据返回值：>>>>>>>>" + str);
        }
        return;
      }
      finally
      {
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      return;
    }
    finally
    {
      this.a.stopSelf();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.j
 * JD-Core Version:    0.6.2
 */