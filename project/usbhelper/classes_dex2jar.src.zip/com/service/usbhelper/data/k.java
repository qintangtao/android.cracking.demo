package com.service.usbhelper.data;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.service.usbhelper.d.c;
import com.service.usbhelper.d.j;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

class k extends Thread
{
  k(UnionAppDataService paramUnionAppDataService)
  {
  }

  public void run()
  {
    try
    {
      Thread.sleep(5000L);
      j.a("diff", "sendUnionAppData");
      try
      {
        localList = c.d(this.a, "union_app_list");
        SharedPreferences localSharedPreferences = com.service.usbhelper.d.k.a(this.a);
        if (localSharedPreferences.getBoolean("is_unionapp_sended", false));
        while (true)
        {
          return;
          localSharedPreferences.edit().putBoolean("is_unionapp_sended", true).commit();
          if ((localList != null) && (localList.size() != 0))
            break;
          this.a.stopSelf();
        }
      }
      finally
      {
      }
    }
    catch (Exception localException)
    {
      List localList;
      localException.printStackTrace();
      return;
      j.a("diff", "w:" + localList.size());
      Iterator localIterator = localList.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
          return;
        String str1 = (String)localIterator.next();
        if (!com.service.usbhelper.d.k.a(this.a, "union_app_list").getString(str1, "empty").equals("empty"))
        {
          String str2 = com.service.usbhelper.c.h.a().a("http://app.50bang.org/api/?api=soft_zhushou_singleApk", com.service.usbhelper.d.h.a("NeA==Sv#i8wMDg.G9+M#j30M08rVst0", i.b(this.a, str1).toString()), this.a);
          if ((str2 != null) && (new JSONObject(str2).getInt("code") == 0))
            com.service.usbhelper.d.k.a(this.a, "union_app_list").edit().putString(str1, "empty").commit();
          j.b("diff", "联盟软件清单数据返回值：>>>>>>>>" + str2);
        }
      }
    }
    finally
    {
      this.a.stopSelf();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.k
 * JD-Core Version:    0.6.2
 */