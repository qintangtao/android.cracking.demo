package com.service.usbhelper.data;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.service.usbhelper.d.c;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

class l extends Thread
{
  l(UnionAppDataService paramUnionAppDataService)
  {
  }

  public void run()
  {
    try
    {
      j.a("diff", "sendOmitUnionAppData");
      try
      {
        List localList = c.d(this.a, "union_app_list");
        SharedPreferences localSharedPreferences = k.a(this.a, "union_app_list");
        if ((localList == null) || (localList.size() == 0))
        {
          this.a.stopSelf();
          return;
        }
        j.a("diff", "omit:");
        Iterator localIterator = localList.iterator();
        while (true)
        {
          if (!localIterator.hasNext())
            return;
          String str1 = (String)localIterator.next();
          if (!localSharedPreferences.getString(str1, "empty").equals("empty"))
          {
            String str2 = com.service.usbhelper.c.h.a().a("http://app.50bang.org/api/?api=soft_zhushou_singleApk", com.service.usbhelper.d.h.a("NeA==Sv#i8wMDg.G9+M#j30M08rVst0", i.b(this.a, str1).toString()), this.a);
            if ((str2 != null) && (new JSONObject(str2).getInt("code") == 0))
              localSharedPreferences.edit().putString(str1, "empty").commit();
            j.b("diff", "联盟软件清单数据返回值：>>>>>>>>" + str2);
          }
        }
      }
      finally
      {
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      return;
    }
    finally
    {
      this.a.stopSelf();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.l
 * JD-Core Version:    0.6.2
 */