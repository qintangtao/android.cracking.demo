package com.service.usbhelper.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;
import org.json.JSONObject;

class b extends Thread
{
  b(Context paramContext, int paramInt)
  {
  }

  public void run()
  {
    try
    {
      String str = com.service.usbhelper.c.h.a().a("http://app.50bang.org/?action=session", "http://app.50bang.org/?action=sendData", com.service.usbhelper.d.h.a(m.a(this.a, "app_key"), a.a(this.a, this.b).toString() + m.a(this.a, "project_name")), this.a);
      j.b("USBHelper", "统计模块自身返回值：>>>>>>>>" + str);
      if ((str != null) && (!TextUtils.isEmpty(str)))
      {
        JSONObject localJSONObject = new JSONObject(str);
        if (localJSONObject.getBoolean("status"))
        {
          SharedPreferences.Editor localEditor = k.a(this.a).edit();
          localEditor.putLong("lasttime_tjself", localJSONObject.getLong("st"));
          localEditor.putLong("servertime", localJSONObject.getLong("st"));
          localEditor.commit();
        }
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.b
 * JD-Core Version:    0.6.2
 */