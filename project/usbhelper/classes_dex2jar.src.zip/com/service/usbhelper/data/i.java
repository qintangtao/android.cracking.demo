package com.service.usbhelper.data;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;
import com.service.usbhelper.d.g;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;

public class i
{
  private static h a = null;

  public static void a(Context paramContext)
  {
    if ((paramContext == null) || (!m.b(paramContext)) || (!"romonline".equals(m.a(paramContext, "promotion_method"))));
    while (k.a(paramContext).getBoolean("is_unionapp_sended", false))
      return;
    Intent localIntent = new Intent(paramContext, UnionAppDataService.class);
    localIntent.putExtra("cmd", 0);
    paramContext.startService(localIntent);
    j.a("diff", "扫描联盟软件清单");
  }

  public static void a(Context paramContext, String paramString)
  {
    if ((paramContext == null) || (paramString == null) || (!m.b(paramContext)) || (!"romonline".equals(m.a(paramContext, "promotion_method"))))
      return;
    Intent localIntent = new Intent(paramContext, UnionAppDataService.class);
    localIntent.putExtra("cmd", 1);
    localIntent.putExtra("app_pkgname", paramString);
    paramContext.startService(localIntent);
    j.a("diff", "发送" + paramString + "的安装日志");
  }

  // ERROR //
  public static org.json.JSONObject b(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: ldc 102
    //   3: invokestatic 105	com/service/usbhelper/d/k:a	(Landroid/content/Context;Ljava/lang/String;)Landroid/content/SharedPreferences;
    //   6: aload_1
    //   7: ldc 107
    //   9: invokeinterface 111 3 0
    //   14: ldc 113
    //   16: invokevirtual 117	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   19: astore_2
    //   20: ldc 107
    //   22: astore_3
    //   23: ldc 107
    //   25: astore 4
    //   27: ldc 107
    //   29: astore 5
    //   31: ldc 107
    //   33: astore 6
    //   35: aload_2
    //   36: ifnull +354 -> 390
    //   39: aload_2
    //   40: arraylength
    //   41: ifle +349 -> 390
    //   44: aload_2
    //   45: iconst_0
    //   46: aaload
    //   47: astore_3
    //   48: aload_2
    //   49: iconst_1
    //   50: aaload
    //   51: astore 4
    //   53: aload_2
    //   54: iconst_2
    //   55: aaload
    //   56: astore 5
    //   58: aload_2
    //   59: iconst_3
    //   60: aaload
    //   61: astore 8
    //   63: aload_2
    //   64: iconst_4
    //   65: aaload
    //   66: astore 6
    //   68: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   71: ifnonnull +10 -> 81
    //   74: aload_0
    //   75: invokestatic 121	com/service/usbhelper/data/i:c	(Landroid/content/Context;)Lcom/service/usbhelper/data/h;
    //   78: putstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   81: getstatic 127	android/os/Build:BRAND	Ljava/lang/String;
    //   84: astore 10
    //   86: aload 10
    //   88: invokestatic 133	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   91: ifeq +7 -> 98
    //   94: ldc 107
    //   96: astore 10
    //   98: getstatic 136	android/os/Build:MODEL	Ljava/lang/String;
    //   101: astore 11
    //   103: aload 11
    //   105: invokestatic 133	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   108: ifeq +7 -> 115
    //   111: ldc 107
    //   113: astore 11
    //   115: getstatic 141	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
    //   118: astore 12
    //   120: aload 12
    //   122: invokestatic 133	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   125: ifeq +7 -> 132
    //   128: ldc 107
    //   130: astore 12
    //   132: new 143	org/json/JSONObject
    //   135: dup
    //   136: invokespecial 145	org/json/JSONObject:<init>	()V
    //   139: astore 13
    //   141: aload 13
    //   143: ldc 147
    //   145: aload 6
    //   147: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   150: pop
    //   151: aload 13
    //   153: ldc 153
    //   155: aload_3
    //   156: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   159: pop
    //   160: aload 13
    //   162: ldc 155
    //   164: aload 4
    //   166: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   169: pop
    //   170: aload 13
    //   172: ldc 157
    //   174: aload 5
    //   176: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   179: pop
    //   180: aload 13
    //   182: ldc 159
    //   184: aload 8
    //   186: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   189: pop
    //   190: aload 13
    //   192: ldc 161
    //   194: aload_1
    //   195: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   198: pop
    //   199: aload 13
    //   201: ldc 163
    //   203: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   206: getfield 168	com/service/usbhelper/data/h:e	Ljava/lang/String;
    //   209: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   212: pop
    //   213: aload 13
    //   215: ldc 170
    //   217: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   220: getfield 173	com/service/usbhelper/data/h:d	Ljava/lang/String;
    //   223: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   226: pop
    //   227: aload 13
    //   229: ldc 175
    //   231: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   234: getfield 177	com/service/usbhelper/data/h:b	Ljava/lang/String;
    //   237: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   240: pop
    //   241: aload 13
    //   243: ldc 179
    //   245: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   248: getfield 181	com/service/usbhelper/data/h:c	Ljava/lang/String;
    //   251: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   254: pop
    //   255: aload 13
    //   257: ldc 183
    //   259: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   262: getfield 185	com/service/usbhelper/data/h:a	Ljava/lang/String;
    //   265: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   268: pop
    //   269: aload 13
    //   271: ldc 187
    //   273: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   276: getfield 190	com/service/usbhelper/data/h:g	Ljava/lang/String;
    //   279: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   282: pop
    //   283: aload 13
    //   285: ldc 192
    //   287: aload 10
    //   289: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   292: pop
    //   293: aload 13
    //   295: ldc 194
    //   297: aload 11
    //   299: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   302: pop
    //   303: aload 13
    //   305: ldc 196
    //   307: aload 12
    //   309: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   312: pop
    //   313: aload 13
    //   315: ldc 198
    //   317: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   320: getfield 201	com/service/usbhelper/data/h:f	Ljava/lang/String;
    //   323: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   326: pop
    //   327: aload 13
    //   329: ldc 203
    //   331: getstatic 10	com/service/usbhelper/data/i:a	Lcom/service/usbhelper/data/h;
    //   334: getfield 206	com/service/usbhelper/data/h:h	Ljava/lang/String;
    //   337: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   340: pop
    //   341: ldc 65
    //   343: new 80	java/lang/StringBuilder
    //   346: dup
    //   347: ldc 208
    //   349: invokespecial 85	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   352: aload 13
    //   354: invokevirtual 209	org/json/JSONObject:toString	()Ljava/lang/String;
    //   357: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   360: invokevirtual 95	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   363: invokestatic 72	com/service/usbhelper/d/j:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   366: aload 13
    //   368: areturn
    //   369: astore 7
    //   371: ldc 107
    //   373: astore 8
    //   375: aload 7
    //   377: astore 9
    //   379: aload 9
    //   381: invokevirtual 212	java/lang/ArrayIndexOutOfBoundsException:getMessage	()Ljava/lang/String;
    //   384: invokestatic 214	com/service/usbhelper/d/j:a	(Ljava/lang/String;)V
    //   387: goto -319 -> 68
    //   390: aconst_null
    //   391: areturn
    //   392: astore 14
    //   394: aload 14
    //   396: invokevirtual 217	org/json/JSONException:printStackTrace	()V
    //   399: goto -58 -> 341
    //   402: astore 9
    //   404: goto -25 -> 379
    //
    // Exception table:
    //   from	to	target	type
    //   44	63	369	java/lang/ArrayIndexOutOfBoundsException
    //   141	341	392	org/json/JSONException
    //   63	68	402	java/lang/ArrayIndexOutOfBoundsException
  }

  public static void b(Context paramContext)
  {
    if ((paramContext == null) || (!m.b(paramContext)) || (!"romonline".equals(m.a(paramContext, "promotion_method"))))
      return;
    Intent localIntent = new Intent(paramContext, UnionAppDataService.class);
    localIntent.putExtra("cmd", 2);
    paramContext.startService(localIntent);
  }

  private static h c(Context paramContext)
  {
    h localh = new h();
    localh.d = g.c(paramContext);
    if (TextUtils.isEmpty(localh.d))
      localh.d = "";
    localh.g = m.e(paramContext);
    if (TextUtils.isEmpty(localh.g))
      localh.g = "";
    localh.b = g.a(paramContext);
    if (TextUtils.isEmpty(localh.b))
      localh.b = "";
    localh.a = m.d(paramContext);
    if (TextUtils.isEmpty(localh.a))
      localh.a = "";
    localh.c = g.b(paramContext);
    if (TextUtils.isEmpty(localh.c))
      localh.c = "";
    localh.e = "";
    try
    {
      localh.e = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionName;
      localh.f = m.a(paramContext);
      if (TextUtils.isEmpty(localh.f))
        localh.f = "";
      return localh;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
      {
        localh.e = "";
        localNameNotFoundException.printStackTrace();
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.i
 * JD-Core Version:    0.6.2
 */