package com.service.usbhelper.data;

import android.content.Context;
import android.os.Build;
import android.os.Build.VERSION;
import android.text.TextUtils;
import com.service.usbhelper.d.g;
import com.service.usbhelper.d.m;
import org.json.JSONException;
import org.json.JSONObject;

public class f
{
  public static JSONObject a(Context paramContext)
  {
    String str1 = g.a(paramContext);
    if (TextUtils.isEmpty(str1))
      str1 = "";
    String str2 = m.d(paramContext);
    if (TextUtils.isEmpty(str2))
      str2 = "";
    String str3 = g.b(paramContext);
    if (TextUtils.isEmpty(str3))
      str3 = "";
    String str4 = m.e(paramContext);
    if (TextUtils.isEmpty(str4))
      str4 = "";
    int i = Build.VERSION.SDK_INT;
    String str5 = Build.VERSION.RELEASE;
    if (TextUtils.isEmpty(str5))
      str5 = "";
    String str6 = m.a(paramContext);
    if (TextUtils.isEmpty(str6))
      str6 = "";
    String str7 = m.c(paramContext);
    if (TextUtils.isEmpty(str7))
      str7 = "";
    String str8 = Build.MODEL;
    if (TextUtils.isEmpty(str8))
      str8 = "";
    String str9 = Build.BRAND;
    if (TextUtils.isEmpty(str9))
      str9 = "";
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("IMEI", str1);
      localJSONObject.put("IMSI", str2);
      localJSONObject.put("MAC", str3);
      localJSONObject.put("SIM", str4);
      localJSONObject.put("SDKVERSION", i);
      localJSONObject.put("osVersion", str5);
      localJSONObject.put("resolution", str6);
      localJSONObject.put("access", str7);
      localJSONObject.put("phonemodel", str8);
      localJSONObject.put("manufacture", str9);
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
    return localJSONObject;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.f
 * JD-Core Version:    0.6.2
 */