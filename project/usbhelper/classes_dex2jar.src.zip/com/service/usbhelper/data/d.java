package com.service.usbhelper.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;
import com.service.usbhelper.db.b;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;

class d extends Thread
{
  d(Context paramContext, ArrayList paramArrayList)
  {
  }

  public void run()
  {
    JSONObject localJSONObject2;
    do
    {
      String str;
      do
      {
        JSONObject localJSONObject1;
        try
        {
          a.d(this.a);
          synchronized (a.a())
          {
            a.a().wait();
            localJSONObject1 = a.a(1, this.a, this.b);
            int i = localJSONObject1.getJSONObject("body").length();
            if (i <= 0)
              return;
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          return;
        }
        str = com.service.usbhelper.c.h.a().a("http://app.50bang.org/tongji_module/?_c=log&action=session", "http://app.50bang.org/tongji_module/?_c=log&action=sendData", com.service.usbhelper.d.h.a(m.a(this.a, "app_key"), localJSONObject1.toString()), this.a);
        j.b("USBHelper", "第三方程序启动返回值：>>>>>>>>" + str);
      }
      while ((str == null) || (TextUtils.isEmpty(str)));
      localJSONObject2 = new JSONObject(str);
    }
    while (localJSONObject2.getLong("code") != 200L);
    b.b(this.a, this.b);
    k.a(this.a).edit().putLong("servertime", localJSONObject2.getJSONObject("data").getLong("st")).commit();
    Iterator localIterator = this.b.iterator();
    while (localIterator.hasNext())
    {
      g localg = (g)localIterator.next();
      if (!TextUtils.isEmpty(localg.a()))
      {
        k.a(this.a, localg.a()).edit().putInt("app_is_start_sended", 1).commit();
        j.c("songyx", "xml第三方启动update：" + localg.a());
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.d
 * JD-Core Version:    0.6.2
 */