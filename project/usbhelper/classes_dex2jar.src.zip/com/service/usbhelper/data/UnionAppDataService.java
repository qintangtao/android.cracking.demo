package com.service.usbhelper.data;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;
import com.service.usbhelper.d.n;

public class UnionAppDataService extends Service
{
  private void a()
  {
    n.a(new k(this));
  }

  private void a(String paramString)
  {
    if (TextUtils.isEmpty(paramString))
      return;
    n.a(new j(this, paramString));
  }

  private void b()
  {
    n.a(new l(this));
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    super.onCreate();
  }

  public void onDestroy()
  {
    super.onDestroy();
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    com.service.usbhelper.d.j.a("diff", "sendUnionAppData" + paramIntent.getIntExtra("cmd", -1));
    switch (paramIntent.getIntExtra("cmd", -1))
    {
    default:
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      return super.onStartCommand(paramIntent, paramInt1, paramInt2);
      a();
      continue;
      a(paramIntent.getStringExtra("app_pkgname"));
      continue;
      b();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.data.UnionAppDataService
 * JD-Core Version:    0.6.2
 */