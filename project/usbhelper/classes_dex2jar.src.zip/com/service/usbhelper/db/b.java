package com.service.usbhelper.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import com.service.usbhelper.d.j;
import com.service.usbhelper.data.g;
import java.util.ArrayList;
import java.util.Iterator;

public class b
{
  // ERROR //
  public static long a(Context paramContext, ContentValues paramContentValues)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic 13	com/service/usbhelper/db/a:a	(Landroid/content/Context;)Lcom/service/usbhelper/db/a;
    //   4: invokevirtual 17	com/service/usbhelper/db/a:getWritableDatabase	()Landroid/database/sqlite/SQLiteDatabase;
    //   7: astore 6
    //   9: aload 6
    //   11: ldc 19
    //   13: aconst_null
    //   14: aload_1
    //   15: invokevirtual 25	android/database/sqlite/SQLiteDatabase:insert	(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   18: lstore 7
    //   20: lload 7
    //   22: lstore_3
    //   23: aload 6
    //   25: invokevirtual 29	android/database/sqlite/SQLiteDatabase:close	()V
    //   28: lload_3
    //   29: lreturn
    //   30: astore_2
    //   31: ldc2_w 30
    //   34: lstore_3
    //   35: aload_2
    //   36: astore 5
    //   38: aload 5
    //   40: invokevirtual 34	java/lang/Exception:printStackTrace	()V
    //   43: lload_3
    //   44: lreturn
    //   45: astore 5
    //   47: goto -9 -> 38
    //
    // Exception table:
    //   from	to	target	type
    //   0	20	30	java/lang/Exception
    //   23	28	45	java/lang/Exception
  }

  public static ArrayList<TJBaseModel> a(Context paramContext)
  {
    try
    {
      ArrayList localArrayList = new ArrayList();
      try
      {
        SQLiteDatabase localSQLiteDatabase = a.a(paramContext).getReadableDatabase();
        Cursor localCursor = localSQLiteDatabase.query("usbhelper", new String[] { "usbhelper_appid", "usbhelper_session", "usbhelper_duration", "usbhelper_package_name" }, "usbhelper_is_start_sended = 0", null, null, null, null);
        int i;
        int j;
        int k;
        int m;
        if ((localCursor != null) && (localCursor.getCount() > 0))
        {
          i = localCursor.getColumnIndex("usbhelper_appid");
          j = localCursor.getColumnIndex("usbhelper_session");
          k = localCursor.getColumnIndex("usbhelper_duration");
          m = localCursor.getColumnIndex("usbhelper_package_name");
        }
        while (true)
        {
          if (!localCursor.moveToNext())
          {
            if (localCursor != null)
              localCursor.close();
            localSQLiteDatabase.close();
            j.c("song", localArrayList.toString());
            return localArrayList;
          }
          TJBaseModel localTJBaseModel = new TJBaseModel();
          String str1 = localCursor.getString(i);
          int n = localCursor.getInt(j);
          int i1 = localCursor.getInt(k);
          String str2 = localCursor.getString(m);
          localTJBaseModel.appid = str1;
          localTJBaseModel.session_id = n;
          localTJBaseModel.duration = i1;
          localTJBaseModel.pkgname = str2;
          localArrayList.add(localTJBaseModel);
        }
      }
      catch (Exception localException)
      {
        while (true)
          localException.printStackTrace();
      }
    }
    finally
    {
    }
  }

  public static void a(Context paramContext, ArrayList<g> paramArrayList)
  {
    if ((paramArrayList == null) || (paramArrayList.size() == 0))
      return;
    while (true)
    {
      StringBuilder localStringBuilder;
      int i;
      try
      {
        SQLiteDatabase localSQLiteDatabase = a.a(paramContext).getWritableDatabase();
        localStringBuilder = new StringBuilder();
        localStringBuilder.append("(");
        i = 0;
        if (i >= paramArrayList.size())
        {
          localStringBuilder.append(")");
          if (localStringBuilder.toString().length() <= 2)
            break;
          int j = localSQLiteDatabase.delete("usbhelper", "usbhelper_package_name in " + localStringBuilder.toString(), null);
          j.c("songyx", "数据库第三方运行delete：usbhelper_package_name in " + localStringBuilder.toString());
          j.c("songyx", "数据库第三方运行delete：共" + j + "条");
          localSQLiteDatabase.close();
          return;
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        j.c("songyx", "数据库第三方运行delete：exception");
        return;
      }
      if (!TextUtils.isEmpty(((g)paramArrayList.get(i)).a()))
      {
        localStringBuilder.append("'").append(((g)paramArrayList.get(i)).a()).append("'");
        if (i != -1 + paramArrayList.size())
          localStringBuilder.append(",");
        j.c("songyx", "数据库第三方运行delete：" + ((g)paramArrayList.get(i)).a());
      }
      i++;
    }
  }

  public static void a(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS usbhelper");
    b(paramSQLiteDatabase);
  }

  public static ArrayList<TJBaseModel> b(Context paramContext)
  {
    try
    {
      ArrayList localArrayList = new ArrayList();
      try
      {
        SQLiteDatabase localSQLiteDatabase = a.a(paramContext).getReadableDatabase();
        Cursor localCursor = localSQLiteDatabase.query("usbhelper", new String[] { "usbhelper_appid", "usbhelper_session", "usbhelper_duration", "usbhelper_package_name", "usbhelper_is_start_sended" }, null, null, null, null, null, null);
        int i;
        int j;
        int k;
        int m;
        int n;
        if ((localCursor != null) && (localCursor.getCount() > 0))
        {
          i = localCursor.getColumnIndex("usbhelper_appid");
          j = localCursor.getColumnIndex("usbhelper_session");
          k = localCursor.getColumnIndex("usbhelper_duration");
          m = localCursor.getColumnIndex("usbhelper_package_name");
          n = localCursor.getColumnIndex("usbhelper_is_start_sended");
        }
        while (true)
        {
          if (!localCursor.moveToNext())
          {
            if (localCursor != null)
              localCursor.close();
            localSQLiteDatabase.close();
            return localArrayList;
          }
          TJBaseModel localTJBaseModel = new TJBaseModel();
          String str1 = localCursor.getString(i);
          int i1 = localCursor.getInt(j);
          int i2 = localCursor.getInt(k);
          String str2 = localCursor.getString(m);
          if ((i1 > 0) && (i2 >= 0) && (!TextUtils.isEmpty(str1)))
          {
            localTJBaseModel.appid = str1;
            localTJBaseModel.session_id = i1;
            localTJBaseModel.duration = i2;
            localTJBaseModel.pkgname = str2;
            localTJBaseModel.start_sended = localCursor.getInt(n);
            localArrayList.add(localTJBaseModel);
          }
        }
      }
      catch (Exception localException)
      {
        while (true)
          localException.printStackTrace();
      }
    }
    finally
    {
    }
  }

  public static void b(Context paramContext, ArrayList<g> paramArrayList)
  {
    try
    {
      SQLiteDatabase localSQLiteDatabase = a.a(paramContext).getWritableDatabase();
      ContentValues localContentValues = new ContentValues();
      localContentValues.put("usbhelper_is_start_sended", Integer.valueOf(1));
      Iterator localIterator = paramArrayList.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
        {
          localSQLiteDatabase.close();
          return;
        }
        g localg = (g)localIterator.next();
        if (!TextUtils.isEmpty(localg.a()))
        {
          String[] arrayOfString = new String[1];
          arrayOfString[0] = localg.a();
          int i = localSQLiteDatabase.update("usbhelper", localContentValues, "usbhelper_package_name = ? ", arrayOfString);
          j.c("songyx", "数据库第三方启动update：sql:" + localContentValues + "\t body:" + localg.a() + "\n update count==" + i);
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
    finally
    {
    }
  }

  public static void b(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS usbhelper(_id INTEGER PRIMARY KEY AUTOINCREMENT, usbhelper_session text NOT NULL UNIQUE, usbhelper_duration text default 0 ,usbhelper_appid text default 0 , usbhelper_package_name text , usbhelper_is_start_sended text default 0  ) ");
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.db.b
 * JD-Core Version:    0.6.2
 */