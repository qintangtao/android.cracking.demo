package com.service.usbhelper.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class a extends SQLiteOpenHelper
{
  private static a a;

  private a(Context paramContext)
  {
    super(paramContext, "usbhelper.db", null, 1);
  }

  public static a a(Context paramContext)
  {
    try
    {
      if (a == null)
        a = new a(paramContext);
      a locala = a;
      return locala;
    }
    finally
    {
    }
  }

  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    b.b(paramSQLiteDatabase);
  }

  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
    b.a(paramSQLiteDatabase);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.db.a
 * JD-Core Version:    0.6.2
 */