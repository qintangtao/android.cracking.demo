package com.service.usbhelper.db;

public class TJBaseModel
{
  public String appid;
  public int duration;
  public long end;
  public String pkgname;
  public int session_id;
  public long start;
  public int start_sended;

  public String getAppid()
  {
    return this.appid;
  }

  public int getDuration()
  {
    return this.duration;
  }

  public long getEnd()
  {
    return this.end;
  }

  public String getPkgname()
  {
    return this.pkgname;
  }

  public int getSession_id()
  {
    return this.session_id;
  }

  public long getStart()
  {
    return this.start;
  }

  public int getStart_sended()
  {
    return this.start_sended;
  }

  public void setAppid(String paramString)
  {
    this.appid = paramString;
  }

  public void setDuration(int paramInt)
  {
    this.duration = paramInt;
  }

  public void setEnd(long paramLong)
  {
    this.end = paramLong;
  }

  public void setPkgname(String paramString)
  {
    this.pkgname = paramString;
  }

  public void setSession_id(int paramInt)
  {
    this.session_id = paramInt;
  }

  public void setStart(long paramLong)
  {
    this.start = paramLong;
  }

  public void setStart_sended(int paramInt)
  {
    this.start_sended = paramInt;
  }

  public String toString()
  {
    return "sessiondi:" + this.session_id + "\t pkgname:" + this.pkgname + "\t duration:" + this.duration;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.db.TJBaseModel
 * JD-Core Version:    0.6.2
 */