package com.service.usbhelper.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build;
import android.os.Build.VERSION;
import android.text.TextUtils;
import com.service.usbhelper.d.f;
import com.service.usbhelper.d.g;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;
import org.json.JSONException;
import org.json.JSONObject;

public class a
{
  public static c a;
  public static boolean b = false;

  public static void a(Context paramContext)
  {
    boolean bool = k.a(paramContext).getBoolean("is_arrival_sended", false);
    if ((!"rom".equals(m.a(paramContext, "promotion_method"))) || (bool) || (!m.g(paramContext)))
      return;
    j.a("diff", "setArrivalSendTimer");
    j.a("diff", "is_sended:" + k.a(paramContext).getBoolean("is_arrival_send_fail", false));
    a = new c(paramContext);
    a.start();
  }

  public static void b(Context paramContext)
  {
    if ((paramContext == null) || (k.a(paramContext).getBoolean("is_arrival_sended", false)) || (b))
      return;
    if (!m.b(paramContext))
    {
      SharedPreferences.Editor localEditor = k.a(paramContext).edit();
      localEditor.putBoolean("is_arrival_send_fail", true);
      localEditor.commit();
      return;
    }
    new b(paramContext).start();
    j.a("diff", "sendArrivalData");
  }

  public static JSONObject c(Context paramContext)
  {
    int i = f.a();
    String str1 = g.c(paramContext);
    if (TextUtils.isEmpty(str1))
      str1 = "";
    String str2 = com.service.usbhelper.d.c.a(paramContext);
    if (TextUtils.isEmpty(str2))
      str2 = m.a(paramContext, "UMENG_CHANNEL");
    if (TextUtils.isEmpty(str2))
      str2 = "";
    String str3 = m.f(paramContext);
    if (TextUtils.isEmpty(str3))
      str3 = "";
    String str4 = g.a(paramContext);
    if (TextUtils.isEmpty(str4))
      str4 = "";
    String str5 = m.d(paramContext);
    if (TextUtils.isEmpty(str5))
      str5 = "";
    String str6 = g.b(paramContext);
    if (TextUtils.isEmpty(str6))
      str6 = "";
    String str7 = Build.BRAND;
    if (TextUtils.isEmpty(str7))
      str7 = "";
    String str8 = Build.MODEL;
    if (TextUtils.isEmpty(str8))
      str8 = "";
    String str9 = Build.VERSION.RELEASE;
    if (TextUtils.isEmpty(str9))
      str9 = "";
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("arrival_time", i);
      localJSONObject.put("uid", str1);
      localJSONObject.put("channel", str2);
      localJSONObject.put("supplier", str3);
      localJSONObject.put("imei", str4);
      localJSONObject.put("wmac", str6);
      localJSONObject.put("imsi", str5);
      localJSONObject.put("brand", str7);
      localJSONObject.put("device_model", str8);
      localJSONObject.put("os_version", str9);
      j.a("diff", "buildArrivalData:" + localJSONObject.toString());
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localJSONException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.a.a
 * JD-Core Version:    0.6.2
 */