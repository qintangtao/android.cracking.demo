package com.service.usbhelper.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.SystemClock;
import android.text.TextUtils;
import com.service.usbhelper.c.h;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.l;
import com.service.usbhelper.d.m;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;

public class c extends Thread
{
  private Context a;
  private long b;
  private boolean c = true;

  public c(Context paramContext)
  {
    this.a = paramContext;
  }

  private void a()
  {
    if (!m.b(this.a));
    while (true)
    {
      return;
      try
      {
        String str = h.a().b(l.c, null);
        j.a("diff", "获取服务端到达时间：" + str);
        if (!TextUtils.isEmpty(str))
        {
          JSONObject localJSONObject = new JSONObject(str);
          if (localJSONObject.getBoolean("status"))
          {
            com.service.usbhelper.b.a.a = 1000L * localJSONObject.getLong("time");
            return;
          }
        }
      }
      catch (IOException localIOException)
      {
        j.a("diff", "获取服务端到达时间失败：" + localIOException.getMessage());
        localIOException.printStackTrace();
        return;
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
    }
  }

  public void run()
  {
    super.run();
    if (k.a(this.a).getLong("has_arrival_interval", 0L) != 0L)
    {
      com.service.usbhelper.b.a.a = k.a(this.a).getLong("has_arrival_interval", 0L);
      j.a("diff", "开始计时:" + com.service.usbhelper.b.a.a / 1000L);
      this.b = (SystemClock.elapsedRealtime() + com.service.usbhelper.b.a.a);
    }
    while (true)
    {
      if (!this.c)
      {
        return;
        a();
        break;
      }
      long l = this.b - SystemClock.elapsedRealtime();
      j.a("diff", "倒计时:" + l / 1000L);
      if (l <= 0L)
      {
        a.b(this.a);
        this.c = false;
      }
      else
      {
        SharedPreferences.Editor localEditor = k.a(this.a).edit();
        localEditor.putLong("has_arrival_interval", l);
        localEditor.commit();
        try
        {
          Thread.sleep(2000L);
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.a.c
 * JD-Core Version:    0.6.2
 */