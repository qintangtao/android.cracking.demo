package com.service.usbhelper.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;
import org.json.JSONObject;

class b extends Thread
{
  b(Context paramContext)
  {
  }

  public void run()
  {
    try
    {
      a.b = true;
      String str = com.service.usbhelper.c.h.a().a("http://app.50bang.org/api/srom_arrive.php?action=session", "http://app.50bang.org/api/srom_arrive.php?action=sendData", com.service.usbhelper.d.h.a(m.a(this.a, "app_key"), a.c(this.a).toString()), this.a);
      j.b("diff", "到达数据返回值：>>>>>>>>" + str);
      if ((!TextUtils.isEmpty(str)) && (new JSONObject(str).getBoolean("status")))
      {
        SharedPreferences.Editor localEditor2 = k.a(this.a).edit();
        localEditor2.putBoolean("is_arrival_sended", true);
        localEditor2.commit();
      }
      a.b = false;
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      a.b = false;
      SharedPreferences.Editor localEditor1 = k.a(this.a).edit();
      localEditor1.putBoolean("is_arrival_send_fail", true);
      localEditor1.commit();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.a.b
 * JD-Core Version:    0.6.2
 */