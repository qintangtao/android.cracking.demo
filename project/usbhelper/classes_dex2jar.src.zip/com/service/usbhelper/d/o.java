package com.service.usbhelper.d;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import com.service.usbhelper.service.HelperService;
import java.util.ArrayList;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

public class o
{
  public static int a(Context paramContext)
  {
    String str = paramContext.getPackageName();
    try
    {
      int i = paramContext.getPackageManager().getPackageInfo(str, 0).versionCode;
      return i;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return 0;
  }

  private static void a(Context paramContext, String paramString)
  {
    if ((TextUtils.isEmpty(paramString)) || (paramContext == null))
      return;
    SharedPreferences.Editor localEditor = k.a(paramContext).edit();
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      j.a("update response==" + localJSONObject);
      String str = localJSONObject.getString("updatetype");
      if ((str != null) && (str.equals("update")) && (localJSONObject.getInt("version") > a(paramContext)))
      {
        localEditor.putBoolean("haveUpdate", true).commit();
        Intent localIntent = new Intent();
        localIntent.setClass(paramContext, HelperService.class);
        localIntent.putExtra("service_action", com.service.usbhelper.service.c.a);
        localIntent.putExtra("user_version", localJSONObject.getString("user_version"));
        localIntent.putExtra("updatelog", localJSONObject.getString("updatelog"));
        localIntent.putExtra("downurl", localJSONObject.getString("downurl"));
        localIntent.putExtra("filename", localJSONObject.getString("filename"));
        localIntent.putExtra("filesize", localJSONObject.getString("filesize"));
        localIntent.putExtra("md5", localJSONObject.getString("md5"));
        paramContext.startService(localIntent);
        return;
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      return;
    }
    localEditor.putBoolean("haveUpdate", false).commit();
  }

  public static String b(Context paramContext)
  {
    String str1 = paramContext.getPackageName();
    try
    {
      String str2 = paramContext.getPackageManager().getPackageInfo(str1, 0).versionName;
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public static void c(Context paramContext)
  {
    d(paramContext);
  }

  private static void d(Context paramContext)
  {
    if ((m.b(paramContext)) && (b.a()));
    try
    {
      String str1 = c.b(paramContext);
      if (TextUtils.isEmpty(str1))
        str1 = "default";
      String str2 = a(paramContext);
      String str3 = b(paramContext);
      String str4 = h.a("N#gK3OgTw#eRUI8+8bZsti78P==4s.5", i.a("usbhelper14199ef87d993e033fdca2b0c25fe876680f3" + str1 + str2 + str3 + "11111111111111111111111111111111" + "update"));
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new BasicNameValuePair("authkey", "usbhelper14199"));
      localArrayList.add(new BasicNameValuePair("appkey", "ef87d993e033fdca2b0c25fe876680f3"));
      localArrayList.add(new BasicNameValuePair("channel", str1));
      localArrayList.add(new BasicNameValuePair("version", str2));
      localArrayList.add(new BasicNameValuePair("user_version", str3));
      localArrayList.add(new BasicNameValuePair("old_md5", "11111111111111111111111111111111"));
      localArrayList.add(new BasicNameValuePair("type", "update"));
      localArrayList.add(new BasicNameValuePair("sign", str4));
      a(paramContext, com.service.usbhelper.c.h.a().a("http://update.app.2345.com/index.php", localArrayList));
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.o
 * JD-Core Version:    0.6.2
 */