package com.service.usbhelper.d;

import android.content.Context;

class e
  implements Runnable
{
  e(Context paramContext)
  {
  }

  public void run()
  {
    c.g(this.a);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.e
 * JD-Core Version:    0.6.2
 */