package com.service.usbhelper.d;

public class j
{
  public static void a(String paramString)
  {
  }

  public static void a(String paramString1, String paramString2)
  {
  }

  public static void b(String paramString)
  {
  }

  public static void b(String paramString1, String paramString2)
  {
  }

  public static void c(String paramString1, String paramString2)
  {
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.j
 * JD-Core Version:    0.6.2
 */