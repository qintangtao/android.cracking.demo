package com.service.usbhelper.d;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import java.io.File;

public class m
{
  public static String a(Context paramContext)
  {
    String str;
    if (paramContext == null)
    {
      j.a("context为空,获取不到手机分辨率...");
      str = "*";
    }
    do
    {
      return str;
      SharedPreferences localSharedPreferences = k.a(paramContext);
      str = null;
      if (localSharedPreferences != null)
      {
        boolean bool = localSharedPreferences.contains("resolution");
        str = null;
        if (bool)
          str = localSharedPreferences.getString("resolution", null);
      }
      if (TextUtils.isEmpty(str))
      {
        DisplayMetrics localDisplayMetrics = paramContext.getResources().getDisplayMetrics();
        str = localDisplayMetrics.widthPixels + "*" + localDisplayMetrics.heightPixels;
        localSharedPreferences.edit().putString("resolution", str).commit();
      }
    }
    while (str != null);
    j.a("result为空,获取不到手机分辨率...");
    return "*";
  }

  public static String a(Context paramContext, String paramString)
  {
    if ((paramContext == null) || (TextUtils.isEmpty(paramString)))
      return "";
    PackageManager localPackageManager = paramContext.getPackageManager();
    if (localPackageManager != null)
      try
      {
        ApplicationInfo localApplicationInfo2 = localPackageManager.getApplicationInfo(paramContext.getPackageName(), 128);
        localApplicationInfo1 = localApplicationInfo2;
        if ((localApplicationInfo1 != null) && (localApplicationInfo1.metaData != null) && (localApplicationInfo1.metaData.containsKey(paramString)))
          return localApplicationInfo1.metaData.getString(paramString);
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
        {
          localNameNotFoundException.printStackTrace();
          ApplicationInfo localApplicationInfo1 = null;
        }
      }
    return "";
  }

  public static void b(Context paramContext, String paramString)
  {
    File localFile = new File(paramString);
    Intent localIntent = new Intent();
    localIntent.addFlags(268435456);
    localIntent.setAction("android.intent.action.VIEW");
    localIntent.setDataAndType(Uri.fromFile(localFile), "application/vnd.android.package-archive");
    paramContext.startActivity(localIntent);
  }

  public static boolean b(Context paramContext)
  {
    try
    {
      ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
      if (localConnectivityManager != null)
      {
        NetworkInfo[] arrayOfNetworkInfo = localConnectivityManager.getAllNetworkInfo();
        if (arrayOfNetworkInfo != null)
          for (int i = 0; i < arrayOfNetworkInfo.length; i++)
            if (arrayOfNetworkInfo[i] != null)
            {
              NetworkInfo.State localState1 = arrayOfNetworkInfo[i].getState();
              NetworkInfo.State localState2 = NetworkInfo.State.CONNECTED;
              if (localState1 == localState2)
                return true;
            }
      }
    }
    catch (Exception localException)
    {
      return false;
    }
    return false;
  }

  public static String c(Context paramContext)
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    if (localConnectivityManager != null)
    {
      try
      {
        NetworkInfo localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
        if ((localNetworkInfo != null) && (localNetworkInfo.isConnected()))
          switch (localNetworkInfo.getType())
          {
          case 0:
            if ((localNetworkInfo.getSubtype() == 1) || (localNetworkInfo.getSubtype() == 4) || (localNetworkInfo.getSubtype() == 2))
              break;
            if (localNetworkInfo.getSubtype() != 13)
              break label111;
            return "4G";
          case 1:
            return "WiFi";
          }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    else
    {
      return null;
      return "unknown";
    }
    return "2G";
    label111: return "3G";
  }

  public static String d(Context paramContext)
  {
    String str1 = "";
    while (true)
    {
      try
      {
        TelephonyManager localTelephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
        if (localTelephonyManager != null)
        {
          str1 = localTelephonyManager.getSubscriberId();
          Object localObject;
          if (TextUtils.isEmpty(str1))
          {
            String str3 = localTelephonyManager.getSimOperator();
            if (!TextUtils.isEmpty(str3))
            {
              String str5 = str3 + "@" + g.d(paramContext);
              localObject = str5;
              if (!TextUtils.isEmpty((CharSequence)localObject))
              {
                if ((!((String)localObject).contains("@")) && (!((String)localObject).contains("#")))
                  continue;
                String str2 = k.a(paramContext).getString("imsi", "");
                if (!TextUtils.isEmpty(str2))
                  localObject = str2;
              }
              return localObject;
            }
            else
            {
              if (localTelephonyManager.getSimState() == 5)
              {
                localObject = g.a("@", 14);
                continue;
              }
              String str4 = g.a("#", 14);
              localObject = str4;
              continue;
            }
          }
        }
      }
      catch (Exception localException)
      {
        localObject = g.a("#", 14);
        localException.printStackTrace();
        continue;
        k.a(paramContext).edit().putString("imsi", (String)localObject).commit();
        return localObject;
      }
      localObject = str1;
    }
  }

  public static String e(Context paramContext)
  {
    String str;
    if (paramContext == null)
      str = "";
    label99: 
    while (true)
    {
      return str;
      SharedPreferences localSharedPreferences = k.a(paramContext);
      if (localSharedPreferences.contains("tj_sim_iccid"));
      for (str = localSharedPreferences.getString("tj_sim_iccid", ""); ; str = "")
        while (true)
        {
          if (!TextUtils.isEmpty(str))
            break label99;
          try
          {
            str = ((TelephonyManager)paramContext.getSystemService("phone")).getSimSerialNumber();
            if (TextUtils.isEmpty(str))
              break;
            localSharedPreferences.edit().putString("tj_sim_iccid", str).commit();
            return str;
          }
          catch (Exception localException)
          {
            localException.printStackTrace();
            return str;
          }
        }
    }
  }

  // ERROR //
  public static String f(Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull +6 -> 7
    //   4: ldc 102
    //   6: areturn
    //   7: aload_0
    //   8: invokevirtual 264	android/content/Context:getApplicationInfo	()Landroid/content/pm/ApplicationInfo;
    //   11: getfield 268	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   14: astore_1
    //   15: aload_1
    //   16: invokestatic 38	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   19: ifne -15 -> 4
    //   22: new 270	java/util/zip/ZipFile
    //   25: dup
    //   26: aload_1
    //   27: invokespecial 271	java/util/zip/ZipFile:<init>	(Ljava/lang/String;)V
    //   30: astore_2
    //   31: aload_2
    //   32: invokevirtual 275	java/util/zip/ZipFile:entries	()Ljava/util/Enumeration;
    //   35: astore 8
    //   37: aload 8
    //   39: invokeinterface 280 1 0
    //   44: istore 9
    //   46: iload 9
    //   48: ifne +18 -> 66
    //   51: ldc 102
    //   53: astore 6
    //   55: aload_2
    //   56: ifnull +7 -> 63
    //   59: aload_2
    //   60: invokevirtual 283	java/util/zip/ZipFile:close	()V
    //   63: aload 6
    //   65: areturn
    //   66: aload 8
    //   68: invokeinterface 287 1 0
    //   73: checkcast 289	java/util/zip/ZipEntry
    //   76: astore 10
    //   78: aload 10
    //   80: invokevirtual 292	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   83: ldc_w 294
    //   86: invokevirtual 297	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   89: ifeq -52 -> 37
    //   92: aload 10
    //   94: invokevirtual 292	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   97: ldc_w 294
    //   100: invokevirtual 300	java/lang/String:length	()I
    //   103: invokevirtual 303	java/lang/String:substring	(I)Ljava/lang/String;
    //   106: astore 11
    //   108: aload 11
    //   110: astore 6
    //   112: goto -57 -> 55
    //   115: astore_3
    //   116: aconst_null
    //   117: astore_2
    //   118: aload_3
    //   119: invokevirtual 216	java/lang/Exception:printStackTrace	()V
    //   122: aload_2
    //   123: ifnull +72 -> 195
    //   126: aload_2
    //   127: invokevirtual 283	java/util/zip/ZipFile:close	()V
    //   130: ldc 102
    //   132: astore 6
    //   134: goto -71 -> 63
    //   137: astore 7
    //   139: aload 7
    //   141: invokevirtual 216	java/lang/Exception:printStackTrace	()V
    //   144: ldc 102
    //   146: astore 6
    //   148: goto -85 -> 63
    //   151: astore 4
    //   153: aconst_null
    //   154: astore_2
    //   155: aload_2
    //   156: ifnull +7 -> 163
    //   159: aload_2
    //   160: invokevirtual 283	java/util/zip/ZipFile:close	()V
    //   163: aload 4
    //   165: athrow
    //   166: astore 5
    //   168: aload 5
    //   170: invokevirtual 216	java/lang/Exception:printStackTrace	()V
    //   173: goto -10 -> 163
    //   176: astore 12
    //   178: aload 12
    //   180: invokevirtual 216	java/lang/Exception:printStackTrace	()V
    //   183: goto -120 -> 63
    //   186: astore 4
    //   188: goto -33 -> 155
    //   191: astore_3
    //   192: goto -74 -> 118
    //   195: ldc 102
    //   197: astore 6
    //   199: goto -136 -> 63
    //
    // Exception table:
    //   from	to	target	type
    //   22	31	115	java/lang/Exception
    //   126	130	137	java/lang/Exception
    //   22	31	151	finally
    //   159	163	166	java/lang/Exception
    //   59	63	176	java/lang/Exception
    //   31	37	186	finally
    //   37	46	186	finally
    //   66	108	186	finally
    //   118	122	186	finally
    //   31	37	191	java/lang/Exception
    //   37	46	191	java/lang/Exception
    //   66	108	191	java/lang/Exception
  }

  public static boolean g(Context paramContext)
  {
    return ((TelephonyManager)paramContext.getSystemService("phone")).getSimState() == 5;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.m
 * JD-Core Version:    0.6.2
 */