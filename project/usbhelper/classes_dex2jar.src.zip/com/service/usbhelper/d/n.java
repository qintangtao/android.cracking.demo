package com.service.usbhelper.d;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class n
{
  private static ExecutorService a = null;

  public static void a()
  {
    try
    {
      if ((a == null) || (a.isShutdown()))
      {
        a = null;
        a = Executors.newFixedThreadPool(10);
      }
      return;
    }
    finally
    {
    }
  }

  public static void a(Runnable paramRunnable)
  {
    a();
    a.execute(paramRunnable);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.n
 * JD-Core Version:    0.6.2
 */