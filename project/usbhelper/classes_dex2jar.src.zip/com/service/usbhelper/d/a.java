package com.service.usbhelper.d;

import android.content.Context;

public class a
  implements Thread.UncaughtExceptionHandler
{
  private static a a;
  private Context b;
  private Thread.UncaughtExceptionHandler c;

  public static a a()
  {
    try
    {
      if (a == null)
        a = new a();
      a locala = a;
      return locala;
    }
    finally
    {
    }
  }

  private boolean a(Throwable paramThrowable)
  {
    new com.service.usbhelper.service.a(this.b, paramThrowable).start();
    return false;
  }

  public void a(Context paramContext)
  {
    this.b = paramContext;
    this.c = Thread.getDefaultUncaughtExceptionHandler();
    Thread.currentThread().setUncaughtExceptionHandler(this);
  }

  public void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    j.a("uncaughtException-----");
    if ((!a(paramThrowable)) && (this.c != null))
      this.c.uncaughtException(paramThread, paramThrowable);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.a
 * JD-Core Version:    0.6.2
 */