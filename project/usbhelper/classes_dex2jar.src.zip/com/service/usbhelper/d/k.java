package com.service.usbhelper.d;

import android.content.Context;
import android.content.SharedPreferences;

public class k
{
  private static SharedPreferences a;

  public static SharedPreferences a(Context paramContext)
  {
    a = paramContext.getSharedPreferences("usbHelper", 0);
    return a;
  }

  public static SharedPreferences a(Context paramContext, String paramString)
  {
    a = paramContext.getSharedPreferences(paramString, 0);
    return a;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.k
 * JD-Core Version:    0.6.2
 */