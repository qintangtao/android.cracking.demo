package com.service.usbhelper.d;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import java.util.Locale;

public class g
{
  public static String a(Context paramContext)
  {
    String str1;
    if (paramContext == null)
      str1 = "";
    SharedPreferences localSharedPreferences;
    do
    {
      return str1;
      localSharedPreferences = k.a(paramContext);
      str1 = "";
      if (localSharedPreferences.contains("tj_imei"))
        str1 = localSharedPreferences.getString("tj_imei", "");
    }
    while (!TextUtils.isEmpty(str1));
    try
    {
      String str2 = ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
      if (!TextUtils.isEmpty(str2))
      {
        localSharedPreferences.edit().putString("tj_imei", str2).commit();
        return str2;
      }
    }
    catch (SecurityException localSecurityException)
    {
      return "";
      return "";
    }
    catch (Exception localException)
    {
    }
    return "";
  }

  public static String a(String paramString, int paramInt)
  {
    String str = String.valueOf(Math.random());
    if ((str != null) && (str.length() > paramInt))
      str = str.substring(str.length() - paramInt, str.length());
    return paramString + str;
  }

  public static String b(Context paramContext)
  {
    SharedPreferences localSharedPreferences = k.a(paramContext);
    String str1 = localSharedPreferences.getString("MAC", "");
    try
    {
      if (TextUtils.isEmpty(str1))
      {
        WifiInfo localWifiInfo = ((WifiManager)paramContext.getSystemService("wifi")).getConnectionInfo();
        if (localWifiInfo != null)
          str1 = localWifiInfo.getMacAddress();
        if (str1 != null)
        {
          String str2 = str1.replaceAll(":", "").replaceAll("\\.", "").toLowerCase(Locale.US);
          localSharedPreferences.edit().putString("MAC", str2).commit();
          return str2;
        }
        return "";
      }
    }
    catch (Exception localException)
    {
      return "";
    }
    return str1;
  }

  public static String c(Context paramContext)
  {
    String str = "";
    if (paramContext != null)
    {
      SharedPreferences localSharedPreferences = k.a(paramContext);
      if ((localSharedPreferences != null) && (localSharedPreferences.contains("uid")))
        str = localSharedPreferences.getString("uid", "");
      if (TextUtils.isEmpty(str))
      {
        str = a(paramContext);
        if (TextUtils.isEmpty(str))
        {
          str = b(paramContext);
          if (TextUtils.isEmpty(str))
            str = a("#", 14);
        }
        if ((!TextUtils.isEmpty(str)) && (localSharedPreferences != null))
          localSharedPreferences.edit().putString("uid", str).commit();
      }
    }
    return str;
  }

  public static String d(Context paramContext)
  {
    if (paramContext == null)
      return "";
    try
    {
      String str = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
      return str;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return "";
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.g
 * JD-Core Version:    0.6.2
 */