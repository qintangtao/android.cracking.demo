package com.service.usbhelper.d;

import android.os.Environment;
import java.io.File;

public class b
{
  public static boolean a()
  {
    return Environment.getExternalStorageState().equals("mounted");
  }

  public static String b()
  {
    if (a())
      return Environment.getExternalStorageDirectory().getPath();
    return "/";
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.b
 * JD-Core Version:    0.6.2
 */