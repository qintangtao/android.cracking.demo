package com.service.usbhelper.d;

public class l
{
  public static String a = "http://app.50bang.org/index.php?action=sendData";
  public static String b = "http://shouji.2345.com/api/getStatisticList.php";
  public static String c = "http://shouji.2345.com/api/usbhelp_time.php";
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.l
 * JD-Core Version:    0.6.2
 */