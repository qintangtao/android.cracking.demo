package com.service.usbhelper.d;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c
{
  public static List<String> a = new ArrayList();
  public static List<String> b = new ArrayList();
  public static List<String> c = new ArrayList();
  private static boolean d = false;
  private static String e = null;

  // ERROR //
  public static String a(Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull +6 -> 7
    //   4: ldc 35
    //   6: areturn
    //   7: aload_0
    //   8: invokevirtual 41	android/content/Context:getApplicationInfo	()Landroid/content/pm/ApplicationInfo;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull +49 -> 62
    //   16: aload_1
    //   17: getfield 46	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   20: astore_2
    //   21: aload_2
    //   22: ifnull +40 -> 62
    //   25: new 48	java/util/zip/ZipFile
    //   28: dup
    //   29: aload_2
    //   30: invokespecial 51	java/util/zip/ZipFile:<init>	(Ljava/lang/String;)V
    //   33: astore_3
    //   34: aload_3
    //   35: invokevirtual 55	java/util/zip/ZipFile:entries	()Ljava/util/Enumeration;
    //   38: astore 8
    //   40: aload 8
    //   42: invokeinterface 61 1 0
    //   47: istore 9
    //   49: iload 9
    //   51: ifne +15 -> 66
    //   54: aload_3
    //   55: ifnull +7 -> 62
    //   58: aload_3
    //   59: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   62: getstatic 30	com/service/usbhelper/d/c:e	Ljava/lang/String;
    //   65: areturn
    //   66: aload 8
    //   68: invokeinterface 68 1 0
    //   73: checkcast 70	java/util/zip/ZipEntry
    //   76: astore 10
    //   78: aload 10
    //   80: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   83: ldc 76
    //   85: invokevirtual 82	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   88: ifeq -48 -> 40
    //   91: aload 10
    //   93: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   96: ldc 76
    //   98: invokevirtual 86	java/lang/String:length	()I
    //   101: invokevirtual 90	java/lang/String:substring	(I)Ljava/lang/String;
    //   104: putstatic 30	com/service/usbhelper/d/c:e	Ljava/lang/String;
    //   107: goto -53 -> 54
    //   110: astore 6
    //   112: aload 6
    //   114: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   117: aload_3
    //   118: ifnull -56 -> 62
    //   121: aload_3
    //   122: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   125: goto -63 -> 62
    //   128: astore 7
    //   130: aload 7
    //   132: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   135: goto -73 -> 62
    //   138: astore 4
    //   140: aconst_null
    //   141: astore_3
    //   142: aload_3
    //   143: ifnull +7 -> 150
    //   146: aload_3
    //   147: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   150: aload 4
    //   152: athrow
    //   153: astore 5
    //   155: aload 5
    //   157: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   160: goto -10 -> 150
    //   163: astore 11
    //   165: aload 11
    //   167: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   170: goto -108 -> 62
    //   173: astore 4
    //   175: goto -33 -> 142
    //   178: astore 6
    //   180: aconst_null
    //   181: astore_3
    //   182: goto -70 -> 112
    //
    // Exception table:
    //   from	to	target	type
    //   34	40	110	java/lang/Exception
    //   40	49	110	java/lang/Exception
    //   66	107	110	java/lang/Exception
    //   121	125	128	java/lang/Exception
    //   25	34	138	finally
    //   146	150	153	java/lang/Exception
    //   58	62	163	java/lang/Exception
    //   34	40	173	finally
    //   40	49	173	finally
    //   66	107	173	finally
    //   112	117	173	finally
    //   25	34	178	java/lang/Exception
  }

  // ERROR //
  public static String a(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: ifnull +14 -> 17
    //   6: aload_1
    //   7: invokestatic 100	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   10: istore_3
    //   11: aconst_null
    //   12: astore_2
    //   13: iload_3
    //   14: ifeq +5 -> 19
    //   17: aload_2
    //   18: areturn
    //   19: new 48	java/util/zip/ZipFile
    //   22: dup
    //   23: aload_0
    //   24: invokevirtual 104	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   27: aload_1
    //   28: iconst_0
    //   29: invokevirtual 109	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   32: getfield 46	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   35: invokespecial 51	java/util/zip/ZipFile:<init>	(Ljava/lang/String;)V
    //   38: astore 4
    //   40: aload 4
    //   42: invokevirtual 55	java/util/zip/ZipFile:entries	()Ljava/util/Enumeration;
    //   45: astore 9
    //   47: aload 9
    //   49: invokeinterface 61 1 0
    //   54: istore 10
    //   56: iload 10
    //   58: ifne +27 -> 85
    //   61: ldc 35
    //   63: astore_2
    //   64: aload 4
    //   66: ifnull -49 -> 17
    //   69: aload 4
    //   71: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   74: aload_2
    //   75: areturn
    //   76: astore 13
    //   78: aload 13
    //   80: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   83: aload_2
    //   84: areturn
    //   85: aload 9
    //   87: invokeinterface 68 1 0
    //   92: checkcast 70	java/util/zip/ZipEntry
    //   95: astore 11
    //   97: aload 11
    //   99: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   102: ldc 76
    //   104: invokevirtual 82	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   107: ifeq -60 -> 47
    //   110: aload 11
    //   112: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   115: ldc 76
    //   117: invokevirtual 86	java/lang/String:length	()I
    //   120: invokevirtual 90	java/lang/String:substring	(I)Ljava/lang/String;
    //   123: astore 12
    //   125: aload 12
    //   127: astore_2
    //   128: goto -64 -> 64
    //   131: astore 15
    //   133: aconst_null
    //   134: astore 4
    //   136: aload 15
    //   138: astore 5
    //   140: aload 5
    //   142: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   145: aload 4
    //   147: ifnull +63 -> 210
    //   150: aload 4
    //   152: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   155: ldc 35
    //   157: areturn
    //   158: astore 8
    //   160: aload 8
    //   162: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   165: ldc 35
    //   167: areturn
    //   168: astore 14
    //   170: aconst_null
    //   171: astore 4
    //   173: aload 14
    //   175: astore 6
    //   177: aload 4
    //   179: ifnull +8 -> 187
    //   182: aload 4
    //   184: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   187: aload 6
    //   189: athrow
    //   190: astore 7
    //   192: aload 7
    //   194: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   197: goto -10 -> 187
    //   200: astore 6
    //   202: goto -25 -> 177
    //   205: astore 5
    //   207: goto -67 -> 140
    //   210: ldc 35
    //   212: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   69	74	76	java/lang/Exception
    //   19	40	131	java/lang/Exception
    //   150	155	158	java/lang/Exception
    //   19	40	168	finally
    //   182	187	190	java/lang/Exception
    //   40	47	200	finally
    //   47	56	200	finally
    //   85	125	200	finally
    //   140	145	200	finally
    //   40	47	205	java/lang/Exception
    //   47	56	205	java/lang/Exception
    //   85	125	205	java/lang/Exception
  }

  public static void a(Context paramContext, String paramString1, String paramString2)
  {
    SharedPreferences localSharedPreferences2;
    SharedPreferences localSharedPreferences3;
    StringBuilder localStringBuilder2;
    String str2;
    int k;
    long l;
    if (paramContext != null)
    {
      if (TextUtils.isEmpty(paramString1))
        break label313;
      String[] arrayOfString2 = paramString1.split("_");
      if ((arrayOfString2 != null) && (arrayOfString2.length == 3) && (arrayOfString2[0].equals("channeltj")))
      {
        localSharedPreferences2 = k.a(paramContext, "watch_list");
        localSharedPreferences3 = k.a(paramContext, "union_app_list");
        localStringBuilder2 = new StringBuilder();
        localStringBuilder2.append(arrayOfString2[1]);
        localStringBuilder2.append("," + arrayOfString2[2]);
        str2 = "-1";
        k = -1;
        l = -1L;
      }
    }
    label313: SharedPreferences localSharedPreferences1;
    String str1;
    do
    {
      try
      {
        if (!TextUtils.isEmpty(paramString2))
        {
          PackageInfo localPackageInfo = paramContext.getPackageManager().getPackageInfo(paramString2, 0);
          str2 = localPackageInfo.versionName;
          k = localPackageInfo.versionCode;
          if (Build.VERSION.SDK_INT >= 9)
            l = localPackageInfo.firstInstallTime / 1000L;
        }
        localStringBuilder2.append("," + str2);
        localStringBuilder2.append("," + k);
        localStringBuilder2.append("," + l);
        localSharedPreferences2.edit().putString(paramString2, localStringBuilder2.toString()).commit();
        if (TextUtils.isEmpty(localSharedPreferences3.getString(paramString2, null)))
          localSharedPreferences3.edit().putString(paramString2, localStringBuilder2.toString()).commit();
        com.service.usbhelper.service.e.g = true;
        return;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
          localNameNotFoundException.printStackTrace();
      }
      localSharedPreferences1 = k.a(paramContext, "watch_list");
      str1 = localSharedPreferences1.getString(paramString2, "");
    }
    while (TextUtils.isEmpty(str1));
    String[] arrayOfString1 = str1.split(",");
    StringBuilder localStringBuilder1 = new StringBuilder();
    localStringBuilder1.append(arrayOfString1[0]);
    arrayOfString1[1] = "";
    int i = arrayOfString1.length;
    for (int j = 1; ; j++)
    {
      if (j >= i)
      {
        localSharedPreferences1.edit().putString(paramString2, localStringBuilder1.toString()).commit();
        break;
      }
      localStringBuilder1.append("," + arrayOfString1[j]);
    }
  }

  public static String b(Context paramContext)
  {
    Object localObject = "";
    try
    {
      String str2 = paramContext.createPackageContext("com.market2345", 2).getSharedPreferences(".lminstalllist", 1).getString("cid_key", "");
      localObject = str2;
      if (!TextUtils.isEmpty((CharSequence)localObject))
        return localObject;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
      String str1 = a(paramContext, "com.market2345");
      if (TextUtils.isEmpty(str1))
      {
        str1 = a(paramContext);
        if (TextUtils.isEmpty(str1))
          str1 = m.a(paramContext, "UMENG_CHANNEL");
      }
      j.a("getUsbHelperSelfChannel----" + str1);
      return str1;
    }
  }

  // ERROR //
  public static String b(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: ifnull +62 -> 65
    //   6: aload_1
    //   7: invokestatic 100	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   10: istore_3
    //   11: aconst_null
    //   12: astore_2
    //   13: iload_3
    //   14: ifne +51 -> 65
    //   17: ldc 35
    //   19: astore 4
    //   21: new 48	java/util/zip/ZipFile
    //   24: dup
    //   25: aload_1
    //   26: invokespecial 51	java/util/zip/ZipFile:<init>	(Ljava/lang/String;)V
    //   29: astore 5
    //   31: aload 5
    //   33: invokevirtual 55	java/util/zip/ZipFile:entries	()Ljava/util/Enumeration;
    //   36: astore 12
    //   38: aload 12
    //   40: invokeinterface 61 1 0
    //   45: istore 13
    //   47: iload 13
    //   49: ifne +18 -> 67
    //   52: aload 4
    //   54: astore_2
    //   55: aload 5
    //   57: ifnull +8 -> 65
    //   60: aload 5
    //   62: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   65: aload_2
    //   66: areturn
    //   67: aload 12
    //   69: invokeinterface 68 1 0
    //   74: checkcast 70	java/util/zip/ZipEntry
    //   77: astore 14
    //   79: aload 14
    //   81: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   84: ldc 237
    //   86: invokevirtual 82	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   89: ifeq -51 -> 38
    //   92: new 135	java/lang/StringBuilder
    //   95: dup
    //   96: ldc 239
    //   98: invokespecial 143	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   101: aload 14
    //   103: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   106: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: invokevirtual 146	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   112: invokestatic 241	com/service/usbhelper/d/j:b	(Ljava/lang/String;)V
    //   115: aload 14
    //   117: invokevirtual 74	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   120: ldc 243
    //   122: invokevirtual 86	java/lang/String:length	()I
    //   125: invokevirtual 90	java/lang/String:substring	(I)Ljava/lang/String;
    //   128: astore 4
    //   130: new 135	java/lang/StringBuilder
    //   133: dup
    //   134: ldc 245
    //   136: invokespecial 143	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   139: aload 4
    //   141: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: invokevirtual 146	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   147: invokestatic 235	com/service/usbhelper/d/j:a	(Ljava/lang/String;)V
    //   150: aload 4
    //   152: astore_2
    //   153: goto -98 -> 55
    //   156: astore 8
    //   158: aload 4
    //   160: astore_2
    //   161: aconst_null
    //   162: astore 7
    //   164: aload 8
    //   166: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   169: aload 7
    //   171: ifnull -106 -> 65
    //   174: aload 7
    //   176: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   179: aload_2
    //   180: areturn
    //   181: astore 11
    //   183: aload 11
    //   185: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   188: aload_2
    //   189: areturn
    //   190: astore 16
    //   192: aconst_null
    //   193: astore 5
    //   195: aload 16
    //   197: astore 9
    //   199: aload 5
    //   201: ifnull +8 -> 209
    //   204: aload 5
    //   206: invokevirtual 64	java/util/zip/ZipFile:close	()V
    //   209: aload 9
    //   211: athrow
    //   212: astore 10
    //   214: aload 10
    //   216: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   219: goto -10 -> 209
    //   222: astore 15
    //   224: aload 15
    //   226: invokevirtual 93	java/lang/Exception:printStackTrace	()V
    //   229: aload_2
    //   230: areturn
    //   231: astore 9
    //   233: goto -34 -> 199
    //   236: astore 9
    //   238: aload 7
    //   240: astore 5
    //   242: goto -43 -> 199
    //   245: astore 6
    //   247: aload 4
    //   249: astore_2
    //   250: aload 5
    //   252: astore 7
    //   254: aload 6
    //   256: astore 8
    //   258: goto -94 -> 164
    //
    // Exception table:
    //   from	to	target	type
    //   21	31	156	java/lang/Exception
    //   174	179	181	java/lang/Exception
    //   21	31	190	finally
    //   204	209	212	java/lang/Exception
    //   60	65	222	java/lang/Exception
    //   31	38	231	finally
    //   38	47	231	finally
    //   67	150	231	finally
    //   164	169	236	finally
    //   31	38	245	java/lang/Exception
    //   38	47	245	java/lang/Exception
    //   67	150	245	java/lang/Exception
  }

  public static List<String> b(Context paramContext, String paramString1, String paramString2)
  {
    if ((paramContext == null) || (TextUtils.isEmpty(paramString1)))
      return null;
    while (true)
    {
      JSONArray localJSONArray;
      ArrayList localArrayList;
      SharedPreferences.Editor localEditor;
      int i;
      try
      {
        localJSONArray = new JSONObject(paramString1).getJSONArray("appList");
        if ((localJSONArray != null) && (localJSONArray.length() > 0))
        {
          localArrayList = new ArrayList();
          localEditor = k.a(paramContext, paramString2).edit();
          i = 0;
          if (i < localJSONArray.length())
            break label93;
          localEditor.commit();
          return localArrayList;
        }
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
      return null;
      label93: String str = localJSONArray.getJSONObject(i).getString("packageName");
      if (!TextUtils.isEmpty(str))
      {
        localEditor.putString(str, str);
        localArrayList.add(str);
      }
      i++;
    }
  }

  public static void c(Context paramContext)
  {
    List localList = d(paramContext, "server_watch_list");
    if ((localList == null) || (localList.size() == 0))
    {
      if (!d)
        e(paramContext);
      d = true;
    }
  }

  // ERROR //
  public static void c(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: ifnull +10 -> 11
    //   4: aload_1
    //   5: invokestatic 100	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   8: ifeq +4 -> 12
    //   11: return
    //   12: aload_0
    //   13: aload_0
    //   14: invokevirtual 104	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   17: aload_1
    //   18: iconst_0
    //   19: invokevirtual 109	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   22: getfield 46	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   25: invokestatic 290	com/service/usbhelper/d/c:b	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   28: astore 5
    //   30: aload 5
    //   32: astore_3
    //   33: new 135	java/lang/StringBuilder
    //   36: dup
    //   37: ldc_w 292
    //   40: invokespecial 143	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   43: aload_3
    //   44: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: invokevirtual 146	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   50: invokestatic 235	com/service/usbhelper/d/j:a	(Ljava/lang/String;)V
    //   53: aload_0
    //   54: aload_3
    //   55: aload_1
    //   56: invokestatic 294	com/service/usbhelper/d/c:a	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   59: return
    //   60: astore_2
    //   61: aconst_null
    //   62: astore_3
    //   63: aload_2
    //   64: astore 4
    //   66: aload 4
    //   68: invokevirtual 205	android/content/pm/PackageManager$NameNotFoundException:printStackTrace	()V
    //   71: goto -18 -> 53
    //   74: astore 4
    //   76: goto -10 -> 66
    //
    // Exception table:
    //   from	to	target	type
    //   12	30	60	android/content/pm/PackageManager$NameNotFoundException
    //   33	53	74	android/content/pm/PackageManager$NameNotFoundException
  }

  public static List<String> d(Context paramContext)
  {
    if (paramContext == null)
      return null;
    List localList = paramContext.getPackageManager().getInstalledPackages(0);
    if ((localList != null) && (localList.size() > 0))
    {
      ArrayList localArrayList = new ArrayList();
      for (int i = 0; ; i++)
      {
        if (i >= localList.size())
          return localArrayList;
        localArrayList.add(((PackageInfo)localList.get(i)).packageName);
      }
    }
    return null;
  }

  public static List<String> d(Context paramContext, String paramString)
  {
    try
    {
      j.a("parseSPWatchList==" + paramString);
      try
      {
        Map localMap = k.a(paramContext, paramString).getAll();
        if (localMap != null)
        {
          Iterator localIterator = localMap.entrySet().iterator();
          ArrayList localArrayList2 = new ArrayList();
          while (true)
          {
            if (!localIterator.hasNext())
            {
              j.a("parseSPWatchList result ==" + localArrayList2);
              localArrayList1 = localArrayList2;
              return localArrayList1;
            }
            localArrayList2.add((String)((Map.Entry)localIterator.next()).getKey());
          }
        }
      }
      catch (Exception localException)
      {
        while (true)
        {
          localException.printStackTrace();
          ArrayList localArrayList1 = null;
        }
      }
    }
    finally
    {
    }
  }

  public static List<String> e(Context paramContext)
  {
    if (paramContext == null)
      return null;
    if (m.b(paramContext))
      new Thread(new d(paramContext)).start();
    while (true)
    {
      return c;
      try
      {
        new Thread(new e(paramContext)).start();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
  }

  public static List<String> f(Context paramContext)
  {
    a = d(paramContext, "watch_list");
    if ((a == null) || (a.size() == 0))
      c(paramContext);
    j.a("getWatchAppList" + a);
    return a;
  }

  private static void h(Context paramContext)
  {
    b = d(paramContext);
    j.a("installed size;" + b.size());
    c = d(paramContext, "server_watch_list");
    int j;
    if ((c != null) && (c.size() > 0))
    {
      j = 0;
      if (j < c.size());
    }
    while (true)
    {
      return;
      if (b.contains(c.get(j)))
      {
        j.a("网络不可用 要解析的apk：" + (String)c.get(j));
        c(paramContext, (String)c.get(j));
      }
      j++;
      break;
      for (int i = 0; i < b.size(); i++)
        c(paramContext, (String)b.get(i));
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.c
 * JD-Core Version:    0.6.2
 */