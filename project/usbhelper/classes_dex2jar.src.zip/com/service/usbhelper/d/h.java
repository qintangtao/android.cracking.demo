package com.service.usbhelper.d;

import android.util.Base64;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class h
{
  public static String a(String paramString1, String paramString2)
  {
    j.a("appSecket" + paramString1 + "\n str==" + paramString2);
    String str1 = i.a(paramString1);
    byte[] arrayOfByte1 = paramString2.getBytes();
    int i = str1.length();
    int j = arrayOfByte1.length;
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
    int k = 0;
    while (true)
    {
      if (k >= j);
      try
      {
        String str2 = new String(Base64.encode(arrayOfByte2, 2), "utf-8");
        System.out.print("strcode:" + str2);
        return str2;
        int m = k % i;
        arrayOfByte2[k] = ((byte)(arrayOfByte1[k] ^ str1.charAt(m)));
        k++;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        localUnsupportedEncodingException.printStackTrace();
      }
    }
    return null;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.h
 * JD-Core Version:    0.6.2
 */