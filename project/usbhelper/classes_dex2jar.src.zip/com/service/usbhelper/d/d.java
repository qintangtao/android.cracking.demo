package com.service.usbhelper.d;

import android.content.Context;
import android.text.TextUtils;
import com.service.usbhelper.c.h;
import java.io.IOException;

class d
  implements Runnable
{
  d(Context paramContext)
  {
  }

  public void run()
  {
    try
    {
      String str = h.a().b(l.b, null);
      if ((!TextUtils.isEmpty(str)) && (str.contains("appList")))
      {
        c.c = c.b(this.a, str, "server_watch_list");
        c.a(false);
      }
      c.g(this.a);
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        localIOException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.d
 * JD-Core Version:    0.6.2
 */