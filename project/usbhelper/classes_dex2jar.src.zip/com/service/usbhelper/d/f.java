package com.service.usbhelper.d;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class f
{
  public static int a()
  {
    return (int)(System.currentTimeMillis() / 1000L);
  }

  public static int a(Context paramContext, long paramLong)
  {
    if ((paramContext == null) || (paramLong == 0L))
      return 0;
    try
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
      long l = localSimpleDateFormat.parse(localSimpleDateFormat.format(new Date(1000L * paramLong))).getTime() / 1000L;
      i = (int)l;
      j.a("dayStamp:formatTimeStampByDay==" + i);
      return i;
    }
    catch (Exception localException)
    {
      while (true)
      {
        localException.printStackTrace();
        int i = 0;
      }
    }
  }

  public static String a(long paramLong, String paramString)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(paramString, Locale.SIMPLIFIED_CHINESE);
    localSimpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
    return localSimpleDateFormat.format(new Date(paramLong));
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.d.f
 * JD-Core Version:    0.6.2
 */