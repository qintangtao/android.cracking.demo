package com.service.usbhelper;

import android.app.Application;
import com.service.usbhelper.d.a;

public class MyApplication extends Application
{
  public void onCreate()
  {
    super.onCreate();
    a.a().a(getApplicationContext());
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.MyApplication
 * JD-Core Version:    0.6.2
 */