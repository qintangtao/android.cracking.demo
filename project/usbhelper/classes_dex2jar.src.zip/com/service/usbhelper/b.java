package com.service.usbhelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

class b extends BroadcastReceiver
{
  b(TwinkleActivity paramTwinkleActivity)
  {
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if ((paramIntent.getAction().equals("android.hardware.usb.action.USB_STATE")) && (!paramIntent.getExtras().getBoolean("connected")))
      this.a.finish();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.b
 * JD-Core Version:    0.6.2
 */