package com.service.usbhelper;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class TwinkleActivity extends Activity
{
  private TextView a;
  private ImageView b;
  private b c;

  private void a(ImageView paramImageView)
  {
    paramImageView.setBackgroundResource(2130837505);
    ((AnimationDrawable)paramImageView.getBackground()).start();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    this.a = ((TextView)findViewById(2131099651));
    this.b = ((ImageView)findViewById(2131099649));
    Intent localIntent = getIntent();
    if (localIntent == null)
      finish();
    int i = localIntent.getIntExtra("installCount", 0);
    int j = localIntent.getIntExtra("successCount", 0);
    int k = localIntent.getIntExtra("failCount", 0);
    this.a.setText("已安装完成" + i + "个软件," + "成功" + j + "个," + "失败" + k + "个");
    this.c = new b(this);
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  protected void onPause()
  {
    super.onPause();
    unregisterReceiver(this.c);
  }

  protected void onResume()
  {
    super.onResume();
    registerReceiver(this.c, new IntentFilter("android.hardware.usb.action.USB_STATE"));
    a(this.b);
  }

  protected void onStart()
  {
    super.onStart();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.TwinkleActivity
 * JD-Core Version:    0.6.2
 */