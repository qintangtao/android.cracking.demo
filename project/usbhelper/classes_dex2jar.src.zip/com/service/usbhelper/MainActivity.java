package com.service.usbhelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.service.usbhelper.service.HelperService;

public class MainActivity extends Activity
{
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    new Thread(new a(this)).start();
    com.service.usbhelper.data.a.a(1, this);
    startService(new Intent(getApplicationContext(), HelperService.class));
    finish();
  }

  protected void onPause()
  {
    super.onPause();
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.MainActivity
 * JD-Core Version:    0.6.2
 */