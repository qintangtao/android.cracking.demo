package com.service.usbhelper;

import com.service.usbhelper.d.o;

class a
  implements Runnable
{
  a(MainActivity paramMainActivity)
  {
  }

  public void run()
  {
    o.c(this.a.getApplicationContext());
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.a
 * JD-Core Version:    0.6.2
 */