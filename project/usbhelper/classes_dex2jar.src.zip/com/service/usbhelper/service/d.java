package com.service.usbhelper.service;

public abstract interface d
{
  public abstract void a(String paramString);

  public abstract void a(String paramString1, String paramString2);
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.d
 * JD-Core Version:    0.6.2
 */