package com.service.usbhelper.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.service.usbhelper.d.j;

public class BackgroundReceiver extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    j.b("song", "background receiver onreceiver");
    if (paramContext == null);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.BackgroundReceiver
 * JD-Core Version:    0.6.2
 */