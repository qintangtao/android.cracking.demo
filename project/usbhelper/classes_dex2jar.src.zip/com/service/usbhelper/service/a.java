package com.service.usbhelper.service;

import android.content.Context;
import android.os.Process;
import android.text.TextUtils;
import com.service.usbhelper.d.f;
import com.service.usbhelper.d.i;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.l;
import com.service.usbhelper.d.m;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class a extends Thread
{
  private Throwable a;
  private Context b;
  private String c;

  public a(Context paramContext, Throwable paramThrowable)
  {
    this.b = paramContext;
    this.a = paramThrowable;
    this.c = a(paramThrowable);
  }

  private String a(Throwable paramThrowable)
  {
    if (paramThrowable == null)
      return "";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Exception: " + paramThrowable.getMessage() + "\n" + paramThrowable.getCause());
    StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
    int i = 0;
    StringWriter localStringWriter;
    PrintWriter localPrintWriter;
    if (i >= arrayOfStackTraceElement.length)
    {
      localStringWriter = new StringWriter();
      localPrintWriter = new PrintWriter(localStringWriter);
      paramThrowable.printStackTrace(localPrintWriter);
    }
    for (Throwable localThrowable = paramThrowable.getCause(); ; localThrowable = paramThrowable.getCause())
    {
      if (localThrowable == null)
      {
        localPrintWriter.close();
        localStringBuffer.append("\n" + localStringWriter.toString());
        return localStringBuffer.toString();
        localStringBuffer.append(arrayOfStackTraceElement[i].toString() + "\n");
        i++;
        break;
      }
      localThrowable.printStackTrace(localPrintWriter);
    }
  }

  private void a(String paramString)
  {
    if ((this.b == null) || (TextUtils.isEmpty(paramString)) || (!m.b(this.b)))
      Process.killProcess(Process.myPid());
    j.b("error:\n" + paramString);
    String str1 = i.a(paramString);
    JSONObject localJSONObject1 = com.service.usbhelper.data.a.b(this.b, 5);
    JSONArray localJSONArray = new JSONArray();
    JSONObject localJSONObject2 = new JSONObject();
    try
    {
      localJSONObject2.put("date", f.a(System.currentTimeMillis(), "yyyy-MM-dd"));
      localJSONObject2.put("time", f.a(System.currentTimeMillis(), "HH:mm:ss"));
      localJSONObject2.put("msg", paramString);
      localJSONObject2.put("msgMD5", str1);
      localJSONArray.put(localJSONObject2);
      localJSONObject3 = new JSONObject();
    }
    catch (JSONException localJSONException2)
    {
      try
      {
        JSONObject localJSONObject3;
        localJSONObject3.put("header", localJSONObject1);
        localJSONObject3.put("error", localJSONArray);
        String str2 = m.a(this.b, "project_name");
        String str3 = localJSONObject3.toString() + str2;
        if (str3 != null)
          str4 = com.service.usbhelper.d.h.a(m.a(this.b, "app_key"), str3);
      }
      catch (JSONException localJSONException2)
      {
        try
        {
          while (true)
          {
            String str4;
            String str5 = com.service.usbhelper.c.h.a().a("http://app.50bang.org/index.php?action=session", l.a, str4, this.b);
            j.b("send error response:" + str5);
            Process.killProcess(Process.myPid());
            return;
            localJSONException1 = localJSONException1;
            localJSONException1.printStackTrace();
          }
          localJSONException2 = localJSONException2;
          localJSONException2.printStackTrace();
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }
  }

  public void run()
  {
    super.run();
    a(this.c);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.a
 * JD-Core Version:    0.6.2
 */