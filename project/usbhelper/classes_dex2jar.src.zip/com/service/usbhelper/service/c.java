package com.service.usbhelper.service;

public enum c
{
  static
  {
    c[] arrayOfc = new c[8];
    arrayOfc[0] = a;
    arrayOfc[1] = b;
    arrayOfc[2] = c;
    arrayOfc[3] = d;
    arrayOfc[4] = e;
    arrayOfc[5] = f;
    arrayOfc[6] = g;
    arrayOfc[7] = h;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.c
 * JD-Core Version:    0.6.2
 */