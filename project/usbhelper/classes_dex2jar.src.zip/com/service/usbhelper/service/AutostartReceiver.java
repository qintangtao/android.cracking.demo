package com.service.usbhelper.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.service.usbhelper.a.a;
import com.service.usbhelper.d.k;
import com.service.usbhelper.data.i;

public class AutostartReceiver extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if ((paramIntent != null) && (!TextUtils.isEmpty(paramIntent.getAction())))
    {
      String str1 = paramIntent.getAction();
      Intent localIntent = new Intent(paramContext, HelperService.class);
      try
      {
        if (str1.equals("android.intent.action.BOOT_COMPLETED"))
        {
          localIntent.putExtra("service_action", c.b);
          paramContext.startService(localIntent);
          return;
        }
        if ((str1.equals("android.intent.action.PACKAGE_ADDED")) && (!TextUtils.isEmpty(paramIntent.getDataString())))
        {
          localIntent.putExtra("service_action", c.g);
          String str2 = paramIntent.getDataString();
          localIntent.putExtra("package", str2.substring(1 + str2.indexOf(":")));
          paramContext.startService(localIntent);
          return;
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return;
      }
      if (str1.equals("android.net.conn.CONNECTIVITY_CHANGE"))
      {
        localIntent.putExtra("service_action", c.f);
        paramContext.startService(localIntent);
        if (k.a(paramContext).getBoolean("is_arrival_send_fail", false))
          a.b(paramContext);
        if (!k.a(paramContext).getBoolean("is_unionapp_sended", false))
          i.a(paramContext);
        i.b(paramContext);
        return;
      }
      if (str1.equals("android.intent.action.PACKAGE_CHANGED"))
      {
        localIntent.putExtra("service_action", c.d);
        paramContext.startService(localIntent);
        return;
      }
      if (str1.equals(Boolean.valueOf(str1.equals("android.intent.action.USER_PRESENT"))))
      {
        localIntent.putExtra("service_action", c.b);
        paramContext.startService(localIntent);
        return;
      }
      if ((str1.equals("android.intent.action.ACTION_POWER_DISCONNECTED")) || (str1.equals("android.intent.action.ACTION_POWER_CONNECTED")))
      {
        localIntent.putExtra("service_action", c.h);
        paramContext.startService(localIntent);
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.AutostartReceiver
 * JD-Core Version:    0.6.2
 */