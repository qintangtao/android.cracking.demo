package com.service.usbhelper.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.service.usbhelper.d.j;

class b extends BroadcastReceiver
{
  b(HelperService paramHelperService)
  {
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str;
    if (paramIntent != null)
    {
      str = paramIntent.getAction();
      j.a("action:" + str);
      if (str != null)
      {
        if (!str.equals("android.intent.action.SCREEN_ON"))
          break label49;
        HelperService.a(this.a);
      }
    }
    label49: 
    while (!str.equals("android.intent.action.SCREEN_OFF"))
      return;
    j.a("锁屏广播");
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.b
 * JD-Core Version:    0.6.2
 */