package com.service.usbhelper.service;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build.VERSION;
import android.text.TextUtils;
import com.service.usbhelper.d.c;
import com.service.usbhelper.d.j;
import com.service.usbhelper.data.a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class e extends Thread
{
  public static String c = "";
  public static boolean d = true;
  public static int e = 1;
  public static e f;
  public static boolean g = false;
  private static int h = 0;
  private static List<String> i = null;
  Context a;
  d b;

  public e(Context paramContext, d paramd)
  {
    this.a = paramContext;
    this.b = paramd;
  }

  public static e a(Context paramContext, d paramd)
  {
    try
    {
      if (f == null)
        f = new e(paramContext, paramd);
      e locale = f;
      return locale;
    }
    finally
    {
    }
  }

  private static String a(ActivityManager paramActivityManager)
  {
    List localList = paramActivityManager.getRunningTasks(1);
    if ((localList != null) && (localList.size() > 0))
    {
      ActivityManager.RunningTaskInfo localRunningTaskInfo = (ActivityManager.RunningTaskInfo)localList.get(0);
      if (localRunningTaskInfo != null)
      {
        ComponentName localComponentName = localRunningTaskInfo.topActivity;
        if (localComponentName != null)
          return localComponentName.getPackageName();
      }
    }
    return null;
  }

  private static String a(ActivityManager paramActivityManager, Context paramContext)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramActivityManager.getRunningAppProcesses().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        if ((i == null) || (g))
        {
          i = c.f(paramContext);
          g = false;
        }
        if ((i == null) || (!localArrayList.retainAll(i)) || (localArrayList.size() <= 0))
          break;
        return (String)localArrayList.get(0);
      }
      ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)localIterator.next();
      if (localRunningAppProcessInfo.importance == 100)
        localArrayList.addAll(Arrays.asList(localRunningAppProcessInfo.pkgList));
    }
    return "running_package_null";
  }

  public static String a(Context paramContext)
  {
    if (paramContext == null)
      return null;
    ActivityManager localActivityManager = (ActivityManager)paramContext.getSystemService("activity");
    if (Build.VERSION.SDK_INT > 20)
      return a(localActivityManager, paramContext);
    return a(localActivityManager);
  }

  public void run()
  {
    super.run();
    c = a(this.a);
    if (!d)
      return;
    String str = a(this.a);
    if (TextUtils.isEmpty(str))
      str = "running_package_null";
    if ((!TextUtils.isEmpty(c)) && (c.equals(str)))
      this.b.a(c);
    while (true)
    {
      while (true)
      {
        j.a("count:" + e);
        if (e >= 300)
        {
          a.a(a.c(this.a), this.a);
          h = 1 + h;
          if (h >= 72)
          {
            j.a("监控线程中发送统计模块自身运行数据");
            a.a(2, this.a);
            h = 0;
          }
          e = 1;
        }
        try
        {
          e = 1 + e;
          Thread.sleep(1000L);
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      }
      break;
      if ((!TextUtils.isEmpty(c)) && (!c.equals(str)))
      {
        this.b.a(c, str);
        c = str;
      }
    }
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.service.e
 * JD-Core Version:    0.6.2
 */