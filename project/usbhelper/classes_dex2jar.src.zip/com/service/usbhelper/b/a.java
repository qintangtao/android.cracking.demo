package com.service.usbhelper.b;

public class a
{
  public static long a = 1800000L;
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.b.a
 * JD-Core Version:    0.6.2
 */