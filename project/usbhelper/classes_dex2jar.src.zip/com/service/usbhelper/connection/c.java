package com.service.usbhelper.connection;

import android.content.Context;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.SocketException;
import org.json.JSONException;
import org.json.JSONObject;

public class c
  implements Runnable
{
  private static final String a = c.class.getSimpleName();
  private Socket b;
  private Context c;

  public c(Context paramContext, Socket paramSocket)
  {
    try
    {
      paramSocket.setSoLinger(false, 0);
      this.b = paramSocket;
      this.c = paramContext;
      return;
    }
    catch (SocketException localSocketException)
    {
      while (true)
        localSocketException.printStackTrace();
    }
  }

  public static int a(BufferedInputStream paramBufferedInputStream)
  {
    byte[] arrayOfByte = new byte[4];
    if (paramBufferedInputStream.read(arrayOfByte, 0, arrayOfByte.length) == -1)
      return -1;
    if (arrayOfByte.length != 4)
      throw new IOException("data format error");
    return a.a(arrayOfByte, 0);
  }

  public static int a(InputStream paramInputStream)
  {
    byte[] arrayOfByte = new byte[4];
    int i = paramInputStream.read(arrayOfByte, 0, arrayOfByte.length);
    if (i < 4)
      paramInputStream.read(arrayOfByte, i, arrayOfByte.length - i);
    if (arrayOfByte.length != 4)
      throw new IOException("data format error");
    return a.a(arrayOfByte, 0);
  }

  private void a(int paramInt, BufferedOutputStream paramBufferedOutputStream)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("error_code", "10002");
      localJSONObject.put("error", "fail parm");
      String str = localJSONObject.toString();
      int i = str.getBytes().length;
      byte[] arrayOfByte = new byte[4];
      a.a(paramInt, arrayOfByte, 0);
      paramBufferedOutputStream.write(arrayOfByte);
      a.a(i, arrayOfByte, 0);
      paramBufferedOutputStream.write(arrayOfByte);
      paramBufferedOutputStream.write(str.getBytes());
      paramBufferedOutputStream.flush();
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localJSONException.printStackTrace();
    }
  }

  private void a(int paramInt, BufferedOutputStream paramBufferedOutputStream, String paramString)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("error_code", "10002");
      localJSONObject.put("error", paramString);
      String str = localJSONObject.toString();
      int i = str.getBytes().length;
      byte[] arrayOfByte = new byte[4];
      a.a(paramInt, arrayOfByte, 0);
      paramBufferedOutputStream.write(arrayOfByte);
      a.a(i, arrayOfByte, 0);
      paramBufferedOutputStream.write(arrayOfByte);
      paramBufferedOutputStream.write(str.getBytes());
      paramBufferedOutputStream.flush();
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localJSONException.printStackTrace();
    }
  }

  private void a(int paramInt, BufferedOutputStream paramBufferedOutputStream, String paramString1, String paramString2)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("error_code", paramString1);
      localJSONObject.put("error", paramString2);
      String str = localJSONObject.toString();
      int i = str.getBytes().length;
      byte[] arrayOfByte = new byte[4];
      a.a(paramInt, arrayOfByte, 0);
      paramBufferedOutputStream.write(arrayOfByte);
      a.a(i, arrayOfByte, 0);
      paramBufferedOutputStream.write(arrayOfByte);
      paramBufferedOutputStream.write(str.getBytes());
      paramBufferedOutputStream.flush();
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localJSONException.printStackTrace();
    }
  }

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: getstatic 116	com/service/usbhelper/connection/ConnectionService:TAG	Ljava/lang/String;
    //   5: new 118	java/lang/StringBuilder
    //   8: dup
    //   9: invokestatic 124	java/lang/Thread:currentThread	()Ljava/lang/Thread;
    //   12: invokevirtual 127	java/lang/Thread:getName	()Ljava/lang/String;
    //   15: invokestatic 131	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   18: invokespecial 132	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   21: ldc 134
    //   23: invokevirtual 138	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: ldc 140
    //   28: invokevirtual 138	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: invokevirtual 141	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   34: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   37: pop
    //   38: new 96	java/io/BufferedOutputStream
    //   41: dup
    //   42: aload_0
    //   43: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   46: invokevirtual 151	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
    //   49: invokespecial 154	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   52: astore_3
    //   53: new 44	java/io/BufferedInputStream
    //   56: dup
    //   57: aload_0
    //   58: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   61: invokevirtual 158	java/net/Socket:getInputStream	()Ljava/io/InputStream;
    //   64: invokespecial 161	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   67: astore 4
    //   69: getstatic 22	com/service/usbhelper/connection/c:a	Ljava/lang/String;
    //   72: ldc 163
    //   74: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   77: pop
    //   78: aload_0
    //   79: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   82: invokevirtual 167	java/net/Socket:isConnected	()Z
    //   85: ifeq +13 -> 98
    //   88: aload_0
    //   89: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   92: invokevirtual 170	java/net/Socket:isClosed	()Z
    //   95: ifeq +111 -> 206
    //   98: getstatic 22	com/service/usbhelper/connection/c:a	Ljava/lang/String;
    //   101: ldc 172
    //   103: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   106: pop
    //   107: bipush 6
    //   109: newarray byte
    //   111: astore 38
    //   113: iload_1
    //   114: iconst_m1
    //   115: if_icmpeq +9 -> 124
    //   118: iload_1
    //   119: bipush 6
    //   121: if_icmplt +36 -> 157
    //   124: aload_3
    //   125: ifnull +7 -> 132
    //   128: aload_3
    //   129: invokevirtual 175	java/io/BufferedOutputStream:close	()V
    //   132: aload 4
    //   134: ifnull +8 -> 142
    //   137: aload 4
    //   139: invokevirtual 176	java/io/BufferedInputStream:close	()V
    //   142: aload_0
    //   143: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   146: ifnull +10 -> 156
    //   149: aload_0
    //   150: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   153: invokevirtual 177	java/net/Socket:close	()V
    //   156: return
    //   157: bipush 6
    //   159: iload_1
    //   160: isub
    //   161: istore 39
    //   163: aload 4
    //   165: aload 38
    //   167: iload_1
    //   168: iload 39
    //   170: invokevirtual 48	java/io/BufferedInputStream:read	([BII)I
    //   173: istore 40
    //   175: iload 40
    //   177: iflt -53 -> 124
    //   180: iload_1
    //   181: iload 40
    //   183: iadd
    //   184: istore_1
    //   185: goto -72 -> 113
    //   188: astore 36
    //   190: aload 36
    //   192: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   195: goto -71 -> 124
    //   198: astore 37
    //   200: aload 37
    //   202: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   205: return
    //   206: getstatic 22	com/service/usbhelper/connection/c:a	Ljava/lang/String;
    //   209: new 118	java/lang/StringBuilder
    //   212: dup
    //   213: ldc 181
    //   215: invokespecial 132	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   218: aload_0
    //   219: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   222: invokevirtual 167	java/net/Socket:isConnected	()Z
    //   225: invokevirtual 184	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   228: ldc 186
    //   230: invokevirtual 138	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   233: aload_0
    //   234: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   237: invokevirtual 170	java/net/Socket:isClosed	()Z
    //   240: invokevirtual 184	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   243: invokevirtual 141	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   246: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   249: pop
    //   250: aload 4
    //   252: invokestatic 188	com/service/usbhelper/connection/c:a	(Ljava/io/InputStream;)I
    //   255: istore 42
    //   257: iload 42
    //   259: istore 6
    //   261: aload 4
    //   263: invokestatic 190	com/service/usbhelper/connection/c:a	(Ljava/io/BufferedInputStream;)I
    //   266: istore 43
    //   268: getstatic 22	com/service/usbhelper/connection/c:a	Ljava/lang/String;
    //   271: new 118	java/lang/StringBuilder
    //   274: dup
    //   275: ldc 192
    //   277: invokespecial 132	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   280: iload 43
    //   282: invokevirtual 195	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   285: invokevirtual 141	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   288: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   291: pop
    //   292: getstatic 22	com/service/usbhelper/connection/c:a	Ljava/lang/String;
    //   295: new 118	java/lang/StringBuilder
    //   298: dup
    //   299: ldc 197
    //   301: invokespecial 132	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   304: iload 6
    //   306: invokevirtual 195	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   309: invokevirtual 141	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   312: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   315: pop
    //   316: ldc 199
    //   318: aload_0
    //   319: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   322: invokevirtual 203	java/net/Socket:getInetAddress	()Ljava/net/InetAddress;
    //   325: invokevirtual 208	java/net/InetAddress:getHostAddress	()Ljava/lang/String;
    //   328: invokestatic 147	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   331: pop
    //   332: iload 6
    //   334: lookupswitch	default:+58->392, 29:+123->457, 301:+309->643, 302:+65->399, 303:+65->399, 309:+399->733, 500:+223->557
    //   393: iload 6
    //   395: aload_3
    //   396: invokespecial 210	com/service/usbhelper/connection/c:a	(ILjava/io/BufferedOutputStream;)V
    //   399: bipush 6
    //   401: newarray byte
    //   403: astore 49
    //   405: iload_1
    //   406: iconst_m1
    //   407: if_icmpeq +9 -> 416
    //   410: iload_1
    //   411: bipush 6
    //   413: if_icmplt +587 -> 1000
    //   416: aload_3
    //   417: ifnull +7 -> 424
    //   420: aload_3
    //   421: invokevirtual 175	java/io/BufferedOutputStream:close	()V
    //   424: aload 4
    //   426: ifnull +8 -> 434
    //   429: aload 4
    //   431: invokevirtual 176	java/io/BufferedInputStream:close	()V
    //   434: aload_0
    //   435: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   438: ifnull -282 -> 156
    //   441: aload_0
    //   442: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   445: invokevirtual 177	java/net/Socket:close	()V
    //   448: return
    //   449: astore 48
    //   451: aload 48
    //   453: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   456: return
    //   457: iload 43
    //   459: aload 4
    //   461: aload_3
    //   462: aload_0
    //   463: getfield 38	com/service/usbhelper/connection/c:c	Landroid/content/Context;
    //   466: invokestatic 213	com/service/usbhelper/connection/a:a	(ILjava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;Landroid/content/Context;)V
    //   469: goto -70 -> 399
    //   472: astore 5
    //   474: aload_0
    //   475: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   478: astore 13
    //   480: aload 13
    //   482: ifnull +17 -> 499
    //   485: aload_0
    //   486: iload 6
    //   488: aload_3
    //   489: ldc 215
    //   491: aload 5
    //   493: invokevirtual 218	java/io/IOException:getMessage	()Ljava/lang/String;
    //   496: invokespecial 220	com/service/usbhelper/connection/c:a	(ILjava/io/BufferedOutputStream;Ljava/lang/String;Ljava/lang/String;)V
    //   499: bipush 6
    //   501: newarray byte
    //   503: astore 16
    //   505: iload_1
    //   506: iconst_m1
    //   507: if_icmpeq +9 -> 516
    //   510: iload_1
    //   511: bipush 6
    //   513: if_icmplt +293 -> 806
    //   516: aload_3
    //   517: ifnull +7 -> 524
    //   520: aload_3
    //   521: invokevirtual 175	java/io/BufferedOutputStream:close	()V
    //   524: aload 4
    //   526: ifnull +8 -> 534
    //   529: aload 4
    //   531: invokevirtual 176	java/io/BufferedInputStream:close	()V
    //   534: aload_0
    //   535: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   538: ifnull -382 -> 156
    //   541: aload_0
    //   542: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   545: invokevirtual 177	java/net/Socket:close	()V
    //   548: return
    //   549: astore 15
    //   551: aload 15
    //   553: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   556: return
    //   557: iload 43
    //   559: aload 4
    //   561: aload_0
    //   562: getfield 38	com/service/usbhelper/connection/c:c	Landroid/content/Context;
    //   565: invokestatic 223	com/service/usbhelper/connection/a:a	(ILjava/io/BufferedInputStream;Landroid/content/Context;)V
    //   568: goto -169 -> 399
    //   571: astore 20
    //   573: aload_0
    //   574: iload 6
    //   576: aload_3
    //   577: aload 20
    //   579: invokevirtual 224	java/lang/OutOfMemoryError:getMessage	()Ljava/lang/String;
    //   582: invokespecial 226	com/service/usbhelper/connection/c:a	(ILjava/io/BufferedOutputStream;Ljava/lang/String;)V
    //   585: bipush 6
    //   587: newarray byte
    //   589: astore 24
    //   591: iload_1
    //   592: iconst_m1
    //   593: if_icmpeq +9 -> 602
    //   596: iload_1
    //   597: bipush 6
    //   599: if_icmplt +258 -> 857
    //   602: aload_3
    //   603: ifnull +7 -> 610
    //   606: aload_3
    //   607: invokevirtual 175	java/io/BufferedOutputStream:close	()V
    //   610: aload 4
    //   612: ifnull +8 -> 620
    //   615: aload 4
    //   617: invokevirtual 176	java/io/BufferedInputStream:close	()V
    //   620: aload_0
    //   621: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   624: ifnull -468 -> 156
    //   627: aload_0
    //   628: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   631: invokevirtual 177	java/net/Socket:close	()V
    //   634: return
    //   635: astore 23
    //   637: aload 23
    //   639: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   642: return
    //   643: aload_3
    //   644: iload 6
    //   646: aload_0
    //   647: getfield 38	com/service/usbhelper/connection/c:c	Landroid/content/Context;
    //   650: invokestatic 229	com/service/usbhelper/connection/a:a	(Ljava/io/BufferedOutputStream;ILandroid/content/Context;)V
    //   653: goto -254 -> 399
    //   656: astore 27
    //   658: aload 27
    //   660: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   663: aload_0
    //   664: iload 6
    //   666: aload_3
    //   667: aload 27
    //   669: invokevirtual 230	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   672: invokespecial 226	com/service/usbhelper/connection/c:a	(ILjava/io/BufferedOutputStream;Ljava/lang/String;)V
    //   675: bipush 6
    //   677: newarray byte
    //   679: astore 31
    //   681: iload_1
    //   682: iconst_m1
    //   683: if_icmpeq +9 -> 692
    //   686: iload_1
    //   687: bipush 6
    //   689: if_icmplt +219 -> 908
    //   692: aload_3
    //   693: ifnull +7 -> 700
    //   696: aload_3
    //   697: invokevirtual 175	java/io/BufferedOutputStream:close	()V
    //   700: aload 4
    //   702: ifnull +8 -> 710
    //   705: aload 4
    //   707: invokevirtual 176	java/io/BufferedInputStream:close	()V
    //   710: aload_0
    //   711: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   714: ifnull -558 -> 156
    //   717: aload_0
    //   718: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   721: invokevirtual 177	java/net/Socket:close	()V
    //   724: return
    //   725: astore 30
    //   727: aload 30
    //   729: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   732: return
    //   733: aload_3
    //   734: iload 6
    //   736: invokestatic 233	com/service/usbhelper/connection/a:a	(Ljava/io/BufferedOutputStream;I)V
    //   739: goto -340 -> 399
    //   742: astore 7
    //   744: bipush 6
    //   746: newarray byte
    //   748: astore 10
    //   750: iload_1
    //   751: iconst_m1
    //   752: if_icmpeq +9 -> 761
    //   755: iload_1
    //   756: bipush 6
    //   758: if_icmplt +191 -> 949
    //   761: aload_3
    //   762: ifnull +7 -> 769
    //   765: aload_3
    //   766: invokevirtual 175	java/io/BufferedOutputStream:close	()V
    //   769: aload 4
    //   771: ifnull +8 -> 779
    //   774: aload 4
    //   776: invokevirtual 176	java/io/BufferedInputStream:close	()V
    //   779: aload_0
    //   780: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   783: ifnull +10 -> 793
    //   786: aload_0
    //   787: getfield 36	com/service/usbhelper/connection/c:b	Ljava/net/Socket;
    //   790: invokevirtual 177	java/net/Socket:close	()V
    //   793: aload 7
    //   795: athrow
    //   796: astore 19
    //   798: aload 19
    //   800: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   803: goto -304 -> 499
    //   806: bipush 6
    //   808: iload_1
    //   809: isub
    //   810: istore 17
    //   812: aload 4
    //   814: aload 16
    //   816: iload_1
    //   817: iload 17
    //   819: invokevirtual 48	java/io/BufferedInputStream:read	([BII)I
    //   822: istore 18
    //   824: iload 18
    //   826: iflt -310 -> 516
    //   829: iload_1
    //   830: iload 18
    //   832: iadd
    //   833: istore_1
    //   834: goto -329 -> 505
    //   837: astore 14
    //   839: aload 14
    //   841: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   844: goto -328 -> 516
    //   847: astore 21
    //   849: aload 21
    //   851: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   854: goto -269 -> 585
    //   857: bipush 6
    //   859: iload_1
    //   860: isub
    //   861: istore 25
    //   863: aload 4
    //   865: aload 24
    //   867: iload_1
    //   868: iload 25
    //   870: invokevirtual 48	java/io/BufferedInputStream:read	([BII)I
    //   873: istore 26
    //   875: iload 26
    //   877: iflt -275 -> 602
    //   880: iload_1
    //   881: iload 26
    //   883: iadd
    //   884: istore_1
    //   885: goto -294 -> 591
    //   888: astore 22
    //   890: aload 22
    //   892: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   895: goto -293 -> 602
    //   898: astore 28
    //   900: aload 28
    //   902: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   905: goto -230 -> 675
    //   908: bipush 6
    //   910: iload_1
    //   911: isub
    //   912: istore 32
    //   914: aload 4
    //   916: aload 31
    //   918: iload_1
    //   919: iload 32
    //   921: invokevirtual 48	java/io/BufferedInputStream:read	([BII)I
    //   924: istore 33
    //   926: iload 33
    //   928: iflt -236 -> 692
    //   931: iload_1
    //   932: iload 33
    //   934: iadd
    //   935: istore_1
    //   936: goto -255 -> 681
    //   939: astore 29
    //   941: aload 29
    //   943: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   946: goto -254 -> 692
    //   949: bipush 6
    //   951: iload_1
    //   952: isub
    //   953: istore 11
    //   955: aload 4
    //   957: aload 10
    //   959: iload_1
    //   960: iload 11
    //   962: invokevirtual 48	java/io/BufferedInputStream:read	([BII)I
    //   965: istore 12
    //   967: iload 12
    //   969: iflt -208 -> 761
    //   972: iload_1
    //   973: iload 12
    //   975: iadd
    //   976: istore_1
    //   977: goto -227 -> 750
    //   980: astore 8
    //   982: aload 8
    //   984: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   987: goto -226 -> 761
    //   990: astore 9
    //   992: aload 9
    //   994: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   997: goto -204 -> 793
    //   1000: bipush 6
    //   1002: iload_1
    //   1003: isub
    //   1004: istore 50
    //   1006: aload 4
    //   1008: aload 49
    //   1010: iload_1
    //   1011: iload 50
    //   1013: invokevirtual 48	java/io/BufferedInputStream:read	([BII)I
    //   1016: istore 51
    //   1018: iload 51
    //   1020: iflt -604 -> 416
    //   1023: iload_1
    //   1024: iload 51
    //   1026: iadd
    //   1027: istore_1
    //   1028: goto -623 -> 405
    //   1031: astore 47
    //   1033: aload 47
    //   1035: invokevirtual 178	java/io/IOException:printStackTrace	()V
    //   1038: goto -622 -> 416
    //   1041: astore 7
    //   1043: aconst_null
    //   1044: astore 4
    //   1046: aconst_null
    //   1047: astore_3
    //   1048: goto -304 -> 744
    //   1051: astore 7
    //   1053: aconst_null
    //   1054: astore 4
    //   1056: goto -312 -> 744
    //   1059: astore 27
    //   1061: iconst_0
    //   1062: istore 6
    //   1064: aconst_null
    //   1065: astore 4
    //   1067: aconst_null
    //   1068: astore_3
    //   1069: goto -411 -> 658
    //   1072: astore 27
    //   1074: iconst_0
    //   1075: istore 6
    //   1077: aconst_null
    //   1078: astore 4
    //   1080: goto -422 -> 658
    //   1083: astore 27
    //   1085: iconst_0
    //   1086: istore 6
    //   1088: goto -430 -> 658
    //   1091: astore 20
    //   1093: iconst_0
    //   1094: istore 6
    //   1096: aconst_null
    //   1097: astore 4
    //   1099: aconst_null
    //   1100: astore_3
    //   1101: goto -528 -> 573
    //   1104: astore 20
    //   1106: iconst_0
    //   1107: istore 6
    //   1109: aconst_null
    //   1110: astore 4
    //   1112: goto -539 -> 573
    //   1115: astore 20
    //   1117: iconst_0
    //   1118: istore 6
    //   1120: goto -547 -> 573
    //   1123: astore 5
    //   1125: iconst_0
    //   1126: istore 6
    //   1128: aconst_null
    //   1129: astore 4
    //   1131: aconst_null
    //   1132: astore_3
    //   1133: goto -659 -> 474
    //   1136: astore 5
    //   1138: iconst_0
    //   1139: istore 6
    //   1141: aconst_null
    //   1142: astore 4
    //   1144: goto -670 -> 474
    //   1147: astore 5
    //   1149: iconst_0
    //   1150: istore 6
    //   1152: goto -678 -> 474
    //
    // Exception table:
    //   from	to	target	type
    //   107	113	188	java/io/IOException
    //   163	175	188	java/io/IOException
    //   128	132	198	java/lang/Exception
    //   137	142	198	java/lang/Exception
    //   142	156	198	java/lang/Exception
    //   420	424	449	java/lang/Exception
    //   429	434	449	java/lang/Exception
    //   434	448	449	java/lang/Exception
    //   261	332	472	java/io/IOException
    //   392	399	472	java/io/IOException
    //   457	469	472	java/io/IOException
    //   557	568	472	java/io/IOException
    //   643	653	472	java/io/IOException
    //   733	739	472	java/io/IOException
    //   520	524	549	java/lang/Exception
    //   529	534	549	java/lang/Exception
    //   534	548	549	java/lang/Exception
    //   261	332	571	java/lang/OutOfMemoryError
    //   392	399	571	java/lang/OutOfMemoryError
    //   457	469	571	java/lang/OutOfMemoryError
    //   557	568	571	java/lang/OutOfMemoryError
    //   643	653	571	java/lang/OutOfMemoryError
    //   733	739	571	java/lang/OutOfMemoryError
    //   606	610	635	java/lang/Exception
    //   615	620	635	java/lang/Exception
    //   620	634	635	java/lang/Exception
    //   261	332	656	java/lang/Exception
    //   392	399	656	java/lang/Exception
    //   457	469	656	java/lang/Exception
    //   557	568	656	java/lang/Exception
    //   643	653	656	java/lang/Exception
    //   733	739	656	java/lang/Exception
    //   696	700	725	java/lang/Exception
    //   705	710	725	java/lang/Exception
    //   710	724	725	java/lang/Exception
    //   69	98	742	finally
    //   98	107	742	finally
    //   206	257	742	finally
    //   261	332	742	finally
    //   392	399	742	finally
    //   457	469	742	finally
    //   474	480	742	finally
    //   485	499	742	finally
    //   557	568	742	finally
    //   573	585	742	finally
    //   643	653	742	finally
    //   658	675	742	finally
    //   733	739	742	finally
    //   798	803	742	finally
    //   849	854	742	finally
    //   900	905	742	finally
    //   485	499	796	java/io/IOException
    //   499	505	837	java/io/IOException
    //   812	824	837	java/io/IOException
    //   573	585	847	java/io/IOException
    //   585	591	888	java/io/IOException
    //   863	875	888	java/io/IOException
    //   658	675	898	java/io/IOException
    //   675	681	939	java/io/IOException
    //   914	926	939	java/io/IOException
    //   744	750	980	java/io/IOException
    //   955	967	980	java/io/IOException
    //   765	769	990	java/lang/Exception
    //   774	779	990	java/lang/Exception
    //   779	793	990	java/lang/Exception
    //   399	405	1031	java/io/IOException
    //   1006	1018	1031	java/io/IOException
    //   38	53	1041	finally
    //   53	69	1051	finally
    //   38	53	1059	java/lang/Exception
    //   53	69	1072	java/lang/Exception
    //   69	98	1083	java/lang/Exception
    //   98	107	1083	java/lang/Exception
    //   206	257	1083	java/lang/Exception
    //   38	53	1091	java/lang/OutOfMemoryError
    //   53	69	1104	java/lang/OutOfMemoryError
    //   69	98	1115	java/lang/OutOfMemoryError
    //   98	107	1115	java/lang/OutOfMemoryError
    //   206	257	1115	java/lang/OutOfMemoryError
    //   38	53	1123	java/io/IOException
    //   53	69	1136	java/io/IOException
    //   69	98	1147	java/io/IOException
    //   98	107	1147	java/io/IOException
    //   206	257	1147	java/io/IOException
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.connection.c
 * JD-Core Version:    0.6.2
 */