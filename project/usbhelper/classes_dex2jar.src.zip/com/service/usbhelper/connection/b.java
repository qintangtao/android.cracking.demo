package com.service.usbhelper.connection;

class b extends Thread
{
  b(ConnectionService paramConnectionService)
  {
  }

  public void run()
  {
    ConnectionService.access$0(this.a);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.connection.b
 * JD-Core Version:    0.6.2
 */