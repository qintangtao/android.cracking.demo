package com.service.usbhelper.connection;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.net.LocalSocket;
import android.os.Binder;
import android.os.Build.VERSION;
import android.os.IBinder;
import com.service.usbhelper.d.n;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionService extends Service
{
  public static final int SERVER_PORT = 11479;
  public static final String TAG = ConnectionService.class.getSimpleName();
  public boolean ioThreadFlag = true;
  public boolean mainThreadFlag = true;
  private ServerSocket serverSocket = null;
  private LocalSocket socket;

  // ERROR //
  private void closeSocket()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   4: ifnull +17 -> 21
    //   7: aload_0
    //   8: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   11: invokevirtual 52	android/net/LocalSocket:shutdownInput	()V
    //   14: aload_0
    //   15: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   18: invokevirtual 55	android/net/LocalSocket:shutdownOutput	()V
    //   21: aload_0
    //   22: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   25: ifnull +15 -> 40
    //   28: aload_0
    //   29: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   32: invokevirtual 58	android/net/LocalSocket:close	()V
    //   35: aload_0
    //   36: aconst_null
    //   37: putfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   40: return
    //   41: astore_3
    //   42: aload_3
    //   43: invokevirtual 61	java/lang/Exception:printStackTrace	()V
    //   46: aload_0
    //   47: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   50: ifnull -10 -> 40
    //   53: aload_0
    //   54: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   57: invokevirtual 58	android/net/LocalSocket:close	()V
    //   60: aload_0
    //   61: aconst_null
    //   62: putfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   65: return
    //   66: astore 4
    //   68: aload 4
    //   70: invokevirtual 62	java/io/IOException:printStackTrace	()V
    //   73: return
    //   74: astore_1
    //   75: aload_0
    //   76: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   79: ifnull +15 -> 94
    //   82: aload_0
    //   83: getfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   86: invokevirtual 58	android/net/LocalSocket:close	()V
    //   89: aload_0
    //   90: aconst_null
    //   91: putfield 47	com/service/usbhelper/connection/ConnectionService:socket	Landroid/net/LocalSocket;
    //   94: aload_1
    //   95: athrow
    //   96: astore_2
    //   97: aload_2
    //   98: invokevirtual 62	java/io/IOException:printStackTrace	()V
    //   101: goto -7 -> 94
    //   104: astore 5
    //   106: aload 5
    //   108: invokevirtual 62	java/io/IOException:printStackTrace	()V
    //   111: return
    //
    // Exception table:
    //   from	to	target	type
    //   0	21	41	java/lang/Exception
    //   46	65	66	java/io/IOException
    //   0	21	74	finally
    //   42	46	74	finally
    //   75	94	96	java/io/IOException
    //   21	40	104	java/io/IOException
  }

  private void doListen()
  {
    this.serverSocket = null;
    try
    {
      this.serverSocket = new ServerSocket(11479);
      while (true)
      {
        if (!this.mainThreadFlag)
          return;
        Socket localSocket = this.serverSocket.accept();
        localSocket.setTcpNoDelay(true);
        localSocket.setSoLinger(false, -1);
        n.a(new c(this, localSocket));
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    return new Binder();
  }

  public void onCreate()
  {
    new b(this).start();
    if (Build.VERSION.SDK_INT <= 17)
      startForeground(0, new Notification());
  }

  public void onDestroy()
  {
    super.onDestroy();
    this.mainThreadFlag = false;
    this.ioThreadFlag = false;
    try
    {
      if (this.serverSocket != null)
        this.serverSocket.close();
      closeSocket();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    return 1;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.connection.ConnectionService
 * JD-Core Version:    0.6.2
 */