package com.service.usbhelper.connection;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import com.service.usbhelper.TwinkleActivity;
import com.service.usbhelper.d.g;
import com.service.usbhelper.d.m;
import com.service.usbhelper.data.f;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONException;
import org.json.JSONObject;

public class a
{
  public static final byte[] a = { 79, 75, 65, 89 };
  public static final byte[] b = { 70, 65, 73, 76 };
  public static final byte[] c = { 83, 84, 65, 84 };
  public static final byte[] d = { 82, 69, 67, 86 };
  public static final byte[] e = { 68, 65, 84, 65 };
  public static final byte[] f = { 68, 79, 78, 69 };
  public static final byte[] g = { 83, 69, 78, 68 };
  public static final byte[] h = { 80, 65, 67, 75 };
  public static final byte[] i = { 48, 48, 73, 68 };
  public static final byte[] j = { 84, 89, 80, 69 };
  public static final byte[] k = { 78, 65, 77, 69 };
  public static boolean l;
  private static Object m = new Object();
  private static Object n = new Object();
  private static final Object o = new Object();
  private static AtomicInteger p = new AtomicInteger(0);
  private static HashMap<String, Integer> q = new HashMap();
  private static HashMap<String, Integer> r = new HashMap();

  public static int a(byte[] paramArrayOfByte, int paramInt)
  {
    return 0x0 | 0xFF & paramArrayOfByte[paramInt] | (0xFF & paramArrayOfByte[(paramInt + 1)]) << 8 | (0xFF & paramArrayOfByte[(paramInt + 2)]) << 16 | (0xFF & paramArrayOfByte[(paramInt + 3)]) << 24;
  }

  private static void a()
  {
    l = true;
  }

  public static void a(int paramInt, BufferedInputStream paramBufferedInputStream, Context paramContext)
  {
    byte[] arrayOfByte = new byte[paramInt];
    int i1 = 0;
    while (true)
    {
      if ((i1 == -1) || (i1 >= paramInt))
      {
        JSONObject localJSONObject = new JSONObject(new String(arrayOfByte));
        Intent localIntent = new Intent(paramContext, TwinkleActivity.class);
        localIntent.setFlags(268435456);
        localIntent.putExtra("installCount", localJSONObject.getInt("installCount"));
        localIntent.putExtra("successCount", localJSONObject.getInt("successCount"));
        localIntent.putExtra("failCount", localJSONObject.getInt("failCount"));
        paramContext.startActivity(localIntent);
        return;
      }
      i1 += paramBufferedInputStream.read(arrayOfByte, i1, paramInt - i1);
    }
  }

  public static void a(int paramInt, BufferedInputStream paramBufferedInputStream, BufferedOutputStream paramBufferedOutputStream, Context paramContext)
  {
    a();
    try
    {
      JSONObject localJSONObject = f.a(paramContext);
      localJSONObject.put("error_code", "00001");
      a(localJSONObject, 29, paramBufferedOutputStream);
      System.gc();
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localJSONException.printStackTrace();
    }
  }

  public static void a(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[paramInt2] = ((byte)(paramInt1 & 0xFF));
    paramArrayOfByte[(paramInt2 + 1)] = ((byte)((0xFF00 & paramInt1) >> 8));
    paramArrayOfByte[(paramInt2 + 2)] = ((byte)((0xFF0000 & paramInt1) >> 16));
    paramArrayOfByte[(paramInt2 + 3)] = ((byte)((0xFF000000 & paramInt1) >> 24));
  }

  public static void a(BufferedOutputStream paramBufferedOutputStream, int paramInt)
  {
    a("usbHelper", paramInt, paramBufferedOutputStream);
  }

  public static void a(BufferedOutputStream paramBufferedOutputStream, int paramInt, Context paramContext)
  {
    String str1 = g.a(paramContext);
    if (TextUtils.isEmpty(str1))
      str1 = "";
    String str2 = g.b(paramContext);
    if (TextUtils.isEmpty(str2))
      str2 = "";
    String str3 = m.d(paramContext);
    if (TextUtils.isEmpty(str3))
      str3 = "";
    String str4 = Build.BRAND;
    if (TextUtils.isEmpty(str4))
      str4 = "";
    String str5 = Build.MODEL;
    if (TextUtils.isEmpty(str5))
      str5 = "";
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("imei", str1);
      localJSONObject.put("wmac", str2);
      localJSONObject.put("imsi", str3);
      localJSONObject.put("brand", str4);
      localJSONObject.put("device_model", str5);
      a(localJSONObject, paramInt, paramBufferedOutputStream);
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localJSONException.printStackTrace();
    }
  }

  private static void a(String paramString, int paramInt, OutputStream paramOutputStream)
  {
    int i1 = paramString.getBytes().length;
    byte[] arrayOfByte1 = new byte[4];
    a(i1, arrayOfByte1, 0);
    byte[] arrayOfByte2 = new byte[4];
    a(paramInt, arrayOfByte2, 0);
    paramOutputStream.write(arrayOfByte2);
    paramOutputStream.write(arrayOfByte1);
    paramOutputStream.write(paramString.getBytes());
    paramOutputStream.flush();
  }

  private static void a(JSONObject paramJSONObject, int paramInt, OutputStream paramOutputStream)
  {
    String str = paramJSONObject.toString();
    int i1 = str.getBytes().length;
    byte[] arrayOfByte1 = new byte[4];
    a(i1, arrayOfByte1, 0);
    byte[] arrayOfByte2 = new byte[4];
    a(paramInt, arrayOfByte2, 0);
    paramOutputStream.write(arrayOfByte2);
    paramOutputStream.write(arrayOfByte1);
    paramOutputStream.write(str.getBytes());
    paramOutputStream.flush();
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\usbhelper\classes_dex2jar.jar
 * Qualified Name:     com.service.usbhelper.connection.a
 * JD-Core Version:    0.6.2
 */