package android.support.v4.view;

import android.view.MenuItem;

public class MenuCompat
{
  @Deprecated
  public static void setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    MenuItemCompat.setShowAsAction(paramMenuItem, paramInt);
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\Tool\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.MenuCompat
 * JD-Core Version:    0.6.2
 */