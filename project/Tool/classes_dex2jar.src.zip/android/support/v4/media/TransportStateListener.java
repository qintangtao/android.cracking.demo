package android.support.v4.media;

public class TransportStateListener
{
  public void onPlayingChanged(TransportController paramTransportController)
  {
  }

  public void onTransportControlsChanged(TransportController paramTransportController)
  {
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\Tool\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.TransportStateListener
 * JD-Core Version:    0.6.2
 */