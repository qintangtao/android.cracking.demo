package android.support.v4.internal.view;

import android.view.SubMenu;

public abstract interface SupportSubMenu extends SupportMenu, SubMenu
{
}

/* Location:           C:\Users\Tato\Desktop\android反编译\Tool\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.internal.view.SupportSubMenu
 * JD-Core Version:    0.6.2
 */