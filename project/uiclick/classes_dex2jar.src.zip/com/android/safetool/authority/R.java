package com.android.safetool.authority;

public final class R
{
  public static final class attr
  {
  }

  public static final class dimen
  {
    public static final int activity_horizontal_margin = 2130968576;
    public static final int activity_vertical_margin = 2130968577;
  }

  public static final class drawable
  {
    public static final int ic_launcher = 2130837504;
  }

  public static final class id
  {
    public static final int action_settings = 2131230732;
    public static final int bt_getPhoneInfo = 2131230720;
    public static final int bt_nulls = 2131230726;
    public static final int bt_open = 2131230723;
    public static final int bt_open_web = 2131230721;
    public static final int bt_remove = 2131230724;
    public static final int bt_start_server = 2131230722;
    public static final int edit_content = 2131230730;
    public static final int edit_num = 2131230731;
    public static final int fl_back_ground = 2131230728;
    public static final int rl_root = 2131230727;
    public static final int scroll = 2131230729;
    public static final int tv_show = 2131230725;
  }

  public static final class layout
  {
    public static final int activity_main = 2130903040;
    public static final int fragment_main = 2130903041;
    public static final int nullss = 2130903042;
    public static final int suspend = 2130903043;
  }

  public static final class menu
  {
    public static final int main = 2131165184;
  }

  public static final class string
  {
    public static final int action_settings = 2131034114;
    public static final int app_name = 2131034112;
    public static final int get = 2131034115;
    public static final int hello_world = 2131034113;
  }

  public static final class style
  {
    public static final int AppBaseTheme = 2131099648;
    public static final int AppTheme = 2131099649;
  }
}

/* Location:           C:\Users\Tato\Desktop\android反编译\Tool\classes_dex2jar.jar
 * Qualified Name:     com.android.safetool.authority.R
 * JD-Core Version:    0.6.2
 */