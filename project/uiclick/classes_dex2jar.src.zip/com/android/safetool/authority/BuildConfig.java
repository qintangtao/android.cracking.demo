package com.android.safetool.authority;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}

/* Location:           C:\Users\Tato\Desktop\android反编译\Tool\classes_dex2jar.jar
 * Qualified Name:     com.android.safetool.authority.BuildConfig
 * JD-Core Version:    0.6.2
 */